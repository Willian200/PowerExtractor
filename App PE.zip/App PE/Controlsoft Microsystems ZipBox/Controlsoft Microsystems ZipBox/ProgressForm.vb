'
'Copyright (c)  2008-2009,Domagoj Pintaric
'SharpArchiver is distributed under the terms of the GNU Lesser General Public License
'
'    This file is part of SharpArchiver.
'
'    SharpArchiver is free software: you can redistribute it and/or modify
'    it under the terms of the GNU Lesser General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    SharpArchiver is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with SharpArchiver.  If not, see <http://www.gnu.org/licenses/>.
'
'


Imports System.Drawing
Imports System.Windows.Forms
Imports Cake3
Imports System.Timers
Imports System.Diagnostics


''' <summary>
''' Description of ProgressForm.
''' </summary>
Public Partial Class ProgressForm
	Inherits Form

	Private isShellExtension As Boolean = False
	Private isRun As Boolean = False
	Private file As String



	Public Sub New(isShellExtension As Boolean, isRun As Boolean, file As String)
		'
		' The InitializeComponent() call is required for Windows Forms designer support.
		'
		InitializeComponent()

		Me.isShellExtension = isShellExtension
		Me.isRun = isRun


			'
			' TODO: Add constructor code after the InitializeComponent() call.
			'
		Me.file = file
	End Sub

	Public Sub ProgressForm_Message(sender As Object, e As MessageEventArgs)
		If InvokeRequired Then
			Invoke(New MessageEventHandler(AddressOf ProgressForm_Message), New Object() {sender, e})
		Else

			Text = e.Message
		End If

	End Sub

	Public Sub ProgressForm_Progress(sender As Object, e As ProgressEventArgs)
		If InvokeRequired Then
			Invoke(New ProgressEventHandler(AddressOf ProgressForm_Progress), New Object() {sender, e})
		Else

			If (e.Percent >= 0) AndAlso (e.Percent <= 100) Then
				progressBar1.Value = e.Percent
			End If

			label1.Text = "Working on :" & Utils.ExtractFileName(e.Filename)



			timer1.[Stop]()
		End If
	End Sub

	Public Sub ProgressForm_StartWorking(sender As Object, e As EventArgs)
		If InvokeRequired Then
			Invoke(New EventHandler(AddressOf ProgressForm_StopWorking), New Object() {sender, e})
		Else
			progressBar1.Value = 0

			Text = "Starting"
		End If
	End Sub


	Public Sub ProgressForm_StopWorking(sender As Object, e As EventArgs)
		If InvokeRequired Then
			Invoke(New EventHandler(AddressOf ProgressForm_StopWorking), New Object() {sender, e})
		Else
			progressBar1.Value = 100
			Text = "Completed"


			AddHandler timer1.Tick, New EventHandler(AddressOf TimerTick)
			timer1.Interval = 1000




			timer1.Start()
		End If
	End Sub


	Public Sub addProgressForm_StopWorking(sender As Object, e As EventArgs)
		If InvokeRequired Then
			Invoke(New EventHandler(AddressOf addProgressForm_StopWorking), New Object() {sender, e})
		Else
			progressBar1.Value = 100
			Text = "Completed"

			AddHandler timer1.Tick, New EventHandler(AddressOf TimerTick)
			timer1.Interval = 1000
			timer1.Start()

			Dim mf As MainForm = TryCast(Application.OpenForms("MainForm"), MainForm)



            'mf.Invoke(New EventHandler(AddressOf mf.RefreshListtToolStripMenuItemClick), New [Object]() {sender, e})
        End If
	End Sub

	Public Sub deleteProgressForm_StopWorking(sender As Object, e As EventArgs)
		If InvokeRequired Then
			Invoke(New EventHandler(AddressOf addProgressForm_StopWorking), New Object() {sender, e})
		Else
			progressBar1.Value = 100
			Text = "Completed"

			AddHandler timer1.Tick, New EventHandler(AddressOf TimerTick)
			timer1.Interval = 1000
			timer1.Start()

			Dim mf As MainForm = TryCast(Application.OpenForms("MainForm"), MainForm)



            'mf.Invoke(New EventHandler(AddressOf mf.RefreshListtToolStripMenuItemClick), New [Object]() {sender, e})
        End If
	End Sub




	Private Sub TimerTick(sender As Object, e As EventArgs)
		timer1.[Stop]()
		Close()

		If isShellExtension Then
			Dim mf As MainForm = TryCast(Application.OpenForms("MainForm"), MainForm)
            'mf.Invoke(New EventHandler(AddressOf mf.ExitToolStripMenuItemClick), New [Object]() {sender, e})
        End If

		If isRun Then
			Try

				If Utils.ExtractFileExt(file) = ".exe" Then
					If MessageBox.Show("Executable files usually depend on other files within the archive are you shore you want to run this file? ", "SharpArchiver", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = DialogResult.Yes Then

						Process.Start(file)
					End If
				Else
					Process.Start(file)

				End If
			Catch
				MessageBox.Show("Unabel to run this file.Plese chek is the file assocciated with the appropriate program.", "SharpArchiver", MessageBoxButtons.OK, MessageBoxIcon.Information)

			End Try
		End If

	End Sub

End Class
