﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ZipBox
    Inherits Metro.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ZipBox))
        Me.RibbonUpDown1 = New System.Windows.Forms.RibbonUpDown()
        Me.RibbonOrbRecentItem1 = New System.Windows.Forms.RibbonOrbRecentItem()
        Me.RibbonOrbMenuItem1 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.RibbonOrbMenuItem2 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.RibbonOrbMenuItem3 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.RibbonTab1 = New System.Windows.Forms.RibbonTab()
        Me.RibbonPanel1 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonPanel2 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonPanel3 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonPanel4 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonTab2 = New System.Windows.Forms.RibbonTab()
        Me.RibbonTab3 = New System.Windows.Forms.RibbonTab()
        Me.RibbonColorChooser1 = New System.Windows.Forms.RibbonColorChooser()
        Me.RibbonButton1 = New System.Windows.Forms.RibbonButton()
        Me.RibbonButton2 = New System.Windows.Forms.RibbonButton()
        Me.RibbonButtonList1 = New System.Windows.Forms.RibbonButtonList()
        Me.RibbonOrbOptionButton1 = New System.Windows.Forms.RibbonOrbOptionButton()
        Me.RibbonButton3 = New System.Windows.Forms.RibbonButton()
        Me.RibbonTab4 = New System.Windows.Forms.RibbonTab()
        Me.RibbonSeparator1 = New System.Windows.Forms.RibbonSeparator()
        Me.RibbonOrbMenuItem4 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.RibbonTab5 = New System.Windows.Forms.RibbonTab()
        Me.RibbonPanel6 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonTab6 = New System.Windows.Forms.RibbonTab()
        Me.RibbonTab7 = New System.Windows.Forms.RibbonTab()
        Me.Ribbon1 = New System.Windows.Forms.Ribbon()
        Me.RibbonOrbMenuItem5 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.RibbonOrbMenuItem6 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.RibbonOrbMenuItem7 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.RibbonOrbMenuItem8 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.ribbonDescriptionMenuItem3 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem4 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem5 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem6 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem7 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem8 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.RibbonOrbMenuItem9 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.ribbonDescriptionMenuItem1 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem2 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem9 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem10 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem11 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem12 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.RibbonOrbMenuItem10 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.ribbonDescriptionMenuItem13 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem14 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem15 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem16 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem17 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem18 = New System.Windows.Forms.RibbonDescriptionMenuItem()
        Me.ribbonOrbMenuItem11 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.ribbonOrbMenuItem12 = New System.Windows.Forms.RibbonOrbMenuItem()
        Me.RibbonOrbOptionButton4 = New System.Windows.Forms.RibbonOrbOptionButton()
        Me.RibbonOrbOptionButton5 = New System.Windows.Forms.RibbonOrbOptionButton()
        Me.RibbonTab8 = New System.Windows.Forms.RibbonTab()
        Me.RibbonPanel5 = New System.Windows.Forms.RibbonPanel()
        Me.RBNButtonComprimir = New System.Windows.Forms.RibbonButton()
        Me.RBNButtonExtrair = New System.Windows.Forms.RibbonButton()
        Me.RibbonButton6 = New System.Windows.Forms.RibbonButton()
        Me.ExtractSelectedFiles = New System.Windows.Forms.RibbonButton()
        Me.ExtractAll = New System.Windows.Forms.RibbonButton()
        Me.ribbonButton33 = New System.Windows.Forms.RibbonButton()
        Me.ribbonButton34 = New System.Windows.Forms.RibbonButton()
        Me.ribbonButton35 = New System.Windows.Forms.RibbonButton()
        Me.RBTNTestar = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel8 = New System.Windows.Forms.RibbonPanel()
        Me.RBTNRemoveAll = New System.Windows.Forms.RibbonButton()
        Me.RibbonSeparator2 = New System.Windows.Forms.RibbonSeparator()
        Me.RBTNSelecionarTudo = New System.Windows.Forms.RibbonButton()
        Me.RBTNInfo = New System.Windows.Forms.RibbonButton()
        Me.ribbonPanel14 = New System.Windows.Forms.RibbonPanel()
        Me.RBTNScan = New System.Windows.Forms.RibbonButton()
        Me.RBTNSend = New System.Windows.Forms.RibbonButton()
        Me.RBTNBackup = New System.Windows.Forms.RibbonButton()
        Me.RBTNOpen = New System.Windows.Forms.RibbonButton()
        Me.RibbonTab9 = New System.Windows.Forms.RibbonTab()
        Me.ribbonPanel10 = New System.Windows.Forms.RibbonPanel()
        Me.RBTNConvertImage = New System.Windows.Forms.RibbonButton()
        Me.RBTNConvertDoc = New System.Windows.Forms.RibbonButton()
        Me.RBTNConvertVideo = New System.Windows.Forms.RibbonButton()
        Me.RBTNConvertAudio = New System.Windows.Forms.RibbonButton()
        Me.ribbonPanel11 = New System.Windows.Forms.RibbonPanel()
        Me.RBTNConvertFile = New System.Windows.Forms.RibbonButton()
        Me.RBTNConvertAll = New System.Windows.Forms.RibbonButton()
        Me.RBTNConversionSetting = New System.Windows.Forms.RibbonButton()
        Me.ribbonPanel15 = New System.Windows.Forms.RibbonPanel()
        Me.ribbonButton31 = New System.Windows.Forms.RibbonButton()
        Me.ribbonSeparator4 = New System.Windows.Forms.RibbonSeparator()
        Me.ribbonSeparator5 = New System.Windows.Forms.RibbonSeparator()
        Me.ribbonButton38 = New System.Windows.Forms.RibbonButton()
        Me.ribbonPanel16 = New System.Windows.Forms.RibbonPanel()
        Me.RBTNConverterFormato = New System.Windows.Forms.RibbonButton()
        Me.ribbonTab12 = New System.Windows.Forms.RibbonTab()
        Me.ribbonPanel9 = New System.Windows.Forms.RibbonPanel()
        Me.RBTNRemoveSecure = New System.Windows.Forms.RibbonButton()
        Me.RBTNOpenWith = New System.Windows.Forms.RibbonButton()
        Me.RBTNEncryptFile = New System.Windows.Forms.RibbonButton()
        Me.RBTNCreateSFX = New System.Windows.Forms.RibbonButton()
        Me.ribbonPanel12 = New System.Windows.Forms.RibbonPanel()
        Me.RBTNRemoverDuplicado = New System.Windows.Forms.RibbonButton()
        Me.RBTNRemoveDirectory = New System.Windows.Forms.RibbonButton()
        Me.ribbonButton25 = New System.Windows.Forms.RibbonButton()
        Me.ribbonPanel13 = New System.Windows.Forms.RibbonPanel()
        Me.RBTNOcultarArquivo = New System.Windows.Forms.RibbonButton()
        Me.RBTNCompressImage = New System.Windows.Forms.RibbonButton()
        Me.ribbonButton28 = New System.Windows.Forms.RibbonButton()
        Me.RibbonButton18 = New System.Windows.Forms.RibbonButton()
        Me.ribbonTab10 = New System.Windows.Forms.RibbonTab()
        Me.ribbonPanel17 = New System.Windows.Forms.RibbonPanel()
        Me.RBTNEmuleISO = New System.Windows.Forms.RibbonButton()
        Me.ribbonSeparator7 = New System.Windows.Forms.RibbonSeparator()
        Me.RBTNAddFAV = New System.Windows.Forms.RibbonButton()
        Me.ribbonSeparator8 = New System.Windows.Forms.RibbonSeparator()
        Me.RBTNViewFAV = New System.Windows.Forms.RibbonButton()
        Me.ribbonSeparator9 = New System.Windows.Forms.RibbonSeparator()
        Me.ribbonPanel18 = New System.Windows.Forms.RibbonPanel()
        Me.ribbonButton41 = New System.Windows.Forms.RibbonButton()
        Me.ribbonSeparator10 = New System.Windows.Forms.RibbonSeparator()
        Me.ribbonButton42 = New System.Windows.Forms.RibbonButton()
        Me.ribbonSeparator11 = New System.Windows.Forms.RibbonSeparator()
        Me.RBTNDividir = New System.Windows.Forms.RibbonButton()
        Me.ribbonSeparator12 = New System.Windows.Forms.RibbonSeparator()
        Me.RBTNJuntar = New System.Windows.Forms.RibbonButton()
        Me.ribbonPanel19 = New System.Windows.Forms.RibbonPanel()
        Me.ribbonButton45 = New System.Windows.Forms.RibbonButton()
        Me.ribbonButton46 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel20 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton47 = New System.Windows.Forms.RibbonButton()
        Me.RibbonButton17 = New System.Windows.Forms.RibbonButton()
        Me.RibbonTab11 = New System.Windows.Forms.RibbonTab()
        Me.RibbonPanel7 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton4 = New System.Windows.Forms.RibbonButton()
        Me.RibbonSeparator3 = New System.Windows.Forms.RibbonSeparator()
        Me.RibbonButton5 = New System.Windows.Forms.RibbonButton()
        Me.RibbonSeparator13 = New System.Windows.Forms.RibbonSeparator()
        Me.RibbonPanel21 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton11 = New System.Windows.Forms.RibbonButton()
        Me.RibbonSeparator16 = New System.Windows.Forms.RibbonSeparator()
        Me.RibbonPanel22 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton13 = New System.Windows.Forms.RibbonButton()
        Me.RibbonSeparator17 = New System.Windows.Forms.RibbonSeparator()
        Me.RibbonButton14 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel23 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonButton7 = New System.Windows.Forms.RibbonButton()
        Me.RibbonSeparator14 = New System.Windows.Forms.RibbonSeparator()
        Me.RibbonButton10 = New System.Windows.Forms.RibbonButton()
        Me.RibbonPanel24 = New System.Windows.Forms.RibbonPanel()
        Me.RibbonSeparator15 = New System.Windows.Forms.RibbonSeparator()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripProgressBar1 = New System.Windows.Forms.ToolStripProgressBar()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.RibbonOrbOptionButton2 = New System.Windows.Forms.RibbonOrbOptionButton()
        Me.RibbonOrbOptionButton3 = New System.Windows.Forms.RibbonOrbOptionButton()
        Me.listView1 = New WindowsFormsAero.ListView()
        Me.ColumnHeader0 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AbrirArquivoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AbrirComNotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopiarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ColarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelecionarTudoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1.SuspendLayout()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'RibbonUpDown1
        '
        Me.RibbonUpDown1.Name = "RibbonUpDown1"
        Me.RibbonUpDown1.TextBoxText = ""
        Me.RibbonUpDown1.TextBoxWidth = 50
        '
        'RibbonOrbRecentItem1
        '
        Me.RibbonOrbRecentItem1.Image = CType(resources.GetObject("RibbonOrbRecentItem1.Image"), System.Drawing.Image)
        Me.RibbonOrbRecentItem1.LargeImage = CType(resources.GetObject("RibbonOrbRecentItem1.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbRecentItem1.Name = "RibbonOrbRecentItem1"
        Me.RibbonOrbRecentItem1.SmallImage = CType(resources.GetObject("RibbonOrbRecentItem1.SmallImage"), System.Drawing.Image)
        '
        'RibbonOrbMenuItem1
        '
        Me.RibbonOrbMenuItem1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem1.Image = CType(resources.GetObject("RibbonOrbMenuItem1.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem1.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem1.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem1.Name = "RibbonOrbMenuItem1"
        Me.RibbonOrbMenuItem1.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem1.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem1.Text = "RibbonOrbMenuItem1"
        Me.RibbonOrbMenuItem1.ToolTip = "Clique Para Abrir Arquivo"
        '
        'RibbonOrbMenuItem2
        '
        Me.RibbonOrbMenuItem2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem2.Image = CType(resources.GetObject("RibbonOrbMenuItem2.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem2.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem2.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem2.Name = "RibbonOrbMenuItem2"
        Me.RibbonOrbMenuItem2.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem2.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem2.Text = "RibbonOrbMenuItem2"
        '
        'RibbonOrbMenuItem3
        '
        Me.RibbonOrbMenuItem3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem3.Image = CType(resources.GetObject("RibbonOrbMenuItem3.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem3.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem3.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem3.Name = "RibbonOrbMenuItem3"
        Me.RibbonOrbMenuItem3.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem3.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem3.Text = "RibbonOrbMenuItem3"
        '
        'RibbonTab1
        '
        Me.RibbonTab1.Name = "RibbonTab1"
        Me.RibbonTab1.Panels.Add(Me.RibbonPanel1)
        Me.RibbonTab1.Panels.Add(Me.RibbonPanel2)
        Me.RibbonTab1.Panels.Add(Me.RibbonPanel3)
        Me.RibbonTab1.Panels.Add(Me.RibbonPanel4)
        Me.RibbonTab1.Text = "RibbonTab1"
        Me.RibbonTab1.Visible = False
        '
        'RibbonPanel1
        '
        Me.RibbonPanel1.Name = "RibbonPanel1"
        Me.RibbonPanel1.Text = "RibbonPanel1"
        Me.RibbonPanel1.Visible = False
        '
        'RibbonPanel2
        '
        Me.RibbonPanel2.Name = "RibbonPanel2"
        Me.RibbonPanel2.Text = "RibbonPanel2"
        Me.RibbonPanel2.Visible = False
        '
        'RibbonPanel3
        '
        Me.RibbonPanel3.Name = "RibbonPanel3"
        Me.RibbonPanel3.Text = "RibbonPanel3"
        Me.RibbonPanel3.Visible = False
        '
        'RibbonPanel4
        '
        Me.RibbonPanel4.Name = "RibbonPanel4"
        Me.RibbonPanel4.Text = "RibbonPanel4"
        Me.RibbonPanel4.Visible = False
        '
        'RibbonTab2
        '
        Me.RibbonTab2.Name = "RibbonTab2"
        Me.RibbonTab2.Text = "RibbonTab2"
        Me.RibbonTab2.Visible = False
        '
        'RibbonTab3
        '
        Me.RibbonTab3.Name = "RibbonTab3"
        Me.RibbonTab3.Text = "RibbonTab3"
        Me.RibbonTab3.Visible = False
        '
        'RibbonColorChooser1
        '
        Me.RibbonColorChooser1.Color = System.Drawing.Color.Transparent
        Me.RibbonColorChooser1.Image = CType(resources.GetObject("RibbonColorChooser1.Image"), System.Drawing.Image)
        Me.RibbonColorChooser1.LargeImage = CType(resources.GetObject("RibbonColorChooser1.LargeImage"), System.Drawing.Image)
        Me.RibbonColorChooser1.Name = "RibbonColorChooser1"
        Me.RibbonColorChooser1.SmallImage = CType(resources.GetObject("RibbonColorChooser1.SmallImage"), System.Drawing.Image)
        '
        'RibbonButton1
        '
        Me.RibbonButton1.Image = CType(resources.GetObject("RibbonButton1.Image"), System.Drawing.Image)
        Me.RibbonButton1.LargeImage = CType(resources.GetObject("RibbonButton1.LargeImage"), System.Drawing.Image)
        Me.RibbonButton1.Name = "RibbonButton1"
        Me.RibbonButton1.SmallImage = CType(resources.GetObject("RibbonButton1.SmallImage"), System.Drawing.Image)
        '
        'RibbonButton2
        '
        Me.RibbonButton2.Image = CType(resources.GetObject("RibbonButton2.Image"), System.Drawing.Image)
        Me.RibbonButton2.LargeImage = CType(resources.GetObject("RibbonButton2.LargeImage"), System.Drawing.Image)
        Me.RibbonButton2.Name = "RibbonButton2"
        Me.RibbonButton2.SmallImage = CType(resources.GetObject("RibbonButton2.SmallImage"), System.Drawing.Image)
        '
        'RibbonButtonList1
        '
        Me.RibbonButtonList1.ButtonsSizeMode = System.Windows.Forms.RibbonElementSizeMode.Large
        Me.RibbonButtonList1.FlowToBottom = False
        Me.RibbonButtonList1.ItemsSizeInDropwDownMode = New System.Drawing.Size(7, 5)
        Me.RibbonButtonList1.Name = "RibbonButtonList1"
        '
        'RibbonOrbOptionButton1
        '
        Me.RibbonOrbOptionButton1.Image = CType(resources.GetObject("RibbonOrbOptionButton1.Image"), System.Drawing.Image)
        Me.RibbonOrbOptionButton1.LargeImage = CType(resources.GetObject("RibbonOrbOptionButton1.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbOptionButton1.Name = "RibbonOrbOptionButton1"
        Me.RibbonOrbOptionButton1.SmallImage = CType(resources.GetObject("RibbonOrbOptionButton1.SmallImage"), System.Drawing.Image)
        '
        'RibbonButton3
        '
        Me.RibbonButton3.Image = CType(resources.GetObject("RibbonButton3.Image"), System.Drawing.Image)
        Me.RibbonButton3.LargeImage = CType(resources.GetObject("RibbonButton3.LargeImage"), System.Drawing.Image)
        Me.RibbonButton3.Name = "RibbonButton3"
        Me.RibbonButton3.SmallImage = CType(resources.GetObject("RibbonButton3.SmallImage"), System.Drawing.Image)
        '
        'RibbonTab4
        '
        Me.RibbonTab4.Name = "RibbonTab4"
        Me.RibbonTab4.Text = Nothing
        '
        'RibbonSeparator1
        '
        Me.RibbonSeparator1.Name = "RibbonSeparator1"
        '
        'RibbonOrbMenuItem4
        '
        Me.RibbonOrbMenuItem4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem4.Image = CType(resources.GetObject("RibbonOrbMenuItem4.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem4.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem4.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem4.Name = "RibbonOrbMenuItem4"
        Me.RibbonOrbMenuItem4.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem4.SmallImage"), System.Drawing.Image)
        '
        'RibbonTab5
        '
        Me.RibbonTab5.Name = "RibbonTab5"
        Me.RibbonTab5.Panels.Add(Me.RibbonPanel6)
        Me.RibbonTab5.Text = "RibbonTab5"
        Me.RibbonTab5.Visible = False
        '
        'RibbonPanel6
        '
        Me.RibbonPanel6.Name = "RibbonPanel6"
        Me.RibbonPanel6.Text = "RibbonPanel6"
        Me.RibbonPanel6.Visible = False
        '
        'RibbonTab6
        '
        Me.RibbonTab6.Name = "RibbonTab6"
        Me.RibbonTab6.Text = "RibbonTab6"
        Me.RibbonTab6.Visible = False
        '
        'RibbonTab7
        '
        Me.RibbonTab7.Name = "RibbonTab7"
        Me.RibbonTab7.Text = "RibbonTab7"
        Me.RibbonTab7.Visible = False
        '
        'Ribbon1
        '
        Me.Ribbon1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Ribbon1.CaptionBarVisible = False
        Me.Ribbon1.Font = New System.Drawing.Font("Segoe UI", 11.25!)
        Me.Ribbon1.ForeColor = System.Drawing.Color.DarkGray
        Me.Ribbon1.Location = New System.Drawing.Point(2, 30)
        Me.Ribbon1.Minimized = False
        Me.Ribbon1.Name = "Ribbon1"
        '
        '
        '
        Me.Ribbon1.OrbDropDown.BorderRoundness = 8
        Me.Ribbon1.OrbDropDown.Location = New System.Drawing.Point(0, 0)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.RibbonOrbMenuItem5)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.RibbonOrbMenuItem6)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.RibbonOrbMenuItem7)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.RibbonOrbMenuItem8)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.RibbonOrbMenuItem9)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.RibbonOrbMenuItem10)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem11)
        Me.Ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem12)
        Me.Ribbon1.OrbDropDown.Name = ""
        Me.Ribbon1.OrbDropDown.OptionItems.Add(Me.RibbonOrbOptionButton4)
        Me.Ribbon1.OrbDropDown.OptionItems.Add(Me.RibbonOrbOptionButton5)
        Me.Ribbon1.OrbDropDown.Size = New System.Drawing.Size(527, 424)
        Me.Ribbon1.OrbDropDown.TabIndex = 0
        Me.Ribbon1.OrbStyle = System.Windows.Forms.RibbonOrbStyle.Office_2010
        Me.Ribbon1.OrbText = "File"
        Me.Ribbon1.RibbonTabFont = New System.Drawing.Font("Trebuchet MS", 9.0!)
        Me.Ribbon1.Size = New System.Drawing.Size(897, 174)
        Me.Ribbon1.TabIndex = 15
        Me.Ribbon1.Tabs.Add(Me.RibbonTab8)
        Me.Ribbon1.Tabs.Add(Me.RibbonTab9)
        Me.Ribbon1.Tabs.Add(Me.ribbonTab12)
        Me.Ribbon1.Tabs.Add(Me.ribbonTab10)
        Me.Ribbon1.Tabs.Add(Me.RibbonTab11)
        Me.Ribbon1.TabsMargin = New System.Windows.Forms.Padding(6, 2, 20, 0)
        Me.Ribbon1.TabSpacing = 3
        Me.Ribbon1.Text = "Ribbon1"
        Me.Ribbon1.ThemeColor = System.Windows.Forms.RibbonTheme.Black
        '
        'RibbonOrbMenuItem5
        '
        Me.RibbonOrbMenuItem5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem5.Image = CType(resources.GetObject("RibbonOrbMenuItem5.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem5.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem5.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem5.Name = "RibbonOrbMenuItem5"
        Me.RibbonOrbMenuItem5.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem5.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem5.Text = "Abrir Arquivo"
        '
        'RibbonOrbMenuItem6
        '
        Me.RibbonOrbMenuItem6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem6.Image = CType(resources.GetObject("RibbonOrbMenuItem6.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem6.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem6.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem6.Name = "RibbonOrbMenuItem6"
        Me.RibbonOrbMenuItem6.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem6.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem6.Text = "Vizualizar"
        '
        'RibbonOrbMenuItem7
        '
        Me.RibbonOrbMenuItem7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem7.Image = CType(resources.GetObject("RibbonOrbMenuItem7.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem7.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem7.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem7.Name = "RibbonOrbMenuItem7"
        Me.RibbonOrbMenuItem7.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem7.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem7.Text = "Procurar"
        '
        'RibbonOrbMenuItem8
        '
        Me.RibbonOrbMenuItem8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem8.DropDownItems.Add(Me.ribbonDescriptionMenuItem3)
        Me.RibbonOrbMenuItem8.DropDownItems.Add(Me.ribbonDescriptionMenuItem4)
        Me.RibbonOrbMenuItem8.DropDownItems.Add(Me.ribbonDescriptionMenuItem5)
        Me.RibbonOrbMenuItem8.DropDownItems.Add(Me.ribbonDescriptionMenuItem6)
        Me.RibbonOrbMenuItem8.DropDownItems.Add(Me.ribbonDescriptionMenuItem7)
        Me.RibbonOrbMenuItem8.DropDownItems.Add(Me.ribbonDescriptionMenuItem8)
        Me.RibbonOrbMenuItem8.Image = CType(resources.GetObject("RibbonOrbMenuItem8.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem8.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem8.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem8.Name = "RibbonOrbMenuItem8"
        Me.RibbonOrbMenuItem8.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem8.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem8.Style = System.Windows.Forms.RibbonButtonStyle.DropDown
        Me.RibbonOrbMenuItem8.Text = "Abrir Com"
        '
        'ribbonDescriptionMenuItem3
        '
        Me.ribbonDescriptionMenuItem3.DescriptionBounds = New System.Drawing.Rectangle(35, 24, 279, 28)
        Me.ribbonDescriptionMenuItem3.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem3.Image = CType(resources.GetObject("ribbonDescriptionMenuItem3.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem3.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem3.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem3.Name = "ribbonDescriptionMenuItem3"
        Me.ribbonDescriptionMenuItem3.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem3.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem3.Text = "ribbonDescriptionMenuItem3"
        '
        'ribbonDescriptionMenuItem4
        '
        Me.ribbonDescriptionMenuItem4.DescriptionBounds = New System.Drawing.Rectangle(35, 76, 279, 28)
        Me.ribbonDescriptionMenuItem4.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem4.Image = CType(resources.GetObject("ribbonDescriptionMenuItem4.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem4.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem4.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem4.Name = "ribbonDescriptionMenuItem4"
        Me.ribbonDescriptionMenuItem4.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem4.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem4.Text = "ribbonDescriptionMenuItem4"
        '
        'ribbonDescriptionMenuItem5
        '
        Me.ribbonDescriptionMenuItem5.DescriptionBounds = New System.Drawing.Rectangle(35, 128, 279, 28)
        Me.ribbonDescriptionMenuItem5.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem5.Image = CType(resources.GetObject("ribbonDescriptionMenuItem5.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem5.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem5.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem5.Name = "ribbonDescriptionMenuItem5"
        Me.ribbonDescriptionMenuItem5.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem5.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem5.Text = "ribbonDescriptionMenuItem5"
        '
        'ribbonDescriptionMenuItem6
        '
        Me.ribbonDescriptionMenuItem6.DescriptionBounds = New System.Drawing.Rectangle(35, 180, 279, 28)
        Me.ribbonDescriptionMenuItem6.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem6.Image = CType(resources.GetObject("ribbonDescriptionMenuItem6.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem6.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem6.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem6.Name = "ribbonDescriptionMenuItem6"
        Me.ribbonDescriptionMenuItem6.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem6.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem6.Text = "ribbonDescriptionMenuItem6"
        '
        'ribbonDescriptionMenuItem7
        '
        Me.ribbonDescriptionMenuItem7.DescriptionBounds = New System.Drawing.Rectangle(35, 232, 279, 28)
        Me.ribbonDescriptionMenuItem7.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem7.Image = CType(resources.GetObject("ribbonDescriptionMenuItem7.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem7.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem7.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem7.Name = "ribbonDescriptionMenuItem7"
        Me.ribbonDescriptionMenuItem7.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem7.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem7.Text = "ribbonDescriptionMenuItem7"
        '
        'ribbonDescriptionMenuItem8
        '
        Me.ribbonDescriptionMenuItem8.DescriptionBounds = New System.Drawing.Rectangle(35, 284, 279, 28)
        Me.ribbonDescriptionMenuItem8.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem8.Image = CType(resources.GetObject("ribbonDescriptionMenuItem8.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem8.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem8.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem8.Name = "ribbonDescriptionMenuItem8"
        Me.ribbonDescriptionMenuItem8.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem8.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem8.Text = "ribbonDescriptionMenuItem8"
        '
        'RibbonOrbMenuItem9
        '
        Me.RibbonOrbMenuItem9.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem9.DropDownItems.Add(Me.ribbonDescriptionMenuItem1)
        Me.RibbonOrbMenuItem9.DropDownItems.Add(Me.ribbonDescriptionMenuItem2)
        Me.RibbonOrbMenuItem9.DropDownItems.Add(Me.ribbonDescriptionMenuItem9)
        Me.RibbonOrbMenuItem9.DropDownItems.Add(Me.ribbonDescriptionMenuItem10)
        Me.RibbonOrbMenuItem9.DropDownItems.Add(Me.ribbonDescriptionMenuItem11)
        Me.RibbonOrbMenuItem9.DropDownItems.Add(Me.ribbonDescriptionMenuItem12)
        Me.RibbonOrbMenuItem9.Image = CType(resources.GetObject("RibbonOrbMenuItem9.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem9.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem9.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem9.Name = "RibbonOrbMenuItem9"
        Me.RibbonOrbMenuItem9.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem9.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem9.Style = System.Windows.Forms.RibbonButtonStyle.DropDown
        Me.RibbonOrbMenuItem9.Text = "Criar"
        '
        'ribbonDescriptionMenuItem1
        '
        Me.ribbonDescriptionMenuItem1.DescriptionBounds = New System.Drawing.Rectangle(35, 24, 279, 28)
        Me.ribbonDescriptionMenuItem1.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem1.Image = CType(resources.GetObject("ribbonDescriptionMenuItem1.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem1.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem1.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem1.Name = "ribbonDescriptionMenuItem1"
        Me.ribbonDescriptionMenuItem1.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem1.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem1.Text = "ribbonDescriptionMenuItem1"
        '
        'ribbonDescriptionMenuItem2
        '
        Me.ribbonDescriptionMenuItem2.DescriptionBounds = New System.Drawing.Rectangle(35, 76, 279, 28)
        Me.ribbonDescriptionMenuItem2.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem2.Image = CType(resources.GetObject("ribbonDescriptionMenuItem2.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem2.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem2.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem2.Name = "ribbonDescriptionMenuItem2"
        Me.ribbonDescriptionMenuItem2.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem2.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem2.Text = "ribbonDescriptionMenuItem2"
        '
        'ribbonDescriptionMenuItem9
        '
        Me.ribbonDescriptionMenuItem9.DescriptionBounds = New System.Drawing.Rectangle(35, 128, 279, 28)
        Me.ribbonDescriptionMenuItem9.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem9.Image = CType(resources.GetObject("ribbonDescriptionMenuItem9.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem9.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem9.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem9.Name = "ribbonDescriptionMenuItem9"
        Me.ribbonDescriptionMenuItem9.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem9.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem9.Text = "ribbonDescriptionMenuItem9"
        '
        'ribbonDescriptionMenuItem10
        '
        Me.ribbonDescriptionMenuItem10.DescriptionBounds = New System.Drawing.Rectangle(35, 180, 279, 28)
        Me.ribbonDescriptionMenuItem10.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem10.Image = CType(resources.GetObject("ribbonDescriptionMenuItem10.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem10.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem10.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem10.Name = "ribbonDescriptionMenuItem10"
        Me.ribbonDescriptionMenuItem10.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem10.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem10.Text = "ribbonDescriptionMenuItem10"
        '
        'ribbonDescriptionMenuItem11
        '
        Me.ribbonDescriptionMenuItem11.DescriptionBounds = New System.Drawing.Rectangle(35, 232, 279, 28)
        Me.ribbonDescriptionMenuItem11.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem11.Image = CType(resources.GetObject("ribbonDescriptionMenuItem11.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem11.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem11.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem11.Name = "ribbonDescriptionMenuItem11"
        Me.ribbonDescriptionMenuItem11.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem11.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem11.Text = "ribbonDescriptionMenuItem11"
        '
        'ribbonDescriptionMenuItem12
        '
        Me.ribbonDescriptionMenuItem12.DescriptionBounds = New System.Drawing.Rectangle(35, 284, 279, 28)
        Me.ribbonDescriptionMenuItem12.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem12.Image = CType(resources.GetObject("ribbonDescriptionMenuItem12.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem12.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem12.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem12.Name = "ribbonDescriptionMenuItem12"
        Me.ribbonDescriptionMenuItem12.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem12.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem12.Text = "ribbonDescriptionMenuItem12"
        '
        'RibbonOrbMenuItem10
        '
        Me.RibbonOrbMenuItem10.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.RibbonOrbMenuItem10.DropDownItems.Add(Me.ribbonDescriptionMenuItem13)
        Me.RibbonOrbMenuItem10.DropDownItems.Add(Me.ribbonDescriptionMenuItem14)
        Me.RibbonOrbMenuItem10.DropDownItems.Add(Me.ribbonDescriptionMenuItem15)
        Me.RibbonOrbMenuItem10.DropDownItems.Add(Me.ribbonDescriptionMenuItem16)
        Me.RibbonOrbMenuItem10.DropDownItems.Add(Me.ribbonDescriptionMenuItem17)
        Me.RibbonOrbMenuItem10.DropDownItems.Add(Me.ribbonDescriptionMenuItem18)
        Me.RibbonOrbMenuItem10.Image = CType(resources.GetObject("RibbonOrbMenuItem10.Image"), System.Drawing.Image)
        Me.RibbonOrbMenuItem10.LargeImage = CType(resources.GetObject("RibbonOrbMenuItem10.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem10.Name = "RibbonOrbMenuItem10"
        Me.RibbonOrbMenuItem10.SmallImage = CType(resources.GetObject("RibbonOrbMenuItem10.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbMenuItem10.Text = "Criptografar "
        '
        'ribbonDescriptionMenuItem13
        '
        Me.ribbonDescriptionMenuItem13.DescriptionBounds = New System.Drawing.Rectangle(0, 0, 0, 0)
        Me.ribbonDescriptionMenuItem13.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem13.Image = CType(resources.GetObject("ribbonDescriptionMenuItem13.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem13.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem13.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem13.Name = "ribbonDescriptionMenuItem13"
        Me.ribbonDescriptionMenuItem13.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem13.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem13.Text = "ribbonDescriptionMenuItem13"
        '
        'ribbonDescriptionMenuItem14
        '
        Me.ribbonDescriptionMenuItem14.DescriptionBounds = New System.Drawing.Rectangle(0, 0, 0, 0)
        Me.ribbonDescriptionMenuItem14.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem14.Image = CType(resources.GetObject("ribbonDescriptionMenuItem14.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem14.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem14.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem14.Name = "ribbonDescriptionMenuItem14"
        Me.ribbonDescriptionMenuItem14.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem14.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem14.Text = "ribbonDescriptionMenuItem14"
        '
        'ribbonDescriptionMenuItem15
        '
        Me.ribbonDescriptionMenuItem15.DescriptionBounds = New System.Drawing.Rectangle(0, 0, 0, 0)
        Me.ribbonDescriptionMenuItem15.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem15.Image = CType(resources.GetObject("ribbonDescriptionMenuItem15.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem15.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem15.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem15.Name = "ribbonDescriptionMenuItem15"
        Me.ribbonDescriptionMenuItem15.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem15.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem15.Text = "ribbonDescriptionMenuItem15"
        '
        'ribbonDescriptionMenuItem16
        '
        Me.ribbonDescriptionMenuItem16.DescriptionBounds = New System.Drawing.Rectangle(0, 0, 0, 0)
        Me.ribbonDescriptionMenuItem16.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem16.Image = CType(resources.GetObject("ribbonDescriptionMenuItem16.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem16.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem16.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem16.Name = "ribbonDescriptionMenuItem16"
        Me.ribbonDescriptionMenuItem16.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem16.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem16.Text = "ribbonDescriptionMenuItem16"
        '
        'ribbonDescriptionMenuItem17
        '
        Me.ribbonDescriptionMenuItem17.DescriptionBounds = New System.Drawing.Rectangle(0, 0, 0, 0)
        Me.ribbonDescriptionMenuItem17.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem17.Image = CType(resources.GetObject("ribbonDescriptionMenuItem17.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem17.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem17.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem17.Name = "ribbonDescriptionMenuItem17"
        Me.ribbonDescriptionMenuItem17.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem17.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem17.Text = "ribbonDescriptionMenuItem17"
        '
        'ribbonDescriptionMenuItem18
        '
        Me.ribbonDescriptionMenuItem18.DescriptionBounds = New System.Drawing.Rectangle(0, 0, 0, 0)
        Me.ribbonDescriptionMenuItem18.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem18.Image = CType(resources.GetObject("ribbonDescriptionMenuItem18.Image"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem18.LargeImage = CType(resources.GetObject("ribbonDescriptionMenuItem18.LargeImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem18.Name = "ribbonDescriptionMenuItem18"
        Me.ribbonDescriptionMenuItem18.SmallImage = CType(resources.GetObject("ribbonDescriptionMenuItem18.SmallImage"), System.Drawing.Image)
        Me.ribbonDescriptionMenuItem18.Text = "ribbonDescriptionMenuItem18"
        '
        'ribbonOrbMenuItem11
        '
        Me.ribbonOrbMenuItem11.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem11.Image = CType(resources.GetObject("ribbonOrbMenuItem11.Image"), System.Drawing.Image)
        Me.ribbonOrbMenuItem11.LargeImage = CType(resources.GetObject("ribbonOrbMenuItem11.LargeImage"), System.Drawing.Image)
        Me.ribbonOrbMenuItem11.Name = "ribbonOrbMenuItem11"
        Me.ribbonOrbMenuItem11.SmallImage = CType(resources.GetObject("ribbonOrbMenuItem11.SmallImage"), System.Drawing.Image)
        Me.ribbonOrbMenuItem11.Text = "ribbonOrbMenuItem11"
        '
        'ribbonOrbMenuItem12
        '
        Me.ribbonOrbMenuItem12.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem12.Image = CType(resources.GetObject("ribbonOrbMenuItem12.Image"), System.Drawing.Image)
        Me.ribbonOrbMenuItem12.LargeImage = CType(resources.GetObject("ribbonOrbMenuItem12.LargeImage"), System.Drawing.Image)
        Me.ribbonOrbMenuItem12.Name = "ribbonOrbMenuItem12"
        Me.ribbonOrbMenuItem12.SmallImage = CType(resources.GetObject("ribbonOrbMenuItem12.SmallImage"), System.Drawing.Image)
        Me.ribbonOrbMenuItem12.Text = "ribbonOrbMenuItem12"
        '
        'RibbonOrbOptionButton4
        '
        Me.RibbonOrbOptionButton4.Image = CType(resources.GetObject("RibbonOrbOptionButton4.Image"), System.Drawing.Image)
        Me.RibbonOrbOptionButton4.LargeImage = CType(resources.GetObject("RibbonOrbOptionButton4.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbOptionButton4.Name = "RibbonOrbOptionButton4"
        Me.RibbonOrbOptionButton4.SmallImage = CType(resources.GetObject("RibbonOrbOptionButton4.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbOptionButton4.Text = "Configurações"
        '
        'RibbonOrbOptionButton5
        '
        Me.RibbonOrbOptionButton5.Image = CType(resources.GetObject("RibbonOrbOptionButton5.Image"), System.Drawing.Image)
        Me.RibbonOrbOptionButton5.LargeImage = CType(resources.GetObject("RibbonOrbOptionButton5.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbOptionButton5.Name = "RibbonOrbOptionButton5"
        Me.RibbonOrbOptionButton5.SmallImage = CType(resources.GetObject("RibbonOrbOptionButton5.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbOptionButton5.Text = "Sobre"
        '
        'RibbonTab8
        '
        Me.RibbonTab8.Name = "RibbonTab8"
        Me.RibbonTab8.Panels.Add(Me.RibbonPanel5)
        Me.RibbonTab8.Panels.Add(Me.RibbonPanel8)
        Me.RibbonTab8.Panels.Add(Me.ribbonPanel14)
        Me.RibbonTab8.Text = "Compressão"
        '
        'RibbonPanel5
        '
        Me.RibbonPanel5.Items.Add(Me.RBNButtonComprimir)
        Me.RibbonPanel5.Items.Add(Me.RBNButtonExtrair)
        Me.RibbonPanel5.Items.Add(Me.RibbonButton6)
        Me.RibbonPanel5.Items.Add(Me.RBTNTestar)
        Me.RibbonPanel5.Name = "RibbonPanel5"
        Me.RibbonPanel5.Text = "Comprimir"
        '
        'RBNButtonComprimir
        '
        Me.RBNButtonComprimir.Image = CType(resources.GetObject("RBNButtonComprimir.Image"), System.Drawing.Image)
        Me.RBNButtonComprimir.LargeImage = CType(resources.GetObject("RBNButtonComprimir.LargeImage"), System.Drawing.Image)
        Me.RBNButtonComprimir.Name = "RBNButtonComprimir"
        Me.RBNButtonComprimir.SmallImage = CType(resources.GetObject("RBNButtonComprimir.SmallImage"), System.Drawing.Image)
        Me.RBNButtonComprimir.Text = "Compress File"
        '
        'RBNButtonExtrair
        '
        Me.RBNButtonExtrair.Image = CType(resources.GetObject("RBNButtonExtrair.Image"), System.Drawing.Image)
        Me.RBNButtonExtrair.LargeImage = CType(resources.GetObject("RBNButtonExtrair.LargeImage"), System.Drawing.Image)
        Me.RBNButtonExtrair.Name = "RBNButtonExtrair"
        Me.RBNButtonExtrair.SmallImage = CType(resources.GetObject("RBNButtonExtrair.SmallImage"), System.Drawing.Image)
        Me.RBNButtonExtrair.Text = "Extract File"
        '
        'RibbonButton6
        '
        Me.RibbonButton6.DropDownItems.Add(Me.ExtractSelectedFiles)
        Me.RibbonButton6.DropDownItems.Add(Me.ExtractAll)
        Me.RibbonButton6.DropDownItems.Add(Me.ribbonButton33)
        Me.RibbonButton6.DropDownItems.Add(Me.ribbonButton34)
        Me.RibbonButton6.DropDownItems.Add(Me.ribbonButton35)
        Me.RibbonButton6.Image = CType(resources.GetObject("RibbonButton6.Image"), System.Drawing.Image)
        Me.RibbonButton6.LargeImage = CType(resources.GetObject("RibbonButton6.LargeImage"), System.Drawing.Image)
        Me.RibbonButton6.Name = "RibbonButton6"
        Me.RibbonButton6.SmallImage = CType(resources.GetObject("RibbonButton6.SmallImage"), System.Drawing.Image)
        Me.RibbonButton6.Style = System.Windows.Forms.RibbonButtonStyle.DropDown
        Me.RibbonButton6.Text = "Extrair Comprimir Apenas"
        '
        'ExtractSelectedFiles
        '
        Me.ExtractSelectedFiles.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ExtractSelectedFiles.Image = CType(resources.GetObject("ExtractSelectedFiles.Image"), System.Drawing.Image)
        Me.ExtractSelectedFiles.LargeImage = CType(resources.GetObject("ExtractSelectedFiles.LargeImage"), System.Drawing.Image)
        Me.ExtractSelectedFiles.Name = "ExtractSelectedFiles"
        Me.ExtractSelectedFiles.SmallImage = CType(resources.GetObject("ExtractSelectedFiles.SmallImage"), System.Drawing.Image)
        Me.ExtractSelectedFiles.Text = "Apenas Selecionados"
        '
        'ExtractAll
        '
        Me.ExtractAll.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ExtractAll.Image = CType(resources.GetObject("ExtractAll.Image"), System.Drawing.Image)
        Me.ExtractAll.LargeImage = CType(resources.GetObject("ExtractAll.LargeImage"), System.Drawing.Image)
        Me.ExtractAll.Name = "ExtractAll"
        Me.ExtractAll.SmallImage = CType(resources.GetObject("ExtractAll.SmallImage"), System.Drawing.Image)
        Me.ExtractAll.Text = "Extrair Todos"
        '
        'ribbonButton33
        '
        Me.ribbonButton33.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonButton33.Image = CType(resources.GetObject("ribbonButton33.Image"), System.Drawing.Image)
        Me.ribbonButton33.LargeImage = CType(resources.GetObject("ribbonButton33.LargeImage"), System.Drawing.Image)
        Me.ribbonButton33.Name = "ribbonButton33"
        Me.ribbonButton33.SmallImage = CType(resources.GetObject("ribbonButton33.SmallImage"), System.Drawing.Image)
        Me.ribbonButton33.Text = "Arquivos Exceto Extensão"
        '
        'ribbonButton34
        '
        Me.ribbonButton34.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonButton34.Image = CType(resources.GetObject("ribbonButton34.Image"), System.Drawing.Image)
        Me.ribbonButton34.LargeImage = CType(resources.GetObject("ribbonButton34.LargeImage"), System.Drawing.Image)
        Me.ribbonButton34.Name = "ribbonButton34"
        Me.ribbonButton34.SmallImage = CType(resources.GetObject("ribbonButton34.SmallImage"), System.Drawing.Image)
        Me.ribbonButton34.Text = "ribbonButton34"
        '
        'ribbonButton35
        '
        Me.ribbonButton35.DropDownArrowDirection = System.Windows.Forms.RibbonArrowDirection.Left
        Me.ribbonButton35.Image = CType(resources.GetObject("ribbonButton35.Image"), System.Drawing.Image)
        Me.ribbonButton35.LargeImage = CType(resources.GetObject("ribbonButton35.LargeImage"), System.Drawing.Image)
        Me.ribbonButton35.Name = "ribbonButton35"
        Me.ribbonButton35.SmallImage = CType(resources.GetObject("ribbonButton35.SmallImage"), System.Drawing.Image)
        Me.ribbonButton35.Text = "ribbonButton35"
        '
        'RBTNTestar
        '
        Me.RBTNTestar.Image = CType(resources.GetObject("RBTNTestar.Image"), System.Drawing.Image)
        Me.RBTNTestar.LargeImage = CType(resources.GetObject("RBTNTestar.LargeImage"), System.Drawing.Image)
        Me.RBTNTestar.Name = "RBTNTestar"
        Me.RBTNTestar.SmallImage = CType(resources.GetObject("RBTNTestar.SmallImage"), System.Drawing.Image)
        Me.RBTNTestar.Text = "Test File"
        '
        'RibbonPanel8
        '
        Me.RibbonPanel8.Items.Add(Me.RBTNRemoveAll)
        Me.RibbonPanel8.Items.Add(Me.RibbonSeparator2)
        Me.RibbonPanel8.Items.Add(Me.RBTNSelecionarTudo)
        Me.RibbonPanel8.Items.Add(Me.RBTNInfo)
        Me.RibbonPanel8.Name = "RibbonPanel8"
        Me.RibbonPanel8.Text = ""
        '
        'RBTNRemoveAll
        '
        Me.RBTNRemoveAll.Image = CType(resources.GetObject("RBTNRemoveAll.Image"), System.Drawing.Image)
        Me.RBTNRemoveAll.LargeImage = CType(resources.GetObject("RBTNRemoveAll.LargeImage"), System.Drawing.Image)
        Me.RBTNRemoveAll.Name = "RBTNRemoveAll"
        Me.RBTNRemoveAll.SmallImage = CType(resources.GetObject("RBTNRemoveAll.SmallImage"), System.Drawing.Image)
        Me.RBTNRemoveAll.Text = "Delete All"
        '
        'RibbonSeparator2
        '
        Me.RibbonSeparator2.Name = "RibbonSeparator2"
        '
        'RBTNSelecionarTudo
        '
        Me.RBTNSelecionarTudo.Image = CType(resources.GetObject("RBTNSelecionarTudo.Image"), System.Drawing.Image)
        Me.RBTNSelecionarTudo.LargeImage = CType(resources.GetObject("RBTNSelecionarTudo.LargeImage"), System.Drawing.Image)
        Me.RBTNSelecionarTudo.Name = "RBTNSelecionarTudo"
        Me.RBTNSelecionarTudo.SmallImage = CType(resources.GetObject("RBTNSelecionarTudo.SmallImage"), System.Drawing.Image)
        Me.RBTNSelecionarTudo.Text = "Select All"
        '
        'RBTNInfo
        '
        Me.RBTNInfo.Image = CType(resources.GetObject("RBTNInfo.Image"), System.Drawing.Image)
        Me.RBTNInfo.LargeImage = CType(resources.GetObject("RBTNInfo.LargeImage"), System.Drawing.Image)
        Me.RBTNInfo.Name = "RBTNInfo"
        Me.RBTNInfo.SmallImage = CType(resources.GetObject("RBTNInfo.SmallImage"), System.Drawing.Image)
        Me.RBTNInfo.Text = "Information"
        '
        'ribbonPanel14
        '
        Me.ribbonPanel14.Items.Add(Me.RBTNScan)
        Me.ribbonPanel14.Items.Add(Me.RBTNSend)
        Me.ribbonPanel14.Items.Add(Me.RBTNBackup)
        Me.ribbonPanel14.Items.Add(Me.RBTNOpen)
        Me.ribbonPanel14.Name = "ribbonPanel14"
        Me.ribbonPanel14.Text = ""
        '
        'RBTNScan
        '
        Me.RBTNScan.Image = CType(resources.GetObject("RBTNScan.Image"), System.Drawing.Image)
        Me.RBTNScan.LargeImage = CType(resources.GetObject("RBTNScan.LargeImage"), System.Drawing.Image)
        Me.RBTNScan.Name = "RBTNScan"
        Me.RBTNScan.SmallImage = CType(resources.GetObject("RBTNScan.SmallImage"), System.Drawing.Image)
        Me.RBTNScan.Text = "Virus Scan"
        '
        'RBTNSend
        '
        Me.RBTNSend.Image = CType(resources.GetObject("RBTNSend.Image"), System.Drawing.Image)
        Me.RBTNSend.LargeImage = CType(resources.GetObject("RBTNSend.LargeImage"), System.Drawing.Image)
        Me.RBTNSend.Name = "RBTNSend"
        Me.RBTNSend.SmallImage = CType(resources.GetObject("RBTNSend.SmallImage"), System.Drawing.Image)
        Me.RBTNSend.Text = "Send With Email"
        '
        'RBTNBackup
        '
        Me.RBTNBackup.Image = CType(resources.GetObject("RBTNBackup.Image"), System.Drawing.Image)
        Me.RBTNBackup.LargeImage = CType(resources.GetObject("RBTNBackup.LargeImage"), System.Drawing.Image)
        Me.RBTNBackup.Name = "RBTNBackup"
        Me.RBTNBackup.SmallImage = CType(resources.GetObject("RBTNBackup.SmallImage"), System.Drawing.Image)
        Me.RBTNBackup.Text = "Auto Backup"
        '
        'RBTNOpen
        '
        Me.RBTNOpen.Image = CType(resources.GetObject("RBTNOpen.Image"), System.Drawing.Image)
        Me.RBTNOpen.LargeImage = CType(resources.GetObject("RBTNOpen.LargeImage"), System.Drawing.Image)
        Me.RBTNOpen.Name = "RBTNOpen"
        Me.RBTNOpen.SmallImage = CType(resources.GetObject("RBTNOpen.SmallImage"), System.Drawing.Image)
        Me.RBTNOpen.Text = "Open With"
        '
        'RibbonTab9
        '
        Me.RibbonTab9.Name = "RibbonTab9"
        Me.RibbonTab9.Panels.Add(Me.ribbonPanel10)
        Me.RibbonTab9.Panels.Add(Me.ribbonPanel11)
        Me.RibbonTab9.Panels.Add(Me.ribbonPanel15)
        Me.RibbonTab9.Panels.Add(Me.ribbonPanel16)
        Me.RibbonTab9.Text = "Converter"
        '
        'ribbonPanel10
        '
        Me.ribbonPanel10.Items.Add(Me.RBTNConvertImage)
        Me.ribbonPanel10.Items.Add(Me.RBTNConvertDoc)
        Me.ribbonPanel10.Items.Add(Me.RBTNConvertVideo)
        Me.ribbonPanel10.Items.Add(Me.RBTNConvertAudio)
        Me.ribbonPanel10.Name = "ribbonPanel10"
        Me.ribbonPanel10.Text = "Converter Documentos"
        '
        'RBTNConvertImage
        '
        Me.RBTNConvertImage.Image = CType(resources.GetObject("RBTNConvertImage.Image"), System.Drawing.Image)
        Me.RBTNConvertImage.LargeImage = CType(resources.GetObject("RBTNConvertImage.LargeImage"), System.Drawing.Image)
        Me.RBTNConvertImage.Name = "RBTNConvertImage"
        Me.RBTNConvertImage.SmallImage = CType(resources.GetObject("RBTNConvertImage.SmallImage"), System.Drawing.Image)
        Me.RBTNConvertImage.Text = "Picture Converter"
        '
        'RBTNConvertDoc
        '
        Me.RBTNConvertDoc.Image = CType(resources.GetObject("RBTNConvertDoc.Image"), System.Drawing.Image)
        Me.RBTNConvertDoc.LargeImage = CType(resources.GetObject("RBTNConvertDoc.LargeImage"), System.Drawing.Image)
        Me.RBTNConvertDoc.Name = "RBTNConvertDoc"
        Me.RBTNConvertDoc.SmallImage = CType(resources.GetObject("RBTNConvertDoc.SmallImage"), System.Drawing.Image)
        Me.RBTNConvertDoc.Text = "Doc Converter"
        '
        'RBTNConvertVideo
        '
        Me.RBTNConvertVideo.Image = CType(resources.GetObject("RBTNConvertVideo.Image"), System.Drawing.Image)
        Me.RBTNConvertVideo.LargeImage = CType(resources.GetObject("RBTNConvertVideo.LargeImage"), System.Drawing.Image)
        Me.RBTNConvertVideo.Name = "RBTNConvertVideo"
        Me.RBTNConvertVideo.SmallImage = CType(resources.GetObject("RBTNConvertVideo.SmallImage"), System.Drawing.Image)
        Me.RBTNConvertVideo.Text = "Converter Vídeo"
        '
        'RBTNConvertAudio
        '
        Me.RBTNConvertAudio.Image = CType(resources.GetObject("RBTNConvertAudio.Image"), System.Drawing.Image)
        Me.RBTNConvertAudio.LargeImage = CType(resources.GetObject("RBTNConvertAudio.LargeImage"), System.Drawing.Image)
        Me.RBTNConvertAudio.Name = "RBTNConvertAudio"
        Me.RBTNConvertAudio.SmallImage = CType(resources.GetObject("RBTNConvertAudio.SmallImage"), System.Drawing.Image)
        Me.RBTNConvertAudio.Text = "Converter Aúdio"
        '
        'ribbonPanel11
        '
        Me.ribbonPanel11.Items.Add(Me.RBTNConvertFile)
        Me.ribbonPanel11.Items.Add(Me.RBTNConvertAll)
        Me.ribbonPanel11.Items.Add(Me.RBTNConversionSetting)
        Me.ribbonPanel11.Name = "ribbonPanel11"
        Me.ribbonPanel11.Text = "Ferramentas de Conversão"
        '
        'RBTNConvertFile
        '
        Me.RBTNConvertFile.Image = CType(resources.GetObject("RBTNConvertFile.Image"), System.Drawing.Image)
        Me.RBTNConvertFile.LargeImage = CType(resources.GetObject("RBTNConvertFile.LargeImage"), System.Drawing.Image)
        Me.RBTNConvertFile.Name = "RBTNConvertFile"
        Me.RBTNConvertFile.SmallImage = CType(resources.GetObject("RBTNConvertFile.SmallImage"), System.Drawing.Image)
        Me.RBTNConvertFile.Text = "File Converter"
        '
        'RBTNConvertAll
        '
        Me.RBTNConvertAll.Image = CType(resources.GetObject("RBTNConvertAll.Image"), System.Drawing.Image)
        Me.RBTNConvertAll.LargeImage = CType(resources.GetObject("RBTNConvertAll.LargeImage"), System.Drawing.Image)
        Me.RBTNConvertAll.Name = "RBTNConvertAll"
        Me.RBTNConvertAll.SmallImage = CType(resources.GetObject("RBTNConvertAll.SmallImage"), System.Drawing.Image)
        Me.RBTNConvertAll.Text = "Converter All"
        '
        'RBTNConversionSetting
        '
        Me.RBTNConversionSetting.Image = CType(resources.GetObject("RBTNConversionSetting.Image"), System.Drawing.Image)
        Me.RBTNConversionSetting.LargeImage = CType(resources.GetObject("RBTNConversionSetting.LargeImage"), System.Drawing.Image)
        Me.RBTNConversionSetting.Name = "RBTNConversionSetting"
        Me.RBTNConversionSetting.SmallImage = CType(resources.GetObject("RBTNConversionSetting.SmallImage"), System.Drawing.Image)
        Me.RBTNConversionSetting.Text = "Conversion Setting"
        '
        'ribbonPanel15
        '
        Me.ribbonPanel15.Items.Add(Me.ribbonButton31)
        Me.ribbonPanel15.Items.Add(Me.ribbonSeparator4)
        Me.ribbonPanel15.Items.Add(Me.ribbonSeparator5)
        Me.ribbonPanel15.Items.Add(Me.ribbonButton38)
        Me.ribbonPanel15.Name = "ribbonPanel15"
        Me.ribbonPanel15.Text = "Opções de Conversão"
        '
        'ribbonButton31
        '
        Me.ribbonButton31.Image = CType(resources.GetObject("ribbonButton31.Image"), System.Drawing.Image)
        Me.ribbonButton31.LargeImage = CType(resources.GetObject("ribbonButton31.LargeImage"), System.Drawing.Image)
        Me.ribbonButton31.Name = "ribbonButton31"
        Me.ribbonButton31.SmallImage = CType(resources.GetObject("ribbonButton31.SmallImage"), System.Drawing.Image)
        Me.ribbonButton31.Text = "Converter Selected"
        '
        'ribbonSeparator4
        '
        Me.ribbonSeparator4.Name = "ribbonSeparator4"
        '
        'ribbonSeparator5
        '
        Me.ribbonSeparator5.Name = "ribbonSeparator5"
        '
        'ribbonButton38
        '
        Me.ribbonButton38.Image = CType(resources.GetObject("ribbonButton38.Image"), System.Drawing.Image)
        Me.ribbonButton38.LargeImage = CType(resources.GetObject("ribbonButton38.LargeImage"), System.Drawing.Image)
        Me.ribbonButton38.Name = "ribbonButton38"
        Me.ribbonButton38.SmallImage = CType(resources.GetObject("ribbonButton38.SmallImage"), System.Drawing.Image)
        Me.ribbonButton38.Text = "Force Format Conversion"
        '
        'ribbonPanel16
        '
        Me.ribbonPanel16.Items.Add(Me.RBTNConverterFormato)
        Me.ribbonPanel16.Name = "ribbonPanel16"
        Me.ribbonPanel16.Text = ""
        '
        'RBTNConverterFormato
        '
        Me.RBTNConverterFormato.Image = CType(resources.GetObject("RBTNConverterFormato.Image"), System.Drawing.Image)
        Me.RBTNConverterFormato.LargeImage = CType(resources.GetObject("RBTNConverterFormato.LargeImage"), System.Drawing.Image)
        Me.RBTNConverterFormato.Name = "RBTNConverterFormato"
        Me.RBTNConverterFormato.SmallImage = CType(resources.GetObject("RBTNConverterFormato.SmallImage"), System.Drawing.Image)
        Me.RBTNConverterFormato.Text = "Converter Formato"
        '
        'ribbonTab12
        '
        Me.ribbonTab12.Name = "ribbonTab12"
        Me.ribbonTab12.Panels.Add(Me.ribbonPanel9)
        Me.ribbonTab12.Panels.Add(Me.ribbonPanel12)
        Me.ribbonTab12.Panels.Add(Me.ribbonPanel13)
        Me.ribbonTab12.Text = "Ferramentas"
        '
        'ribbonPanel9
        '
        Me.ribbonPanel9.Items.Add(Me.RBTNRemoveSecure)
        Me.ribbonPanel9.Items.Add(Me.RBTNOpenWith)
        Me.ribbonPanel9.Items.Add(Me.RBTNEncryptFile)
        Me.ribbonPanel9.Items.Add(Me.RBTNCreateSFX)
        Me.ribbonPanel9.Name = "ribbonPanel9"
        Me.ribbonPanel9.Text = "Ferramentas"
        '
        'RBTNRemoveSecure
        '
        Me.RBTNRemoveSecure.Image = CType(resources.GetObject("RBTNRemoveSecure.Image"), System.Drawing.Image)
        Me.RBTNRemoveSecure.LargeImage = CType(resources.GetObject("RBTNRemoveSecure.LargeImage"), System.Drawing.Image)
        Me.RBTNRemoveSecure.Name = "RBTNRemoveSecure"
        Me.RBTNRemoveSecure.SmallImage = CType(resources.GetObject("RBTNRemoveSecure.SmallImage"), System.Drawing.Image)
        Me.RBTNRemoveSecure.Text = "Unlock And Destroy"
        '
        'RBTNOpenWith
        '
        Me.RBTNOpenWith.Image = CType(resources.GetObject("RBTNOpenWith.Image"), System.Drawing.Image)
        Me.RBTNOpenWith.LargeImage = CType(resources.GetObject("RBTNOpenWith.LargeImage"), System.Drawing.Image)
        Me.RBTNOpenWith.Name = "RBTNOpenWith"
        Me.RBTNOpenWith.SmallImage = CType(resources.GetObject("RBTNOpenWith.SmallImage"), System.Drawing.Image)
        Me.RBTNOpenWith.Text = "Open With"
        '
        'RBTNEncryptFile
        '
        Me.RBTNEncryptFile.Image = CType(resources.GetObject("RBTNEncryptFile.Image"), System.Drawing.Image)
        Me.RBTNEncryptFile.LargeImage = CType(resources.GetObject("RBTNEncryptFile.LargeImage"), System.Drawing.Image)
        Me.RBTNEncryptFile.Name = "RBTNEncryptFile"
        Me.RBTNEncryptFile.SmallImage = CType(resources.GetObject("RBTNEncryptFile.SmallImage"), System.Drawing.Image)
        Me.RBTNEncryptFile.Text = "File Encrypt"
        '
        'RBTNCreateSFX
        '
        Me.RBTNCreateSFX.Image = CType(resources.GetObject("RBTNCreateSFX.Image"), System.Drawing.Image)
        Me.RBTNCreateSFX.LargeImage = CType(resources.GetObject("RBTNCreateSFX.LargeImage"), System.Drawing.Image)
        Me.RBTNCreateSFX.Name = "RBTNCreateSFX"
        Me.RBTNCreateSFX.SmallImage = CType(resources.GetObject("RBTNCreateSFX.SmallImage"), System.Drawing.Image)
        Me.RBTNCreateSFX.Text = "Create SFX"
        '
        'ribbonPanel12
        '
        Me.ribbonPanel12.Items.Add(Me.RBTNRemoverDuplicado)
        Me.ribbonPanel12.Items.Add(Me.RBTNRemoveDirectory)
        Me.ribbonPanel12.Items.Add(Me.ribbonButton25)
        Me.ribbonPanel12.Name = "ribbonPanel12"
        Me.ribbonPanel12.Text = "Remover Arquivos Duplicados"
        '
        'RBTNRemoverDuplicado
        '
        Me.RBTNRemoverDuplicado.Image = CType(resources.GetObject("RBTNRemoverDuplicado.Image"), System.Drawing.Image)
        Me.RBTNRemoverDuplicado.LargeImage = CType(resources.GetObject("RBTNRemoverDuplicado.LargeImage"), System.Drawing.Image)
        Me.RBTNRemoverDuplicado.Name = "RBTNRemoverDuplicado"
        Me.RBTNRemoverDuplicado.SmallImage = CType(resources.GetObject("RBTNRemoverDuplicado.SmallImage"), System.Drawing.Image)
        Me.RBTNRemoverDuplicado.Text = "Check Duplicate Files"
        '
        'RBTNRemoveDirectory
        '
        Me.RBTNRemoveDirectory.Image = CType(resources.GetObject("RBTNRemoveDirectory.Image"), System.Drawing.Image)
        Me.RBTNRemoveDirectory.LargeImage = CType(resources.GetObject("RBTNRemoveDirectory.LargeImage"), System.Drawing.Image)
        Me.RBTNRemoveDirectory.Name = "RBTNRemoveDirectory"
        Me.RBTNRemoveDirectory.SmallImage = CType(resources.GetObject("RBTNRemoveDirectory.SmallImage"), System.Drawing.Image)
        Me.RBTNRemoveDirectory.Text = "Remove Null Directory"
        '
        'ribbonButton25
        '
        Me.ribbonButton25.Image = CType(resources.GetObject("ribbonButton25.Image"), System.Drawing.Image)
        Me.ribbonButton25.LargeImage = CType(resources.GetObject("ribbonButton25.LargeImage"), System.Drawing.Image)
        Me.ribbonButton25.Name = "ribbonButton25"
        Me.ribbonButton25.SmallImage = CType(resources.GetObject("ribbonButton25.SmallImage"), System.Drawing.Image)
        Me.ribbonButton25.Text = "check duplicate tablets"
        Me.ribbonButton25.TextAlignment = System.Windows.Forms.RibbonItem.RibbonItemTextAlignment.Right
        '
        'ribbonPanel13
        '
        Me.ribbonPanel13.Items.Add(Me.RBTNOcultarArquivo)
        Me.ribbonPanel13.Items.Add(Me.RBTNCompressImage)
        Me.ribbonPanel13.Items.Add(Me.ribbonButton28)
        Me.ribbonPanel13.Items.Add(Me.RibbonButton18)
        Me.ribbonPanel13.Name = "ribbonPanel13"
        Me.ribbonPanel13.Text = ""
        '
        'RBTNOcultarArquivo
        '
        Me.RBTNOcultarArquivo.Image = CType(resources.GetObject("RBTNOcultarArquivo.Image"), System.Drawing.Image)
        Me.RBTNOcultarArquivo.LargeImage = CType(resources.GetObject("RBTNOcultarArquivo.LargeImage"), System.Drawing.Image)
        Me.RBTNOcultarArquivo.Name = "RBTNOcultarArquivo"
        Me.RBTNOcultarArquivo.SmallImage = CType(resources.GetObject("RBTNOcultarArquivo.SmallImage"), System.Drawing.Image)
        Me.RBTNOcultarArquivo.Text = "Hide Files"
        '
        'RBTNCompressImage
        '
        Me.RBTNCompressImage.Image = CType(resources.GetObject("RBTNCompressImage.Image"), System.Drawing.Image)
        Me.RBTNCompressImage.LargeImage = CType(resources.GetObject("RBTNCompressImage.LargeImage"), System.Drawing.Image)
        Me.RBTNCompressImage.Name = "RBTNCompressImage"
        Me.RBTNCompressImage.SmallImage = CType(resources.GetObject("RBTNCompressImage.SmallImage"), System.Drawing.Image)
        Me.RBTNCompressImage.Text = "Compress Picture"
        '
        'ribbonButton28
        '
        Me.ribbonButton28.Image = CType(resources.GetObject("ribbonButton28.Image"), System.Drawing.Image)
        Me.ribbonButton28.LargeImage = CType(resources.GetObject("ribbonButton28.LargeImage"), System.Drawing.Image)
        Me.ribbonButton28.Name = "ribbonButton28"
        Me.ribbonButton28.SmallImage = CType(resources.GetObject("ribbonButton28.SmallImage"), System.Drawing.Image)
        Me.ribbonButton28.Text = "Open With Program"
        '
        'RibbonButton18
        '
        Me.RibbonButton18.Image = CType(resources.GetObject("RibbonButton18.Image"), System.Drawing.Image)
        Me.RibbonButton18.LargeImage = CType(resources.GetObject("RibbonButton18.LargeImage"), System.Drawing.Image)
        Me.RibbonButton18.Name = "RibbonButton18"
        Me.RibbonButton18.SmallImage = CType(resources.GetObject("RibbonButton18.SmallImage"), System.Drawing.Image)
        Me.RibbonButton18.Text = "Compare Files"
        '
        'ribbonTab10
        '
        Me.ribbonTab10.Name = "ribbonTab10"
        Me.ribbonTab10.Panels.Add(Me.ribbonPanel17)
        Me.ribbonTab10.Panels.Add(Me.ribbonPanel18)
        Me.ribbonTab10.Panels.Add(Me.ribbonPanel19)
        Me.ribbonTab10.Panels.Add(Me.RibbonPanel20)
        Me.ribbonTab10.Text = "Opções"
        '
        'ribbonPanel17
        '
        Me.ribbonPanel17.Items.Add(Me.RBTNEmuleISO)
        Me.ribbonPanel17.Items.Add(Me.ribbonSeparator7)
        Me.ribbonPanel17.Items.Add(Me.RBTNAddFAV)
        Me.ribbonPanel17.Items.Add(Me.ribbonSeparator8)
        Me.ribbonPanel17.Items.Add(Me.RBTNViewFAV)
        Me.ribbonPanel17.Items.Add(Me.ribbonSeparator9)
        Me.ribbonPanel17.Name = "ribbonPanel17"
        Me.ribbonPanel17.Text = ""
        '
        'RBTNEmuleISO
        '
        Me.RBTNEmuleISO.Image = CType(resources.GetObject("RBTNEmuleISO.Image"), System.Drawing.Image)
        Me.RBTNEmuleISO.LargeImage = CType(resources.GetObject("RBTNEmuleISO.LargeImage"), System.Drawing.Image)
        Me.RBTNEmuleISO.Name = "RBTNEmuleISO"
        Me.RBTNEmuleISO.SmallImage = CType(resources.GetObject("RBTNEmuleISO.SmallImage"), System.Drawing.Image)
        Me.RBTNEmuleISO.Text = "Emulate Iso Image"
        '
        'ribbonSeparator7
        '
        Me.ribbonSeparator7.Name = "ribbonSeparator7"
        '
        'RBTNAddFAV
        '
        Me.RBTNAddFAV.Image = CType(resources.GetObject("RBTNAddFAV.Image"), System.Drawing.Image)
        Me.RBTNAddFAV.LargeImage = CType(resources.GetObject("RBTNAddFAV.LargeImage"), System.Drawing.Image)
        Me.RBTNAddFAV.Name = "RBTNAddFAV"
        Me.RBTNAddFAV.SmallImage = CType(resources.GetObject("RBTNAddFAV.SmallImage"), System.Drawing.Image)
        Me.RBTNAddFAV.Text = "Add File to favorites"
        '
        'ribbonSeparator8
        '
        Me.ribbonSeparator8.Name = "ribbonSeparator8"
        '
        'RBTNViewFAV
        '
        Me.RBTNViewFAV.Image = CType(resources.GetObject("RBTNViewFAV.Image"), System.Drawing.Image)
        Me.RBTNViewFAV.LargeImage = CType(resources.GetObject("RBTNViewFAV.LargeImage"), System.Drawing.Image)
        Me.RBTNViewFAV.Name = "RBTNViewFAV"
        Me.RBTNViewFAV.SmallImage = CType(resources.GetObject("RBTNViewFAV.SmallImage"), System.Drawing.Image)
        Me.RBTNViewFAV.Text = "Favorites View"
        Me.RBTNViewFAV.TextAlignment = System.Windows.Forms.RibbonItem.RibbonItemTextAlignment.Center
        '
        'ribbonSeparator9
        '
        Me.ribbonSeparator9.Name = "ribbonSeparator9"
        '
        'ribbonPanel18
        '
        Me.ribbonPanel18.Items.Add(Me.ribbonButton41)
        Me.ribbonPanel18.Items.Add(Me.ribbonSeparator10)
        Me.ribbonPanel18.Items.Add(Me.ribbonButton42)
        Me.ribbonPanel18.Items.Add(Me.ribbonSeparator11)
        Me.ribbonPanel18.Items.Add(Me.RBTNDividir)
        Me.ribbonPanel18.Items.Add(Me.ribbonSeparator12)
        Me.ribbonPanel18.Items.Add(Me.RBTNJuntar)
        Me.ribbonPanel18.Name = "ribbonPanel18"
        Me.ribbonPanel18.Text = "Opções "
        '
        'ribbonButton41
        '
        Me.ribbonButton41.Image = CType(resources.GetObject("ribbonButton41.Image"), System.Drawing.Image)
        Me.ribbonButton41.LargeImage = CType(resources.GetObject("ribbonButton41.LargeImage"), System.Drawing.Image)
        Me.ribbonButton41.Name = "ribbonButton41"
        Me.ribbonButton41.SmallImage = CType(resources.GetObject("ribbonButton41.SmallImage"), System.Drawing.Image)
        Me.ribbonButton41.Text = "Create SFX"
        '
        'ribbonSeparator10
        '
        Me.ribbonSeparator10.Name = "ribbonSeparator10"
        '
        'ribbonButton42
        '
        Me.ribbonButton42.Image = CType(resources.GetObject("ribbonButton42.Image"), System.Drawing.Image)
        Me.ribbonButton42.LargeImage = CType(resources.GetObject("ribbonButton42.LargeImage"), System.Drawing.Image)
        Me.ribbonButton42.Name = "ribbonButton42"
        Me.ribbonButton42.SmallImage = CType(resources.GetObject("ribbonButton42.SmallImage"), System.Drawing.Image)
        Me.ribbonButton42.Text = "Send With FTP"
        '
        'ribbonSeparator11
        '
        Me.ribbonSeparator11.Name = "ribbonSeparator11"
        '
        'RBTNDividir
        '
        Me.RBTNDividir.Image = CType(resources.GetObject("RBTNDividir.Image"), System.Drawing.Image)
        Me.RBTNDividir.LargeImage = CType(resources.GetObject("RBTNDividir.LargeImage"), System.Drawing.Image)
        Me.RBTNDividir.Name = "RBTNDividir"
        Me.RBTNDividir.SmallImage = CType(resources.GetObject("RBTNDividir.SmallImage"), System.Drawing.Image)
        Me.RBTNDividir.Text = "Split Files"
        '
        'ribbonSeparator12
        '
        Me.ribbonSeparator12.Name = "ribbonSeparator12"
        '
        'RBTNJuntar
        '
        Me.RBTNJuntar.Image = CType(resources.GetObject("RBTNJuntar.Image"), System.Drawing.Image)
        Me.RBTNJuntar.LargeImage = CType(resources.GetObject("RBTNJuntar.LargeImage"), System.Drawing.Image)
        Me.RBTNJuntar.Name = "RBTNJuntar"
        Me.RBTNJuntar.SmallImage = CType(resources.GetObject("RBTNJuntar.SmallImage"), System.Drawing.Image)
        Me.RBTNJuntar.Text = "Join Files"
        '
        'ribbonPanel19
        '
        Me.ribbonPanel19.Items.Add(Me.ribbonButton45)
        Me.ribbonPanel19.Items.Add(Me.ribbonButton46)
        Me.ribbonPanel19.Name = "ribbonPanel19"
        Me.ribbonPanel19.Text = ""
        '
        'ribbonButton45
        '
        Me.ribbonButton45.Image = CType(resources.GetObject("ribbonButton45.Image"), System.Drawing.Image)
        Me.ribbonButton45.LargeImage = CType(resources.GetObject("ribbonButton45.LargeImage"), System.Drawing.Image)
        Me.ribbonButton45.Name = "ribbonButton45"
        Me.ribbonButton45.SmallImage = CType(resources.GetObject("ribbonButton45.SmallImage"), System.Drawing.Image)
        Me.ribbonButton45.Text = "Change Directory Icons"
        '
        'ribbonButton46
        '
        Me.ribbonButton46.Image = CType(resources.GetObject("ribbonButton46.Image"), System.Drawing.Image)
        Me.ribbonButton46.LargeImage = CType(resources.GetObject("ribbonButton46.LargeImage"), System.Drawing.Image)
        Me.ribbonButton46.Name = "ribbonButton46"
        Me.ribbonButton46.SmallImage = CType(resources.GetObject("ribbonButton46.SmallImage"), System.Drawing.Image)
        Me.ribbonButton46.Text = "Send With"
        '
        'RibbonPanel20
        '
        Me.RibbonPanel20.Items.Add(Me.RibbonButton47)
        Me.RibbonPanel20.Items.Add(Me.RibbonButton17)
        Me.RibbonPanel20.Name = "RibbonPanel20"
        Me.RibbonPanel20.Text = ""
        '
        'RibbonButton47
        '
        Me.RibbonButton47.Image = CType(resources.GetObject("RibbonButton47.Image"), System.Drawing.Image)
        Me.RibbonButton47.LargeImage = CType(resources.GetObject("RibbonButton47.LargeImage"), System.Drawing.Image)
        Me.RibbonButton47.Name = "RibbonButton47"
        Me.RibbonButton47.SmallImage = CType(resources.GetObject("RibbonButton47.SmallImage"), System.Drawing.Image)
        Me.RibbonButton47.Text = "Automatic Backup"
        '
        'RibbonButton17
        '
        Me.RibbonButton17.Image = CType(resources.GetObject("RibbonButton17.Image"), System.Drawing.Image)
        Me.RibbonButton17.LargeImage = CType(resources.GetObject("RibbonButton17.LargeImage"), System.Drawing.Image)
        Me.RibbonButton17.Name = "RibbonButton17"
        Me.RibbonButton17.SmallImage = CType(resources.GetObject("RibbonButton17.SmallImage"), System.Drawing.Image)
        Me.RibbonButton17.Text = "Rename List"
        '
        'RibbonTab11
        '
        Me.RibbonTab11.Name = "RibbonTab11"
        Me.RibbonTab11.Panels.Add(Me.RibbonPanel7)
        Me.RibbonTab11.Panels.Add(Me.RibbonPanel21)
        Me.RibbonTab11.Panels.Add(Me.RibbonPanel22)
        Me.RibbonTab11.Panels.Add(Me.RibbonPanel23)
        Me.RibbonTab11.Panels.Add(Me.RibbonPanel24)
        Me.RibbonTab11.Text = "ZipBox"
        '
        'RibbonPanel7
        '
        Me.RibbonPanel7.Items.Add(Me.RibbonButton4)
        Me.RibbonPanel7.Items.Add(Me.RibbonSeparator3)
        Me.RibbonPanel7.Items.Add(Me.RibbonButton5)
        Me.RibbonPanel7.Items.Add(Me.RibbonSeparator13)
        Me.RibbonPanel7.Name = "RibbonPanel7"
        Me.RibbonPanel7.Text = "RibbonPanel7"
        '
        'RibbonButton4
        '
        Me.RibbonButton4.Image = CType(resources.GetObject("RibbonButton4.Image"), System.Drawing.Image)
        Me.RibbonButton4.LargeImage = CType(resources.GetObject("RibbonButton4.LargeImage"), System.Drawing.Image)
        Me.RibbonButton4.Name = "RibbonButton4"
        Me.RibbonButton4.SmallImage = CType(resources.GetObject("RibbonButton4.SmallImage"), System.Drawing.Image)
        Me.RibbonButton4.Text = "Add Comment"
        '
        'RibbonSeparator3
        '
        Me.RibbonSeparator3.Name = "RibbonSeparator3"
        '
        'RibbonButton5
        '
        Me.RibbonButton5.Image = CType(resources.GetObject("RibbonButton5.Image"), System.Drawing.Image)
        Me.RibbonButton5.LargeImage = CType(resources.GetObject("RibbonButton5.LargeImage"), System.Drawing.Image)
        Me.RibbonButton5.Name = "RibbonButton5"
        Me.RibbonButton5.SmallImage = CType(resources.GetObject("RibbonButton5.SmallImage"), System.Drawing.Image)
        Me.RibbonButton5.Text = "Encrypt Files "
        '
        'RibbonSeparator13
        '
        Me.RibbonSeparator13.Name = "RibbonSeparator13"
        '
        'RibbonPanel21
        '
        Me.RibbonPanel21.Items.Add(Me.RibbonButton11)
        Me.RibbonPanel21.Items.Add(Me.RibbonSeparator16)
        Me.RibbonPanel21.Name = "RibbonPanel21"
        Me.RibbonPanel21.Text = "RibbonPanel21"
        '
        'RibbonButton11
        '
        Me.RibbonButton11.Image = CType(resources.GetObject("RibbonButton11.Image"), System.Drawing.Image)
        Me.RibbonButton11.LargeImage = CType(resources.GetObject("RibbonButton11.LargeImage"), System.Drawing.Image)
        Me.RibbonButton11.Name = "RibbonButton11"
        Me.RibbonButton11.SmallImage = CType(resources.GetObject("RibbonButton11.SmallImage"), System.Drawing.Image)
        Me.RibbonButton11.Text = "Search Similar images"
        '
        'RibbonSeparator16
        '
        Me.RibbonSeparator16.Name = "RibbonSeparator16"
        '
        'RibbonPanel22
        '
        Me.RibbonPanel22.Items.Add(Me.RibbonButton13)
        Me.RibbonPanel22.Items.Add(Me.RibbonSeparator17)
        Me.RibbonPanel22.Items.Add(Me.RibbonButton14)
        Me.RibbonPanel22.Name = "RibbonPanel22"
        Me.RibbonPanel22.Text = "RibbonPanel22"
        '
        'RibbonButton13
        '
        Me.RibbonButton13.Image = CType(resources.GetObject("RibbonButton13.Image"), System.Drawing.Image)
        Me.RibbonButton13.LargeImage = CType(resources.GetObject("RibbonButton13.LargeImage"), System.Drawing.Image)
        Me.RibbonButton13.Name = "RibbonButton13"
        Me.RibbonButton13.SmallImage = CType(resources.GetObject("RibbonButton13.SmallImage"), System.Drawing.Image)
        Me.RibbonButton13.Text = "Comprimir Imagens"
        '
        'RibbonSeparator17
        '
        Me.RibbonSeparator17.Name = "RibbonSeparator17"
        '
        'RibbonButton14
        '
        Me.RibbonButton14.Image = CType(resources.GetObject("RibbonButton14.Image"), System.Drawing.Image)
        Me.RibbonButton14.LargeImage = CType(resources.GetObject("RibbonButton14.LargeImage"), System.Drawing.Image)
        Me.RibbonButton14.Name = "RibbonButton14"
        Me.RibbonButton14.SmallImage = CType(resources.GetObject("RibbonButton14.SmallImage"), System.Drawing.Image)
        Me.RibbonButton14.Text = "Optimize Folder"
        '
        'RibbonPanel23
        '
        Me.RibbonPanel23.Items.Add(Me.RibbonButton7)
        Me.RibbonPanel23.Items.Add(Me.RibbonSeparator14)
        Me.RibbonPanel23.Items.Add(Me.RibbonButton10)
        Me.RibbonPanel23.Name = "RibbonPanel23"
        Me.RibbonPanel23.Text = "RibbonPanel23"
        '
        'RibbonButton7
        '
        Me.RibbonButton7.Image = CType(resources.GetObject("RibbonButton7.Image"), System.Drawing.Image)
        Me.RibbonButton7.LargeImage = CType(resources.GetObject("RibbonButton7.LargeImage"), System.Drawing.Image)
        Me.RibbonButton7.Name = "RibbonButton7"
        Me.RibbonButton7.SmallImage = CType(resources.GetObject("RibbonButton7.SmallImage"), System.Drawing.Image)
        Me.RibbonButton7.Text = "Compare Files And Folders"
        '
        'RibbonSeparator14
        '
        Me.RibbonSeparator14.Name = "RibbonSeparator14"
        '
        'RibbonButton10
        '
        Me.RibbonButton10.Image = CType(resources.GetObject("RibbonButton10.Image"), System.Drawing.Image)
        Me.RibbonButton10.LargeImage = CType(resources.GetObject("RibbonButton10.LargeImage"), System.Drawing.Image)
        Me.RibbonButton10.Name = "RibbonButton10"
        Me.RibbonButton10.SmallImage = CType(resources.GetObject("RibbonButton10.SmallImage"), System.Drawing.Image)
        Me.RibbonButton10.Text = "Organize Files And Folders"
        Me.RibbonButton10.ToolTip = "Organizador de arquivos que separa cada tipo de arquivo em uma pasta diferente de" &
    " acordo com a sua escolha"
        '
        'RibbonPanel24
        '
        Me.RibbonPanel24.Items.Add(Me.RibbonSeparator15)
        Me.RibbonPanel24.Name = "RibbonPanel24"
        Me.RibbonPanel24.Text = "RibbonPanel24"
        '
        'RibbonSeparator15
        '
        Me.RibbonSeparator15.Name = "RibbonSeparator15"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripProgressBar1, Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(2, 573)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(897, 22)
        Me.StatusStrip1.TabIndex = 16
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripProgressBar1
        '
        Me.ToolStripProgressBar1.Name = "ToolStripProgressBar1"
        Me.ToolStripProgressBar1.Size = New System.Drawing.Size(100, 16)
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(0, 17)
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(0, 17)
        '
        'RibbonOrbOptionButton2
        '
        Me.RibbonOrbOptionButton2.Image = CType(resources.GetObject("RibbonOrbOptionButton2.Image"), System.Drawing.Image)
        Me.RibbonOrbOptionButton2.LargeImage = CType(resources.GetObject("RibbonOrbOptionButton2.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbOptionButton2.Name = "RibbonOrbOptionButton2"
        Me.RibbonOrbOptionButton2.SmallImage = CType(resources.GetObject("RibbonOrbOptionButton2.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbOptionButton2.Text = "About"
        '
        'RibbonOrbOptionButton3
        '
        Me.RibbonOrbOptionButton3.Image = CType(resources.GetObject("RibbonOrbOptionButton3.Image"), System.Drawing.Image)
        Me.RibbonOrbOptionButton3.LargeImage = CType(resources.GetObject("RibbonOrbOptionButton3.LargeImage"), System.Drawing.Image)
        Me.RibbonOrbOptionButton3.Name = "RibbonOrbOptionButton3"
        Me.RibbonOrbOptionButton3.SmallImage = CType(resources.GetObject("RibbonOrbOptionButton3.SmallImage"), System.Drawing.Image)
        Me.RibbonOrbOptionButton3.Text = "Configurações"
        '
        'listView1
        '
        Me.listView1.BackColor = System.Drawing.Color.Silver
        Me.listView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.listView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader0, Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3})
        Me.listView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.listView1.ForeColor = System.Drawing.Color.DimGray
        Me.listView1.FullRowSelect = True
        Me.listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.listView1.LargeImageList = Me.imageList1
        Me.listView1.Location = New System.Drawing.Point(2, 204)
        Me.listView1.Name = "listView1"
        Me.listView1.Size = New System.Drawing.Size(897, 369)
        Me.listView1.SmallImageList = Me.imageList1
        Me.listView1.TabIndex = 18
        Me.listView1.UseCompatibleStateImageBehavior = False
        Me.listView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader0
        '
        Me.ColumnHeader0.Text = ""
        Me.ColumnHeader0.Width = 30
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Nome do Arquivo"
        Me.ColumnHeader1.Width = 200
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Tamanho"
        Me.ColumnHeader2.Width = 174
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Pasta"
        Me.ColumnHeader3.Width = 473
        '
        'imageList1
        '
        Me.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.imageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AbrirArquivoToolStripMenuItem, Me.AbrirComNotepadToolStripMenuItem, Me.CopiarToolStripMenuItem, Me.ColarToolStripMenuItem, Me.SelecionarTudoToolStripMenuItem})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(177, 114)
        '
        'AbrirArquivoToolStripMenuItem
        '
        Me.AbrirArquivoToolStripMenuItem.Name = "AbrirArquivoToolStripMenuItem"
        Me.AbrirArquivoToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.AbrirArquivoToolStripMenuItem.Text = "Abrir Arquivo"
        '
        'AbrirComNotepadToolStripMenuItem
        '
        Me.AbrirComNotepadToolStripMenuItem.Name = "AbrirComNotepadToolStripMenuItem"
        Me.AbrirComNotepadToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.AbrirComNotepadToolStripMenuItem.Text = "Abrir com Notepad"
        '
        'CopiarToolStripMenuItem
        '
        Me.CopiarToolStripMenuItem.Name = "CopiarToolStripMenuItem"
        Me.CopiarToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.CopiarToolStripMenuItem.Text = "Copiar"
        '
        'ColarToolStripMenuItem
        '
        Me.ColarToolStripMenuItem.Name = "ColarToolStripMenuItem"
        Me.ColarToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.ColarToolStripMenuItem.Text = "Colar"
        '
        'SelecionarTudoToolStripMenuItem
        '
        Me.SelecionarTudoToolStripMenuItem.Name = "SelecionarTudoToolStripMenuItem"
        Me.SelecionarTudoToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.SelecionarTudoToolStripMenuItem.Text = "Selecionar Tudo"
        '
        'ZipBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.ClientSize = New System.Drawing.Size(901, 597)
        Me.Controls.Add(Me.listView1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Ribbon1)
        Me.ForeColor = System.Drawing.Color.White
        Me.KeyPreview = True
        Me.Name = "ZipBox"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ZipBox"
        Me.Controls.SetChildIndex(Me.Ribbon1, 0)
        Me.Controls.SetChildIndex(Me.StatusStrip1, 0)
        Me.Controls.SetChildIndex(Me.listView1, 0)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private ribbonPanel19 As System.Windows.Forms.RibbonPanel
    Private imageList1 As System.Windows.Forms.ImageList
    Private ribbonSeparator12 As System.Windows.Forms.RibbonSeparator
    Private ribbonSeparator11 As System.Windows.Forms.RibbonSeparator
    Private ribbonSeparator10 As System.Windows.Forms.RibbonSeparator
    Private ribbonPanel18 As System.Windows.Forms.RibbonPanel
    Private ribbonSeparator9 As System.Windows.Forms.RibbonSeparator
    Private ribbonSeparator8 As System.Windows.Forms.RibbonSeparator
    Private ribbonSeparator7 As System.Windows.Forms.RibbonSeparator
    Private ribbonPanel17 As System.Windows.Forms.RibbonPanel
    Private ribbonTab10 As System.Windows.Forms.RibbonTab
    Private ribbonDescriptionMenuItem18 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem17 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem16 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem15 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem14 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem13 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem12 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem11 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem10 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem9 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem8 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem7 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem6 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem5 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem4 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem3 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonOrbMenuItem12 As System.Windows.Forms.RibbonOrbMenuItem
    Private ribbonOrbMenuItem11 As System.Windows.Forms.RibbonOrbMenuItem
    Private ribbonDescriptionMenuItem2 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonDescriptionMenuItem1 As System.Windows.Forms.RibbonDescriptionMenuItem
    Private ribbonPanel16 As System.Windows.Forms.RibbonPanel
    Private ribbonSeparator5 As System.Windows.Forms.RibbonSeparator
    Private ribbonSeparator4 As System.Windows.Forms.RibbonSeparator
    Private ribbonButton31 As System.Windows.Forms.RibbonButton
    Private ribbonButton35 As System.Windows.Forms.RibbonButton
    Private ribbonButton34 As System.Windows.Forms.RibbonButton
    Private ribbonButton33 As System.Windows.Forms.RibbonButton
    Private ribbonPanel15 As System.Windows.Forms.RibbonPanel
    Private ribbonPanel14 As System.Windows.Forms.RibbonPanel
    Private ribbonPanel13 As System.Windows.Forms.RibbonPanel
    Private ribbonPanel12 As System.Windows.Forms.RibbonPanel
    Private RBTNConversionSetting As System.Windows.Forms.RibbonButton
    Private ribbonPanel11 As System.Windows.Forms.RibbonPanel
    Private ribbonPanel10 As System.Windows.Forms.RibbonPanel
    Private ribbonTab12 As System.Windows.Forms.RibbonTab
    Private ribbonPanel9 As System.Windows.Forms.RibbonPanel
    Friend WithEvents RibbonUpDown1 As RibbonUpDown
    Friend WithEvents RibbonOrbRecentItem1 As RibbonOrbRecentItem
    Friend WithEvents RibbonOrbMenuItem1 As RibbonOrbMenuItem
    Friend WithEvents RibbonOrbMenuItem2 As RibbonOrbMenuItem
    Friend WithEvents RibbonOrbMenuItem3 As RibbonOrbMenuItem
    Friend WithEvents RibbonTab1 As RibbonTab
    Friend WithEvents RibbonPanel1 As RibbonPanel
    Friend WithEvents RibbonPanel2 As RibbonPanel
    Friend WithEvents RibbonTab2 As RibbonTab
    Friend WithEvents RibbonTab3 As RibbonTab
    Friend WithEvents RibbonColorChooser1 As RibbonColorChooser
    Friend WithEvents RibbonPanel3 As RibbonPanel
    Friend WithEvents RibbonButton1 As RibbonButton
    Friend WithEvents RibbonButton2 As RibbonButton
    Friend WithEvents RibbonButtonList1 As RibbonButtonList
    Friend WithEvents RibbonOrbOptionButton1 As RibbonOrbOptionButton
    Friend WithEvents RibbonButton3 As RibbonButton
    Friend WithEvents RibbonPanel4 As RibbonPanel
    Friend WithEvents RibbonTab4 As RibbonTab
    Friend WithEvents RibbonSeparator1 As RibbonSeparator
    Friend WithEvents RibbonOrbMenuItem4 As RibbonOrbMenuItem
    Friend WithEvents RibbonContext1 As RibbonContext
    Friend WithEvents RibbonContext2 As RibbonContext
    Friend WithEvents RibbonTab5 As RibbonTab
    Friend WithEvents RibbonTab6 As RibbonTab
    Friend WithEvents RibbonTab7 As RibbonTab
    Friend WithEvents RibbonPanel6 As RibbonPanel
    Friend WithEvents RibbonTab8 As RibbonTab
    Friend WithEvents RibbonPanel5 As RibbonPanel
    Friend WithEvents RibbonTab9 As RibbonTab
    Friend WithEvents RBNButtonExtrair As RibbonButton
    Friend WithEvents RibbonButton6 As RibbonButton
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents RibbonOrbMenuItem5 As RibbonOrbMenuItem
    Friend WithEvents RibbonOrbMenuItem6 As RibbonOrbMenuItem
    Friend WithEvents RibbonOrbMenuItem7 As RibbonOrbMenuItem
    Friend WithEvents RibbonOrbMenuItem8 As RibbonOrbMenuItem
    Friend WithEvents RibbonOrbMenuItem9 As RibbonOrbMenuItem
    Friend WithEvents RibbonOrbMenuItem10 As RibbonOrbMenuItem
    Friend WithEvents ExtractSelectedFiles As RibbonButton
    Friend WithEvents ExtractAll As RibbonButton
    Friend WithEvents RibbonOrbOptionButton2 As RibbonOrbOptionButton
    Friend WithEvents RibbonOrbOptionButton3 As RibbonOrbOptionButton
    Friend WithEvents RibbonPanel8 As RibbonPanel
    Friend WithEvents RibbonSeparator2 As RibbonSeparator
    Friend WithEvents RibbonOrbOptionButton4 As RibbonOrbOptionButton



    Friend WithEvents RibbonOrbOptionButton5 As RibbonOrbOptionButton
    Friend WithEvents RibbonPanel20 As RibbonPanel
    Public WithEvents RBTNDividir As RibbonButton
    Public WithEvents RBTNSend As RibbonButton
    Public WithEvents RBTNConvertDoc As RibbonButton
    Public WithEvents RBTNConvertImage As RibbonButton
    Public WithEvents RBTNConvertVideo As RibbonButton
    Public WithEvents RBTNCreateSFX As RibbonButton
    Public WithEvents RBTNEncryptFile As RibbonButton
    Public WithEvents RBTNConvertAudio As RibbonButton
    Public WithEvents RBNButtonComprimir As RibbonButton
    Public WithEvents Ribbon1 As Ribbon
    Friend WithEvents ToolStripProgressBar1 As ToolStripProgressBar
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Public WithEvents listView1 As WindowsFormsAero.ListView
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents ContextMenuStrip2 As ContextMenuStrip
    Friend WithEvents AbrirArquivoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AbrirComNotepadToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopiarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ColarToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SelecionarTudoToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ColumnHeader0 As ColumnHeader
    Friend WithEvents ColumnHeader1 As ColumnHeader
    Friend WithEvents ColumnHeader2 As ColumnHeader
    Friend WithEvents ColumnHeader3 As ColumnHeader
    Public WithEvents RBTNTestar As RibbonButton
    Public WithEvents RBTNSelecionarTudo As RibbonButton
    Public WithEvents RBTNInfo As RibbonButton
    Public WithEvents RBTNScan As RibbonButton
    Public WithEvents RBTNConvertAll As RibbonButton
    Public WithEvents RBTNConvertFile As RibbonButton
    Public WithEvents RBTNBackup As RibbonButton
    Public WithEvents ribbonButton38 As RibbonButton
    Public WithEvents RBTNConverterFormato As RibbonButton
    Public WithEvents RBTNOpenWith As RibbonButton
    Public WithEvents RBTNRemoveSecure As RibbonButton
    Public WithEvents RBTNRemoveDirectory As RibbonButton
    Public WithEvents RBTNRemoverDuplicado As RibbonButton
    Public WithEvents RBTNOcultarArquivo As RibbonButton
    Public WithEvents ribbonButton25 As RibbonButton
    Public WithEvents RBTNCompressImage As RibbonButton
    Public WithEvents RBTNEmuleISO As RibbonButton
    Public WithEvents ribbonButton28 As RibbonButton
    Public WithEvents ribbonButton46 As RibbonButton
    Public WithEvents ribbonButton45 As RibbonButton
    Public WithEvents RBTNJuntar As RibbonButton
    Public WithEvents ribbonButton42 As RibbonButton
    Public WithEvents ribbonButton41 As RibbonButton
    Public WithEvents RBTNViewFAV As RibbonButton
    Public WithEvents RBTNAddFAV As RibbonButton
    Public WithEvents RibbonButton47 As RibbonButton
    Friend WithEvents RibbonTab11 As RibbonTab
    Friend WithEvents RibbonPanel7 As RibbonPanel
    Friend WithEvents RibbonButton4 As RibbonButton
    Friend WithEvents RibbonSeparator3 As RibbonSeparator
    Friend WithEvents RibbonButton5 As RibbonButton
    Friend WithEvents RibbonSeparator13 As RibbonSeparator
    Friend WithEvents RibbonPanel21 As RibbonPanel
    Friend WithEvents RibbonButton11 As RibbonButton
    Friend WithEvents RibbonSeparator16 As RibbonSeparator
    Friend WithEvents RibbonPanel22 As RibbonPanel
    Friend WithEvents RibbonButton13 As RibbonButton
    Friend WithEvents RibbonSeparator17 As RibbonSeparator
    Friend WithEvents RibbonButton14 As RibbonButton
    Friend WithEvents RibbonPanel23 As RibbonPanel
    Friend WithEvents RibbonButton7 As RibbonButton
    Friend WithEvents RibbonSeparator14 As RibbonSeparator
    Friend WithEvents RibbonButton10 As RibbonButton
    Friend WithEvents RibbonPanel24 As RibbonPanel
    Friend WithEvents RibbonSeparator15 As RibbonSeparator
    Friend WithEvents RBTNOpen As RibbonButton
    Friend WithEvents RibbonButton18 As RibbonButton
    Friend WithEvents RibbonButton17 As RibbonButton
    Public WithEvents RBTNRemoveAll As RibbonButton
End Class
