﻿'Controlsoft Microsystems

Public Partial Class HiddenFiles
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub

    Public IsFileArchive, IsFolderPath As Boolean

    Private Sub GlassButton1_Click(sender As Object, e As EventArgs) Handles GlassButton1.Click

        Dim IsFile, isFolder As Boolean : IsFile = False : isFolder = False
        IsFile = CheckBoxFile.Checked
        isFolder = CheckBoxFolder.Checked

        If IsFile = True And isFolder = True Then
            MsgBox("Escolha Arquivo ou Pasta")
        End If

        If IsFile = True Then
            Try
                Dim FileBrowser As New OpenFileDialog()
                FileBrowser.Title = "Selecione o Arquivo Para Ocultar"
                FileBrowser.CheckFileExists = True
                FileBrowser.CheckPathExists = True
                FileBrowser.Multiselect = False
                FileBrowser.ShowDialog()

                TextBox1.Text = FileBrowser.FileName.ToString()
                IsFileArchive = True
                FileBrowser.Dispose()
            Catch Erro As Exception

            End Try

        ElseIf isFolder Then
            Try
                Dim FolderDialog As New FolderBrowserDialog()
                FolderDialog.RootFolder = Environment.GetFolderPath(Environment.SpecialFolder.MyComputer)
                FolderDialog.ShowDialog()
                TextBox1.Text = FolderDialog.SelectedPath.ToString()
                IsFolderPath = True
            Catch ErroEx As Exception
            End Try


        End If


    End Sub

    Private Sub HiddenFiles_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

        Catch ex As Exception
            MsgBox("Erro ao Carregar Formulário", MsgBoxStyle.Information)
        End Try
    End Sub

    Private Sub GlassButton4_Click(sender As Object, e As EventArgs) Handles GlassButton4.Click
        Try
            If IsFileArchive = True Then
                Dim Arquivo As String = TextBox1.Text
                IO.File.SetAttributes(Arquivo, IO.FileAttributes.Normal)

            ElseIf IsFolderPath = True Then
                Dim Path As String = TextBox1.Text
                IO.File.SetAttributes(Path, IO.FileAttributes.Normal)
            End If
        Catch Erro As Exception

        End Try

    End Sub

    Private Sub GlassButton3_Click(sender As Object, e As EventArgs) Handles GlassButton3.Click
        If IsFileArchive = True Then
            Try
                Dim Arquivo As String = TextBox1.Text
                IO.File.SetAttributes(Arquivo, IO.FileAttributes.Hidden)
            Catch Erro As Exception
                MsgBox("Erro ao Ocultar Arquivo " & Space(1) & Erro.Message.ToString())
            End Try
            Try

                Dim Folder As String = TextBox1.Text
                IO.File.SetAttributes(Folder, IO.FileAttributes.Hidden)
            Catch ErroPath As Exception
                MsgBox("Erro ao Ocultar Pasta" & Space(1) & ErroPath.Message.ToString())
            End Try

        End If
    End Sub
End Class
