﻿Public Class AutoBackup

    Dim m_Path As String
    Public Property Path As String
        Get
            Return m_Path
        End Get
        Set(value As String)
            m_Path = value
        End Set
    End Property

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private Sub GlassButton2_Click(sender As Object, e As EventArgs) Handles GlassButton2.Click
        Dim Folder As New FolderBrowserDialog()
        With Folder
            .Description = "Selecione a Pasta"
            .ShowNewFolderButton = False

            Try
                .ShowDialog()
                Dim Path As String = Folder.SelectedPath.ToString
                listView1.Items.Add(Path)

            Catch ex As Exception

            End Try
        End With


    End Sub

    Private Sub GlassButton3_Click(sender As Object, e As EventArgs) Handles GlassButton3.Click
        Try
            listView1.Items.Clear()

        Catch Erro As Exception
        End Try

    End Sub

    Private Sub GlassButton1_Click(sender As Object, e As EventArgs) Handles GlassButton1.Click

    End Sub
End Class