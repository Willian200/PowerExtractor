﻿'
' Created by SharpDevelop.
' User: joaopaulo
' Date: 13/01/2017
' Time: 06:31
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class FormSendFile
    Inherits Metro.Form
    ''' <summary>
    ''' Designer variable used to keep track of non-visual components.
    ''' </summary>
    Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.GGlowBox2 = New gGlowBox.gGlowBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GGlowBox3 = New gGlowBox.gGlowBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.GGlowBox4 = New gGlowBox.gGlowBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.GlassButton3 = New Glass.GlassButton()
        Me.GlassButton2 = New Glass.GlassButton()
        Me.GGlowBox6 = New gGlowBox.gGlowBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.GGlowBox7 = New gGlowBox.gGlowBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.GlassButton4 = New Glass.GlassButton()
        Me.GGlowBox1 = New gGlowBox.gGlowBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GGlowBox2.SuspendLayout()
        Me.GGlowBox3.SuspendLayout()
        Me.GGlowBox4.SuspendLayout()
        Me.GGlowBox6.SuspendLayout()
        Me.GGlowBox7.SuspendLayout()
        Me.GGlowBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GGlowBox2
        '
        Me.GGlowBox2.Controls.Add(Me.TextBox2)
        Me.GGlowBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GGlowBox2.ForeColor = System.Drawing.Color.Silver
        Me.GGlowBox2.Location = New System.Drawing.Point(21, 39)
        Me.GGlowBox2.Name = "GGlowBox2"
        Me.GGlowBox2.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox2.TabIndex = 16
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.ForeColor = System.Drawing.Color.Silver
        Me.TextBox2.Location = New System.Drawing.Point(4, 4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(353, 22)
        Me.TextBox2.TabIndex = 11
        Me.TextBox2.Text = "Email"
        '
        'GGlowBox3
        '
        Me.GGlowBox3.Controls.Add(Me.TextBox3)
        Me.GGlowBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GGlowBox3.ForeColor = System.Drawing.Color.Silver
        Me.GGlowBox3.Location = New System.Drawing.Point(21, 72)
        Me.GGlowBox3.Name = "GGlowBox3"
        Me.GGlowBox3.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox3.TabIndex = 17
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.ForeColor = System.Drawing.Color.Silver
        Me.TextBox3.Location = New System.Drawing.Point(4, 4)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(353, 22)
        Me.TextBox3.TabIndex = 11
        Me.TextBox3.Text = "Senha"
        '
        'GGlowBox4
        '
        Me.GGlowBox4.Controls.Add(Me.TextBox4)
        Me.GGlowBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GGlowBox4.ForeColor = System.Drawing.Color.Silver
        Me.GGlowBox4.Location = New System.Drawing.Point(21, 185)
        Me.GGlowBox4.Name = "GGlowBox4"
        Me.GGlowBox4.Size = New System.Drawing.Size(700, 247)
        Me.GGlowBox4.TabIndex = 18
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox4.ForeColor = System.Drawing.Color.Silver
        Me.TextBox4.Location = New System.Drawing.Point(4, 4)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(693, 240)
        Me.TextBox4.TabIndex = 11
        Me.TextBox4.Text = "Email"
        '
        'GlassButton3
        '
        Me.GlassButton3.Location = New System.Drawing.Point(29, 558)
        Me.GlassButton3.Name = "GlassButton3"
        Me.GlassButton3.Size = New System.Drawing.Size(124, 22)
        Me.GlassButton3.TabIndex = 19
        Me.GlassButton3.Text = "Enviar"
        '
        'GlassButton2
        '
        Me.GlassButton2.Location = New System.Drawing.Point(159, 558)
        Me.GlassButton2.Name = "GlassButton2"
        Me.GlassButton2.Size = New System.Drawing.Size(124, 22)
        Me.GlassButton2.TabIndex = 20
        Me.GlassButton2.Text = "Cancelar"
        '
        'GGlowBox6
        '
        Me.GGlowBox6.Controls.Add(Me.TextBox6)
        Me.GGlowBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GGlowBox6.ForeColor = System.Drawing.Color.Silver
        Me.GGlowBox6.Location = New System.Drawing.Point(21, 138)
        Me.GGlowBox6.Name = "GGlowBox6"
        Me.GGlowBox6.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox6.TabIndex = 23
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox6.ForeColor = System.Drawing.Color.Silver
        Me.TextBox6.Location = New System.Drawing.Point(4, 4)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(353, 22)
        Me.TextBox6.TabIndex = 11
        Me.TextBox6.Text = "Anexo"
        '
        'GGlowBox7
        '
        Me.GGlowBox7.Controls.Add(Me.TextBox7)
        Me.GGlowBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GGlowBox7.ForeColor = System.Drawing.Color.Silver
        Me.GGlowBox7.Location = New System.Drawing.Point(21, 105)
        Me.GGlowBox7.Name = "GGlowBox7"
        Me.GGlowBox7.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox7.TabIndex = 22
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox7.ForeColor = System.Drawing.Color.Silver
        Me.TextBox7.Location = New System.Drawing.Point(4, 4)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(353, 22)
        Me.TextBox7.TabIndex = 11
        Me.TextBox7.Text = "Titulo"
        '
        'GlassButton4
        '
        Me.GlassButton4.Location = New System.Drawing.Point(387, 142)
        Me.GlassButton4.Name = "GlassButton4"
        Me.GlassButton4.Size = New System.Drawing.Size(40, 23)
        Me.GlassButton4.TabIndex = 38
        Me.GlassButton4.Text = "..."
        '
        'GGlowBox1
        '
        Me.GGlowBox1.Controls.Add(Me.TextBox1)
        Me.GGlowBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GGlowBox1.ForeColor = System.Drawing.Color.Silver
        Me.GGlowBox1.Location = New System.Drawing.Point(21, 448)
        Me.GGlowBox1.Name = "GGlowBox1"
        Me.GGlowBox1.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox1.TabIndex = 39
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.ForeColor = System.Drawing.Color.Silver
        Me.TextBox1.Location = New System.Drawing.Point(4, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(353, 22)
        Me.TextBox1.TabIndex = 11
        Me.TextBox1.Text = "Enviar Para"
        '
        'FormSendFile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(754, 595)
        Me.Controls.Add(Me.GGlowBox1)
        Me.Controls.Add(Me.GlassButton4)
        Me.Controls.Add(Me.GGlowBox6)
        Me.Controls.Add(Me.GGlowBox7)
        Me.Controls.Add(Me.GlassButton2)
        Me.Controls.Add(Me.GlassButton3)
        Me.Controls.Add(Me.GGlowBox4)
        Me.Controls.Add(Me.GGlowBox3)
        Me.Controls.Add(Me.GGlowBox2)
        Me.ForeColor = System.Drawing.Color.DarkGray
        Me.MaximizeBox = False
        Me.Name = "FormSendFile"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Enviar Arquivo"
        Me.Controls.SetChildIndex(Me.GGlowBox2, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox3, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox4, 0)
        Me.Controls.SetChildIndex(Me.GlassButton3, 0)
        Me.Controls.SetChildIndex(Me.GlassButton2, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox7, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox6, 0)
        Me.Controls.SetChildIndex(Me.GlassButton4, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox1, 0)
        Me.GGlowBox2.ResumeLayout(False)
        Me.GGlowBox2.PerformLayout()
        Me.GGlowBox3.ResumeLayout(False)
        Me.GGlowBox3.PerformLayout()
        Me.GGlowBox4.ResumeLayout(False)
        Me.GGlowBox4.PerformLayout()
        Me.GGlowBox6.ResumeLayout(False)
        Me.GGlowBox6.PerformLayout()
        Me.GGlowBox7.ResumeLayout(False)
        Me.GGlowBox7.PerformLayout()
        Me.GGlowBox1.ResumeLayout(False)
        Me.GGlowBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GGlowBox1 As gGlowBox.gGlowBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GlassButton1 As Glass.GlassButton
    Friend WithEvents GGlowBox2 As gGlowBox.gGlowBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GGlowBox3 As gGlowBox.gGlowBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents GGlowBox4 As gGlowBox.gGlowBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents GlassButton3 As Glass.GlassButton
    Friend WithEvents GlassButton2 As Glass.GlassButton
    Friend WithEvents GGlowBox5 As gGlowBox.gGlowBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents GGlowBox6 As gGlowBox.gGlowBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents GGlowBox7 As gGlowBox.gGlowBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents GlassButton4 As Glass.GlassButton
End Class
