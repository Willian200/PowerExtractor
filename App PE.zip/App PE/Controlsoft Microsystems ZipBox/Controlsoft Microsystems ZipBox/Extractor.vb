﻿Public Class Extractor
    Private Sub Extractor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ProgressIndicator1.Visible = False
    End Sub
    Private Sub GlassButton1_Click(sender As Object, e As EventArgs) Handles GlassButton1.Click
        Dim FileBrowser As New OpenFileDialog()
        FileBrowser.Filter = "Supported Archives (*.shitloads)|*.7z;*.zip;*.rar;*.cab;*.ace;*.tar;*.gz;*.bz2;*.xz;*.wim;*.apm;*.arj;*.chm;*.cpio;*.deb;*.flv;*.jar;*.lha;*.lzh;*.lzma;*.rpm;*.swf;*.xar;*.z;*.iso;*.udf;*.vhd|All Files (*.*)|*.*"
        FileBrowser.CheckFileExists = True
        FileBrowser.CheckPathExists = True
        FileBrowser.Multiselect = False
        FileBrowser.ShowDialog()
        Try
            Dim Arquivo As String = FileBrowser.FileName
            TextBox1.Text = Arquivo
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub

    Private Sub GlassButton2_Click(sender As Object, e As EventArgs) Handles GlassButton2.Click

    End Sub

    Private Sub GlassButton3_Click(sender As Object, e As EventArgs) Handles GlassButton3.Click
        Dim SavePath As New FolderBrowserDialog()
        SavePath.Description = "Selecione a Pasta a Salvar"
        SavePath.ShowNewFolderButton = True
        SavePath.RootFolder = Environment.SpecialFolder.MyComputer
        Try
            SavePath.ShowDialog()
            Dim Path As String = SavePath.SelectedPath.ToString()
            TextBox2.Text = Path
        Catch ex As Exception

        End Try
    End Sub








End Class