﻿Public Class PictureConverter
    Private Sub GlassButton3_Click(sender As Object, e As EventArgs) Handles GlassButton3.Click
        Try
            ListBox1.Items.Clear()
        Catch Erro As Exception
        End Try

    End Sub

    Private Sub GlassButton1_Click(sender As Object, e As EventArgs) Handles GlassButton1.Click
        Dim Dialog As New OpenFileDialog()

        Dialog.CheckFileExists = True
        Dialog.Multiselect = True
        Dialog.CheckPathExists = True
        Dialog.Title = "Selecione a Imagem Para Converter"

        Dim Arquivos() As String = Dialog.FileNames

        Try
            For i = 1 To Arquivos.Length - 1
                ListBox1.Items.Add(Arquivos(i).ToString())

            Next
        Catch Erro As Exception
        End Try


    End Sub

    Private Sub GlassButton2_Click(sender As Object, e As EventArgs) Handles GlassButton2.Click
        Try
            ListBox1.Items.Remove(ListBox1.SelectedItem)
        Catch Erro As Exception

        End Try

    End Sub
    Public Sub ConvertImage(ByVal Filename As String,
  ByVal DesiredFormat As System.Drawing.Imaging.ImageFormat,
  ByVal NewFilename As String)
        ' Takes a filename and saves the file in a new format
        Try
            Dim imgFile As System.Drawing.Image =
      System.Drawing.Image.FromFile(Filename)
            imgFile.Save(NewFilename, DesiredFormat)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    ' 'Forma de uso = 
    ' ConvertImage("c:\img1.gif", _
    'System.Drawing.Imaging.ImageFormat.Bmp, _
    '"c:\img2.bmp")

    Private Sub GlassButton4_Click(sender As Object, e As EventArgs) Handles GlassButton4.Click

        'Falta Terminar
        Dim MultiploArquivo As Boolean
        If ListBox1.Items.Count > 1 Then
            MultiploArquivo = True

            For i = 1 To ListBox1.Items.Count - 1



            Next
        Else
            MultiploArquivo = False

        End If

        If MultiploArquivo = True Then

        Else

            'Então é um só Arquivo
            Dim FileName As String = ListBox1.SelectedItem.ToString()
            ConvertImage(FileName,
   System.Drawing.Imaging.ImageFormat.Bmp,
   "c:\img2.bmp")

        End If
    End Sub

    Private Sub GlassButton6_Click(sender As Object, e As EventArgs) Handles GlassButton6.Click
        Dim FolderBrowser As New FolderBrowserDialog()
        FolderBrowser.RootFolder = Environment.SpecialFolder.MyComputer
        FolderBrowser.ShowNewFolderButton = False
        FolderBrowser.ShowDialog()
        Try
            Dim NomePath As String = FolderBrowser.SelectedPath
            ListBox1.Items.Add(NomePath)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub GlassButton5_Click(sender As Object, e As EventArgs) Handles GlassButton5.Click
        Dim FileDialog As New OpenFileDialog()
        FileDialog.Multiselect = False
        FileDialog.CheckFileExists = True
        FileDialog.CheckPathExists = True
        FileDialog.ShowHelp = False
        FileDialog.Title = "Selecione o Arquivo de Imagem Para Converter"
        Try
            FileDialog.ShowDialog()

            Dim NomeArquivo As String = FileDialog.FileName
            TextBox1.Text = NomeArquivo
        Catch Erro As Exception
        End Try


    End Sub

    Private Sub GlassButton8_Click(sender As Object, e As EventArgs) Handles GlassButton8.Click
        Dim Path As New FolderBrowserDialog()
        Path.Description = "Selecione o Local a Salvar"
        Path.ShowNewFolderButton = True
        Path.RootFolder = Environment.SpecialFolder.MyPictures
        Try
            Path.ShowDialog()

            Dim Pasta As String = Path.SelectedPath
            TextBox2.Text = Pasta
        Catch ex As Exception

        End Try
    End Sub


End Class