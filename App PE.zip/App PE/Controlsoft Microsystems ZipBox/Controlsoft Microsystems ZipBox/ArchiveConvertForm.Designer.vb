'
'Copyright (c)  2008-2009,Domagoj Pintaric
'SharpArchiver is distributed under the terms of the GNU Lesser General Public License
'
'    This file is part of SharpArchiver.
'
'    SharpArchiver is free software: you can redistribute it and/or modify
'    it under the terms of the GNU Lesser General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    SharpArchiver is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with SharpArchiver.  If not, see <http://www.gnu.org/licenses/>.
'
'

Partial Class ArchiveConvertForm
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer = Nothing

	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ArchiveConvertForm))
        Me.button1 = New System.Windows.Forms.Button()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.radioButton4 = New System.Windows.Forms.RadioButton()
        Me.radioButton3 = New System.Windows.Forms.RadioButton()
        Me.radioButton2 = New System.Windows.Forms.RadioButton()
        Me.radioButton1 = New System.Windows.Forms.RadioButton()
        Me.label1 = New System.Windows.Forms.Label()
        Me.button2 = New System.Windows.Forms.Button()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.groupBox2 = New System.Windows.Forms.GroupBox()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button4 = New System.Windows.Forms.Button()
        Me.openFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.folderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.kryptonHeader1 = New ComponentFactory.Krypton.Toolkit.KryptonHeader()
        Me.groupBox1.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(234, 29)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(75, 23)
        Me.button1.TabIndex = 0
        Me.button1.Text = "Browse"
        Me.button1.UseVisualStyleBackColor = True
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(6, 31)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(222, 20)
        Me.textBox1.TabIndex = 1
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.radioButton4)
        Me.groupBox1.Controls.Add(Me.radioButton3)
        Me.groupBox1.Controls.Add(Me.radioButton2)
        Me.groupBox1.Controls.Add(Me.radioButton1)
        Me.groupBox1.Location = New System.Drawing.Point(12, 172)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(319, 52)
        Me.groupBox1.TabIndex = 2
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Convert To"
        '
        'radioButton4
        '
        Me.radioButton4.Location = New System.Drawing.Point(234, 19)
        Me.radioButton4.Name = "radioButton4"
        Me.radioButton4.Size = New System.Drawing.Size(70, 24)
        Me.radioButton4.TabIndex = 3
        Me.radioButton4.TabStop = True
        Me.radioButton4.Text = "Sqx"
        Me.radioButton4.UseVisualStyleBackColor = True
        '
        'radioButton3
        '
        Me.radioButton3.Location = New System.Drawing.Point(158, 19)
        Me.radioButton3.Name = "radioButton3"
        Me.radioButton3.Size = New System.Drawing.Size(70, 24)
        Me.radioButton3.TabIndex = 2
        Me.radioButton3.TabStop = True
        Me.radioButton3.Text = "Lha"
        Me.radioButton3.UseVisualStyleBackColor = True
        '
        'radioButton2
        '
        Me.radioButton2.Location = New System.Drawing.Point(82, 19)
        Me.radioButton2.Name = "radioButton2"
        Me.radioButton2.Size = New System.Drawing.Size(70, 24)
        Me.radioButton2.TabIndex = 1
        Me.radioButton2.TabStop = True
        Me.radioButton2.Text = "7Zip"
        Me.radioButton2.UseVisualStyleBackColor = True
        '
        'radioButton1
        '
        Me.radioButton1.Location = New System.Drawing.Point(6, 19)
        Me.radioButton1.Name = "radioButton1"
        Me.radioButton1.Size = New System.Drawing.Size(70, 24)
        Me.radioButton1.TabIndex = 0
        Me.radioButton1.TabStop = True
        Me.radioButton1.Text = "Zip"
        Me.radioButton1.UseVisualStyleBackColor = True
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(6, 16)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(173, 12)
        Me.label1.TabIndex = 3
        Me.label1.Text = "Open File"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(234, 67)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(75, 23)
        Me.button2.TabIndex = 4
        Me.button2.Text = "Browse"
        Me.button2.UseVisualStyleBackColor = True
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(6, 69)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(222, 20)
        Me.textBox2.TabIndex = 5
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(6, 54)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(207, 12)
        Me.label2.TabIndex = 6
        Me.label2.Text = "Save To"
        '
        'groupBox2
        '
        Me.groupBox2.Controls.Add(Me.label1)
        Me.groupBox2.Controls.Add(Me.label2)
        Me.groupBox2.Controls.Add(Me.button1)
        Me.groupBox2.Controls.Add(Me.textBox2)
        Me.groupBox2.Controls.Add(Me.textBox1)
        Me.groupBox2.Controls.Add(Me.button2)
        Me.groupBox2.Location = New System.Drawing.Point(12, 67)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(319, 99)
        Me.groupBox2.TabIndex = 7
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "File Options"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(256, 238)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(75, 23)
        Me.button3.TabIndex = 8
        Me.button3.Text = "Cancel"
        Me.button3.UseVisualStyleBackColor = True
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(175, 238)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(75, 23)
        Me.button4.TabIndex = 9
        Me.button4.Text = "Convert"
        Me.button4.UseVisualStyleBackColor = True
        '
        'openFileDialog1
        '
        Me.openFileDialog1.FileName = "openFileDialog1"
        '
        'kryptonHeader1
        '
        Me.kryptonHeader1.AutoSize = False
        Me.kryptonHeader1.Dock = System.Windows.Forms.DockStyle.Top
        Me.kryptonHeader1.Location = New System.Drawing.Point(0, 0)
        Me.kryptonHeader1.Name = "kryptonHeader1"
        Me.kryptonHeader1.Size = New System.Drawing.Size(345, 61)
        Me.kryptonHeader1.TabIndex = 10
        Me.kryptonHeader1.Text = "Convert Archive Tool"
        Me.kryptonHeader1.Values.Description = ""
        Me.kryptonHeader1.Values.Heading = "Convert Archive Tool"
        Me.kryptonHeader1.Values.Image = CType(resources.GetObject("kryptonHeader1.Values.Image"), System.Drawing.Image)
        '
        'ArchiveConvertForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(345, 268)
        Me.ControlBox = False
        Me.Controls.Add(Me.kryptonHeader1)
        Me.Controls.Add(Me.button4)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.groupBox2)
        Me.Controls.Add(Me.groupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ArchiveConvertForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "SharpArchiver"
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private folderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
	Private openFileDialog1 As System.Windows.Forms.OpenFileDialog
	Private button4 As System.Windows.Forms.Button
	Private button3 As System.Windows.Forms.Button
	Private groupBox2 As System.Windows.Forms.GroupBox
	Private label2 As System.Windows.Forms.Label
	Private textBox2 As System.Windows.Forms.TextBox
	Private button2 As System.Windows.Forms.Button
	Private label1 As System.Windows.Forms.Label
	Private radioButton1 As System.Windows.Forms.RadioButton
	Private radioButton2 As System.Windows.Forms.RadioButton
	Private radioButton3 As System.Windows.Forms.RadioButton
	Private radioButton4 As System.Windows.Forms.RadioButton
	Private groupBox1 As System.Windows.Forms.GroupBox
	Private textBox1 As System.Windows.Forms.TextBox
	Private button1 As System.Windows.Forms.Button
	Private kryptonHeader1 As ComponentFactory.Krypton.Toolkit.KryptonHeader
End Class
