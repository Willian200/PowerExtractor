'
'Copyright (c)  2008-2009,Domagoj Pintaric
'SharpArchiver is distributed under the terms of the GNU Lesser General Public License
'
'    This file is part of SharpArchiver.
'
'    SharpArchiver is free software: you can redistribute it and/or modify
'    it under the terms of the GNU Lesser General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    SharpArchiver is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with SharpArchiver.  If not, see <http://www.gnu.org/licenses/>.
'
'


Imports System.Drawing
Imports System.Windows.Forms
Imports System.IO
Imports Cake3
Imports System.Collections.Generic

''' <summary>
''' Description of MultiExtractForm.
''' </summary>
Public Partial Class MultiExtractForm
	Inherits Form
	Public Sub New()
		'
		' The InitializeComponent() call is required for Windows Forms designer support.
		'

			'
			' TODO: Add constructor code after the InitializeComponent() call.
			'
		InitializeComponent()
	End Sub

	'Add File
	Private Sub Button1Click(sender As Object, e As EventArgs)
		openFileDialog1.Filter = "All Supported Files|*.zip;*.7z;*.tar;*.gz;*.bz2;*.arc;*.arj;*.asd;*.ace;*.mime;*.b64;*.bel;*.deb;*.yz1;*.f;*.frz;*.icl;*.ico;*.cab;*.jam;*.lha;*.lzh;*.lzs;*.hqx;*.cpt;*.dmg;*.pit;*.pak;*.wad;*.rar;*.rpm;*.sqx;*.macbin;*.cpio;*.shar;*.uue;*.xxe;*.imp;*.yenc;*.zoo;*.ear;*.jar;*.war;*.wsz;*.mskin;*.bzs;*.wal;*.wmz"
		openFileDialog1.Title = "Open Archive"
		If openFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
			Dim fileItem As New ListViewItem()

			fileItem.Text = Utils.ExtractFileName(openFileDialog1.FileName)

			Dim fileInfo As New FileInfo(openFileDialog1.FileName)
			fileItem.SubItems.Add(fileInfo.Length.ToString() & "kb")

			fileItem.SubItems.Add(Utils.ExtractFilePath(openFileDialog1.FileName))

			listView1.Items.Insert(listView1.Items.Count, fileItem)
			imageList1.Images.Add(Utils.GetSmallFileIcon(openFileDialog1.FileName).ToBitmap())


			listView1.Items(listView1.Items.Count - 1).ImageIndex = listView1.Items.Count - 1
		End If

	End Sub

	'Remove File
	Private Sub Button2Click(sender As Object, e As EventArgs)
		Dim mySelection As New ListView.SelectedListViewItemCollection(listView1)
		For Each myItem As ListViewItem In mySelection
			myItem.Remove()
		Next
	End Sub

	'Extrct To
	Private Sub Button3Click(sender As Object, e As EventArgs)
		If folderBrowserDialog1.ShowDialog() = DialogResult.OK Then
			textBox1.Text = folderBrowserDialog1.SelectedPath
		End If

	End Sub

	'Extract
	Private Sub Button4Click(sender As Object, e As EventArgs)
		If listView1.Items.Count <> 0 Then

			If textBox1.Text <> "" Then

				Dim wi As New WorkItem(False, False, "")
				Dim selection As New ListView.ListViewItemCollection(listView1)
				For Each myItem As ListViewItem In selection
					Dim selectionList As New List(Of String)()
					Dim c3 As New Cakdir3(myItem.SubItems(2).Text & "\" & myItem.SubItems(0).Text)
					c3.List()

					For Each ct As ContentType In c3.Archive_Contents
						selectionList.Add(ct.fileName)
					Next

					wi.Extract(myItem.SubItems(2).Text & "\" & myItem.SubItems(0).Text, textBox1.Text, checkBox1.Checked, checkBox2.Checked, selectionList.ToArray())
				Next
				Close()
			Else
				MessageBox.Show(Me, "Extract folder is not specified", "SharpArchiver", MessageBoxButtons.OK, MessageBoxIcon.Information)

			End If
		Else
			MessageBox.Show(Me, "Please add a file", "SharpArchiver", MessageBoxButtons.OK, MessageBoxIcon.Information)
		End If


	End Sub

	'Cancel
	Private Sub Button5Click(sender As Object, e As EventArgs)
		Me.Close()
	End Sub
End Class
