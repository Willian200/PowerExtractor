﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DocumentConvert
    Inherits Metro.Form
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GGlowBox1 = New gGlowBox.gGlowBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GlassButton1 = New Glass.GlassButton()
        Me.GGlowBox2 = New gGlowBox.gGlowBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GlassButton2 = New Glass.GlassButton()
        Me.GlassButton3 = New Glass.GlassButton()
        Me.GlassButton4 = New Glass.GlassButton()
        Me.GGlowBox1.SuspendLayout()
        Me.GGlowBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GGlowBox1
        '
        Me.GGlowBox1.Controls.Add(Me.TextBox1)
        Me.GGlowBox1.Location = New System.Drawing.Point(21, 70)
        Me.GGlowBox1.Name = "GGlowBox1"
        Me.GGlowBox1.Size = New System.Drawing.Size(400, 27)
        Me.GGlowBox1.TabIndex = 15
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Location = New System.Drawing.Point(4, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(393, 22)
        Me.TextBox1.TabIndex = 11
        '
        'GlassButton1
        '
        Me.GlassButton1.Location = New System.Drawing.Point(427, 70)
        Me.GlassButton1.Name = "GlassButton1"
        Me.GlassButton1.Size = New System.Drawing.Size(46, 23)
        Me.GlassButton1.TabIndex = 14
        Me.GlassButton1.Text = "..."
        '
        'GGlowBox2
        '
        Me.GGlowBox2.Controls.Add(Me.TextBox2)
        Me.GGlowBox2.Location = New System.Drawing.Point(21, 118)
        Me.GGlowBox2.Name = "GGlowBox2"
        Me.GGlowBox2.Size = New System.Drawing.Size(400, 27)
        Me.GGlowBox2.TabIndex = 17
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(4, 4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(393, 22)
        Me.TextBox2.TabIndex = 11
        '
        'GlassButton2
        '
        Me.GlassButton2.Location = New System.Drawing.Point(427, 118)
        Me.GlassButton2.Name = "GlassButton2"
        Me.GlassButton2.Size = New System.Drawing.Size(46, 23)
        Me.GlassButton2.TabIndex = 16
        Me.GlassButton2.Text = "..."
        '
        'GlassButton3
        '
        Me.GlassButton3.Location = New System.Drawing.Point(25, 526)
        Me.GlassButton3.Name = "GlassButton3"
        Me.GlassButton3.Size = New System.Drawing.Size(124, 22)
        Me.GlassButton3.TabIndex = 20
        Me.GlassButton3.Text = "Converter"
        '
        'GlassButton4
        '
        Me.GlassButton4.Location = New System.Drawing.Point(155, 526)
        Me.GlassButton4.Name = "GlassButton4"
        Me.GlassButton4.Size = New System.Drawing.Size(124, 22)
        Me.GlassButton4.TabIndex = 21
        Me.GlassButton4.Text = "Cancelar"
        '
        'DocumentConvert
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(529, 571)
        Me.Controls.Add(Me.GlassButton4)
        Me.Controls.Add(Me.GlassButton3)
        Me.Controls.Add(Me.GGlowBox2)
        Me.Controls.Add(Me.GlassButton2)
        Me.Controls.Add(Me.GGlowBox1)
        Me.Controls.Add(Me.GlassButton1)
        Me.Name = "DocumentConvert"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DocumentConvert"
        Me.Controls.SetChildIndex(Me.GlassButton1, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox1, 0)
        Me.Controls.SetChildIndex(Me.GlassButton2, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox2, 0)
        Me.Controls.SetChildIndex(Me.GlassButton3, 0)
        Me.Controls.SetChildIndex(Me.GlassButton4, 0)
        Me.GGlowBox1.ResumeLayout(False)
        Me.GGlowBox1.PerformLayout()
        Me.GGlowBox2.ResumeLayout(False)
        Me.GGlowBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GGlowBox1 As gGlowBox.gGlowBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GlassButton1 As Glass.GlassButton
    Friend WithEvents GGlowBox2 As gGlowBox.gGlowBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GlassButton2 As Glass.GlassButton
    Friend WithEvents GlassButton3 As Glass.GlassButton
    Friend WithEvents GlassButton4 As Glass.GlassButton
End Class
