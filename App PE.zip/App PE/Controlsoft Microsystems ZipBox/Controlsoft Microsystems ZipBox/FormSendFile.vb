﻿Imports System.Net.Mail
'os softwares podem pular procedimentos ou funcoes qie dão errro
Public Class FormSendFile
 Dim ProcessosUsandoArquivo () As String  "'guarda o filename dos processos
 Public Sub New(Files() )As String 
 
End Sub 
 
 
 Public Function IsUsed(FileName As String) As Boolean 
 Try
 Dim Locked As List(Of Process) = ProcessLocking.WhoIsLocking(FileName)
 If Locked.Count > 0 Then 
     Return True
 Else
     Return False 
 Catch ex As Exception 
 Log.WriInLog("Erro na Função IsUsed na Classe Formulário SendFile")
 
 End Function 
 
 
 
 
Dim Locked As List(Of Process) = ProcessLocking.WhoIsLocking(Arquivo)
For Each proc In  Locked 

 
 End If 
 
 End Sub 
 
 
 
    If File.Exists(ArquivoOuPath) Then 
    Dim Locked As List(Of Process) = ProcessLocking.WhoIsLocking(ArquivoouPath)
    If Locked.Count > 0 Then 
    For Each itemproc In Locked 
    MsgBox.Show(" o Arquivo " &  ItemProc.ProcessName.ToString")
    End For
    
    End If
    
    "Exemplo Base
    'Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
    '    LockedFileProcesses.Clear()
    '    RichTextBox1.Text = ""
    '    Dim OFD As New OpenFileDialog
    '    OFD.InitialDirectory = "C\Users\John\Desktop"
    '    OFD.Title = "Check Locked File"
    '    OFD.Multiselect = False
    '    If OFD.ShowDialog = Windows.Forms.DialogResult.OK Then
    '        LockedFileProcesses = WhoIsLocking(OFD.FileName)
    '        If LockedFileProcesses.Count > 0 Then
    '            For Each Item In LockedFileProcesses
    '                RichTextBox1.AppendText(OFD.FileName & " - " & Item.ProcessName.ToString & " .. " & Item.Id.ToString & vbCrLf)
    '            Next
    '        End If
    '    End If




    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) ' Handles Button1.Click
        Dim mail As New MailMessage()
        Dim SmtpServer As New SmtpClient("smtp.gmail.com")
        mail.From = New MailAddress(TextBox2.Text)
        mail.[To].Add(TextBox2.Text)
        mail.Subject = TextBox7.Text
        mail.Body = TextBox4.Text
        Dim attachment As System.Net.Mail.Attachment
        Dim Arquivo As String = TextBox6.Text
        attachment = New System.Net.Mail.Attachment(Arquivo)
        mail.Attachments.Add(attachment)
        SmtpServer.Port = 587
        Dim Email, Senha As String
        Email = TextBox2.Text : Senha = TextBox3.Text
        SmtpServer.Credentials = New System.Net.NetworkCredential(Email, Senha)
        SmtpServer.EnableSsl = True
        SmtpServer.Send(mail)
        MsgBox("Email Enviado com Sucesso")

    End Sub

    Private Sub GlassButton4_Click(sender As Object, e As EventArgs) Handles GlassButton4.Click
        Dim OpenFile As New OpenFileDialog()
        OpenFile.CheckFileExists = True
        OpenFile.CheckPathExists = True
        OpenFile.Title = "Selecione o Anexo"
        OpenFile.Multiselect = False
        Try
            TextBox6.Text = OpenFile.FileName
        Catch ex As Exception
        End Try
    End Sub

End Class
Private Sub GlassButton4_Click(sender As Object, e As EventArgs)

    End Sub