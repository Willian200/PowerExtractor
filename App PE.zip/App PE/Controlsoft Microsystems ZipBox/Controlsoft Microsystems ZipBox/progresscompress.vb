Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports SevenZip
Imports System.IO

Public Partial Class progresscompress
	Inherits Form
    Public Sub New(parent As ZipBox, in_archFile As String, in_archType As OutArchiveFormat, in_compLevel As CompressionLevel, in_fileList As String())
        InitializeComponent()
        archFile = in_archFile
        archType = in_archType
        compLevel = in_compLevel
        fileList = in_fileList
        owner = parent
    End Sub

    Public archFile As String
	Public archType As OutArchiveFormat
	Public compLevel As CompressionLevel
	Public fileList As String()
	Public enginec As New SevenZipCompressor()
	Public curFileNum As Integer = 0
    Public owner As ZipBox

    Private Sub progresscompress_Load(sender As Object, e As EventArgs)

	End Sub

	Private Sub progresscompress_Shown(sender As Object, e As EventArgs)
		startCompression()
	End Sub

	Public Sub comp_Compressing(sender As Object, e As ProgressEventArgs)
		progressBar1.Increment(e.PercentDelta)
		Refresh()
	End Sub

	Public Sub comp_FileCompressionStarted(sender As Object, e As FileNameEventArgs)
		label3.Text = Path.GetFileName(e.FileName)
		progressBar2.Increment(1)
		curFileNum += 1
		label4.Text = curFileNum.ToString() & " / " & fileList.Length.ToString() & " files compressed"
	End Sub

	Public Sub comp_CompressionFinished(sender As Object, e As EventArgs)
		progressBar1.Value = progressBar1.Maximum
		progressBar2.Value = progressBar2.Maximum
		label4.Text = "Compression complete!"
		Dim fi As New FileInfo(archFile)
		Dim fz As String = owner.fSize(CULng(fi.Length))
		MessageBox.Show("Compression has been completed successfully." & Environment.NewLine & Environment.NewLine & "Output file is " & fz, "Compression Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)
		Close()
	End Sub

	Public Sub startCompression()
		AddHandler enginec.Compressing, New EventHandler(Of ProgressEventArgs)(AddressOf comp_Compressing)
		AddHandler enginec.FileCompressionStarted, New EventHandler(Of FileNameEventArgs)(AddressOf comp_FileCompressionStarted)
		AddHandler enginec.CompressionFinished, New EventHandler(Of EventArgs)(AddressOf comp_CompressionFinished)
		enginec.ArchiveFormat = archType
		enginec.CompressionLevel = compLevel
		label2.Text = Path.GetFileName(archFile)
		If File.Exists(archFile) Then
			File.Delete(archFile)
		End If
		progressBar2.Maximum = fileList.Length
		label4.Text = curFileNum.ToString() & " / " & fileList.Length.ToString() & " files compressed"
		enginec.BeginCompressFiles(archFile, fileList)
	End Sub
End Class
