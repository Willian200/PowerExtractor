'
'Copyright (c)  2008-2009,Domagoj Pintaric
'SharpArchiver is distributed under the terms of the GNU Lesser General Public License
'
'    This file is part of SharpArchiver.
'
'    SharpArchiver is free software: you can redistribute it and/or modify
'    it under the terms of the GNU Lesser General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    SharpArchiver is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with SharpArchiver.  If not, see <http://www.gnu.org/licenses/>.
'
'

Imports Cake3
Imports Cake3.Queue
'Algoritmo do CAKE

''' <summary>
''' Description of WorkItem.
''' </summary>
Public Class WorkItem
	Private isShellExtension As Boolean = False
	Private isRun As Boolean = False
	Private file As String


	Public Sub New(isShellExtension As Boolean, isRun As Boolean, file As String)
		Me.isShellExtension = isShellExtension
		'dali se zove iz shellextension
		Me.isRun = isRun
		'dali treba pokrenut file
			'file koji treba pokrenut
		Me.file = file
	End Sub

	Public Sub Extract(filePath As String, extractFolder As String, createFolders As Boolean, overwrite As Boolean, fileList As String())
		Dim pf As New ProgressForm(isShellExtension, isRun, file)

		Dim extractOptions As New ExtractOptions(filePath, extractFolder, fileList, overwrite, createFolders)
		Dim workItem As New CakdirWorkItem(extractOptions)
		workItem.OnProgress = DirectCast([Delegate].Combine(workItem.OnProgress, New ProgressEventHandler(AddressOf pf.ProgressForm_Progress)), ProgressEventHandler)
		workItem.OnMessage = DirectCast([Delegate].Combine(workItem.OnMessage, New MessageEventHandler(AddressOf pf.ProgressForm_Message)), MessageEventHandler)
		workItem.OnStartWorking = DirectCast([Delegate].Combine(workItem.OnStartWorking, New EventHandler(AddressOf pf.ProgressForm_StartWorking)), EventHandler)
		workItem.OnStopWorking = DirectCast([Delegate].Combine(workItem.OnStopWorking, New EventHandler(AddressOf pf.ProgressForm_StopWorking)), EventHandler)

		pf.Show()
		workItem.Start()

	End Sub

	Public Sub Add(filePath As String, fileList As String(), compressionlvl As UShort, password As String, dialogless As Boolean, savePath As String, _
		baseFolder As String)

		Dim pf As New ProgressForm(isShellExtension, False, "")
		Dim addOptions__1 As AddOptions

		If savePath = "Relative" Then
			addOptions__1 = New AddOptions(filePath, fileList, compressionlvl, AddOptions.folderMode.relative, password, dialogless, _
				Nothing)
			addOptions__1.baseFolder = baseFolder

		ElseIf savePath = "Full" Then

			addOptions__1 = New AddOptions(filePath, fileList, compressionlvl, AddOptions.folderMode.full, password, dialogless, _
				Nothing)
		Else

			addOptions__1 = New AddOptions(filePath, fileList, compressionlvl, AddOptions.folderMode.none, password, dialogless, _
				Nothing)
		End If

		Dim workItem As New CakdirWorkItem(addOptions__1)
		workItem.OnProgress = DirectCast([Delegate].Combine(workItem.OnProgress, New ProgressEventHandler(AddressOf pf.ProgressForm_Progress)), ProgressEventHandler)
		workItem.OnMessage = DirectCast([Delegate].Combine(workItem.OnMessage, New MessageEventHandler(AddressOf pf.ProgressForm_Message)), MessageEventHandler)
		workItem.OnStartWorking = DirectCast([Delegate].Combine(workItem.OnStartWorking, New EventHandler(AddressOf pf.ProgressForm_StartWorking)), EventHandler)
		workItem.OnStopWorking = DirectCast([Delegate].Combine(workItem.OnStopWorking, New EventHandler(AddressOf pf.addProgressForm_StopWorking)), EventHandler)
		pf.Show()
		workItem.Start()
	End Sub

	Public Sub Delete(filePath As String, fileList As String())
		Dim pf As New ProgressForm(isShellExtension, False, "")

		Dim deleteOptions As New DeleteOptions(filePath, fileList)
        Dim workItem As New CakdirWorkItem(deleteOptions)
        workItem.OnProgress = DirectCast([Delegate].Combine(workItem.OnProgress, New ProgressEventHandler(AddressOf pf.ProgressForm_Progress)), ProgressEventHandler)
        workItem.OnMessage = DirectCast([Delegate].Combine(workItem.OnMessage, New MessageEventHandler(AddressOf pf.ProgressForm_Message)), MessageEventHandler)
		workItem.OnStartWorking = DirectCast([Delegate].Combine(workItem.OnStartWorking, New EventHandler(AddressOf pf.ProgressForm_StartWorking)), EventHandler)
		workItem.OnStopWorking = DirectCast([Delegate].Combine(workItem.OnStopWorking, New EventHandler(AddressOf pf.deleteProgressForm_StopWorking)), EventHandler)
		pf.Show()
        workItem.Start()


    End Sub

End Class
