﻿'
' Created by SharpDevelop.
' User: joaopaulo
' Date: 13/01/2017
' Time: 06:29
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Public Partial Class RemoveDuplicate
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub

    Private Sub RemoveDuplicate_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GlassButton2_Click(sender As Object, e As EventArgs) Handles GlassButton2.Click

    End Sub
End Class
