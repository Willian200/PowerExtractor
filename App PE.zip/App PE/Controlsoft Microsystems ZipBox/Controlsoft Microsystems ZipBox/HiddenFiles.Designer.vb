﻿'
' Created by SharpDevelop.
' User: joaopaulo
' Date: 13/01/2017
' Time: 06:29
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class HiddenFiles
    Inherits Metro.Form
    ''' <summary>
    ''' Designer variable used to keep track of non-visual components.
    ''' </summary>
    Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GlassButton1 = New Glass.GlassButton()
        Me.GGlowBox1 = New gGlowBox.gGlowBox()
        Me.GlassButton3 = New Glass.GlassButton()
        Me.GlassButton4 = New Glass.GlassButton()
        Me.CheckBoxFile = New System.Windows.Forms.CheckBox()
        Me.CheckBoxFolder = New System.Windows.Forms.CheckBox()
        Me.GGlowBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Location = New System.Drawing.Point(4, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(393, 22)
        Me.TextBox1.TabIndex = 11
        '
        'GlassButton1
        '
        Me.GlassButton1.Location = New System.Drawing.Point(430, 104)
        Me.GlassButton1.Name = "GlassButton1"
        Me.GlassButton1.Size = New System.Drawing.Size(46, 23)
        Me.GlassButton1.TabIndex = 1
        Me.GlassButton1.Text = "..."
        '
        'GGlowBox1
        '
        Me.GGlowBox1.Controls.Add(Me.TextBox1)
        Me.GGlowBox1.Location = New System.Drawing.Point(24, 104)
        Me.GGlowBox1.Name = "GGlowBox1"
        Me.GGlowBox1.Size = New System.Drawing.Size(400, 27)
        Me.GGlowBox1.TabIndex = 13
        '
        'GlassButton3
        '
        Me.GlassButton3.Location = New System.Drawing.Point(13, 311)
        Me.GlassButton3.Name = "GlassButton3"
        Me.GlassButton3.Size = New System.Drawing.Size(124, 23)
        Me.GlassButton3.TabIndex = 16
        Me.GlassButton3.Text = "Ocultar"
        '
        'GlassButton4
        '
        Me.GlassButton4.Location = New System.Drawing.Point(143, 311)
        Me.GlassButton4.Name = "GlassButton4"
        Me.GlassButton4.Size = New System.Drawing.Size(124, 23)
        Me.GlassButton4.TabIndex = 17
        Me.GlassButton4.Text = "Mostrar"
        '
        'CheckBoxFile
        '
        Me.CheckBoxFile.AutoSize = True
        Me.CheckBoxFile.Location = New System.Drawing.Point(25, 220)
        Me.CheckBoxFile.Name = "CheckBoxFile"
        Me.CheckBoxFile.Size = New System.Drawing.Size(66, 17)
        Me.CheckBoxFile.TabIndex = 18
        Me.CheckBoxFile.Text = "Arquivo"
        Me.CheckBoxFile.UseVisualStyleBackColor = True
        '
        'CheckBoxFolder
        '
        Me.CheckBoxFolder.AutoSize = True
        Me.CheckBoxFolder.Location = New System.Drawing.Point(25, 244)
        Me.CheckBoxFolder.Name = "CheckBoxFolder"
        Me.CheckBoxFolder.Size = New System.Drawing.Size(53, 17)
        Me.CheckBoxFolder.TabIndex = 19
        Me.CheckBoxFolder.Text = "Pasta"
        Me.CheckBoxFolder.UseVisualStyleBackColor = True
        '
        'HiddenFiles
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.BorderColor = System.Drawing.Color.Black
        Me.BorderWidth = 3
        Me.ClientSize = New System.Drawing.Size(548, 353)
        Me.Controls.Add(Me.CheckBoxFolder)
        Me.Controls.Add(Me.CheckBoxFile)
        Me.Controls.Add(Me.GlassButton4)
        Me.Controls.Add(Me.GlassButton3)
        Me.Controls.Add(Me.GGlowBox1)
        Me.Controls.Add(Me.GlassButton1)
        Me.ForeColor = System.Drawing.Color.Silver
        Me.MaximizeBox = False
        Me.Name = "HiddenFiles"
        Me.Padding = New System.Windows.Forms.Padding(3)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ocultar Arquivos"
        Me.Controls.SetChildIndex(Me.GlassButton1, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox1, 0)
        Me.Controls.SetChildIndex(Me.GlassButton3, 0)
        Me.Controls.SetChildIndex(Me.GlassButton4, 0)
        Me.Controls.SetChildIndex(Me.CheckBoxFile, 0)
        Me.Controls.SetChildIndex(Me.CheckBoxFolder, 0)
        Me.GGlowBox1.ResumeLayout(False)
        Me.GGlowBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GlassButton1 As Glass.GlassButton
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GGlowBox1 As gGlowBox.gGlowBox
    Friend WithEvents GlassButton3 As Glass.GlassButton
    Friend WithEvents GlassButton4 As Glass.GlassButton
    Friend WithEvents CheckBoxFile As CheckBox
    Friend WithEvents CheckBoxFolder As CheckBox
End Class
