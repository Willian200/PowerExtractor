Partial Class progresscompress
	''' <summary>
	''' Required designer variable.
	''' </summary>
	Private components As System.ComponentModel.IContainer = Nothing

	''' <summary>
	''' Clean up any resources being used.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(disposing As Boolean)
		If disposing AndAlso (components IsNot Nothing) Then
			components.Dispose()
		End If
		MyBase.Dispose(disposing)
	End Sub

	#Region "Windows Form Designer generated code"

	''' <summary>
	''' Required method for Designer support - do not modify
	''' the contents of this method with the code editor.
	''' </summary>
	Private Sub InitializeComponent()
		Me.label1 = New System.Windows.Forms.Label()
		Me.groupBox1 = New System.Windows.Forms.GroupBox()
		Me.progressBar1 = New System.Windows.Forms.ProgressBar()
		Me.label3 = New System.Windows.Forms.Label()
		Me.label2 = New System.Windows.Forms.Label()
		Me.groupBox2 = New System.Windows.Forms.GroupBox()
		Me.progressBar2 = New System.Windows.Forms.ProgressBar()
		Me.label4 = New System.Windows.Forms.Label()
		Me.groupBox1.SuspendLayout()
		Me.groupBox2.SuspendLayout()
		Me.SuspendLayout()
		' 
		' label1
		' 
		Me.label1.AutoSize = True
		Me.label1.Location = New System.Drawing.Point(9, 9)
		Me.label1.Name = "label1"
		Me.label1.Size = New System.Drawing.Size(61, 13)
		Me.label1.TabIndex = 0
		Me.label1.Text = "Output File:"
		' 
		' groupBox1
		' 
		Me.groupBox1.Controls.Add(Me.progressBar1)
		Me.groupBox1.Controls.Add(Me.label3)
		Me.groupBox1.Location = New System.Drawing.Point(12, 25)
		Me.groupBox1.Name = "groupBox1"
		Me.groupBox1.Size = New System.Drawing.Size(374, 52)
		Me.groupBox1.TabIndex = 1
		Me.groupBox1.TabStop = False
		Me.groupBox1.Text = "Processing"
		' 
		' progressBar1
		' 
		Me.progressBar1.Location = New System.Drawing.Point(7, 32)
		Me.progressBar1.Name = "progressBar1"
		Me.progressBar1.Size = New System.Drawing.Size(359, 12)
		Me.progressBar1.TabIndex = 1
		' 
		' label3
		' 
		Me.label3.AutoSize = True
		Me.label3.Location = New System.Drawing.Point(3, 16)
		Me.label3.Name = "label3"
		Me.label3.Size = New System.Drawing.Size(55, 13)
		Me.label3.TabIndex = 0
		Me.label3.Text = "currfile.ext"
		' 
		' label2
		' 
		Me.label2.AutoSize = True
		Me.label2.Location = New System.Drawing.Point(71, 9)
		Me.label2.Name = "label2"
		Me.label2.Size = New System.Drawing.Size(46, 13)
		Me.label2.TabIndex = 2
		Me.label2.Text = "nofile.7z"
		' 
		' groupBox2
		' 
		Me.groupBox2.Controls.Add(Me.progressBar2)
		Me.groupBox2.Controls.Add(Me.label4)
		Me.groupBox2.Location = New System.Drawing.Point(12, 83)
		Me.groupBox2.Name = "groupBox2"
		Me.groupBox2.Size = New System.Drawing.Size(374, 61)
		Me.groupBox2.TabIndex = 3
		Me.groupBox2.TabStop = False
		Me.groupBox2.Text = "Overall"
		' 
		' progressBar2
		' 
		Me.progressBar2.Location = New System.Drawing.Point(7, 32)
		Me.progressBar2.Name = "progressBar2"
		Me.progressBar2.Size = New System.Drawing.Size(359, 23)
		Me.progressBar2.TabIndex = 1
		' 
		' label4
		' 
		Me.label4.Location = New System.Drawing.Point(3, 16)
		Me.label4.Name = "label4"
		Me.label4.Size = New System.Drawing.Size(362, 16)
		Me.label4.TabIndex = 0
		Me.label4.Text = "0 / 0 files compressed"
		Me.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter
		' 
		' progresscompress
		' 
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(399, 156)
		Me.Controls.Add(Me.groupBox2)
		Me.Controls.Add(Me.label2)
		Me.Controls.Add(Me.groupBox1)
		Me.Controls.Add(Me.label1)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "progresscompress"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "Compressing..."
		Me.TopMost = True
		AddHandler Me.Load, New System.EventHandler(AddressOf Me.progresscompress_Load)
		AddHandler Me.Shown, New System.EventHandler(AddressOf Me.progresscompress_Shown)
		Me.groupBox1.ResumeLayout(False)
		Me.groupBox1.PerformLayout()
		Me.groupBox2.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	#End Region

	Private label1 As System.Windows.Forms.Label
	Private groupBox1 As System.Windows.Forms.GroupBox
	Private progressBar1 As System.Windows.Forms.ProgressBar
	Private label3 As System.Windows.Forms.Label
	Private label2 As System.Windows.Forms.Label
	Private groupBox2 As System.Windows.Forms.GroupBox
	Private progressBar2 As System.Windows.Forms.ProgressBar
	Private label4 As System.Windows.Forms.Label
End Class
