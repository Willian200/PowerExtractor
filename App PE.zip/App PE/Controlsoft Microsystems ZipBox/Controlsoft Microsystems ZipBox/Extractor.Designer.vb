﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Extractor
    Inherits Metro.Form
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ProgressIndicator1 = New ProgressControls.ProgressIndicator()
        Me.GGlowBox1 = New gGlowBox.gGlowBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GlassButton1 = New Glass.GlassButton()
        Me.GlassButton2 = New Glass.GlassButton()
        Me.GGlowBox2 = New gGlowBox.gGlowBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GlassButton3 = New Glass.GlassButton()
        Me.GlassButton4 = New Glass.GlassButton()
        Me.GlassButton5 = New Glass.GlassButton()
        Me.GGlowBox1.SuspendLayout()
        Me.GGlowBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'ProgressIndicator1
        '
        Me.ProgressIndicator1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ProgressIndicator1.Location = New System.Drawing.Point(305, 192)
        Me.ProgressIndicator1.Name = "ProgressIndicator1"
        Me.ProgressIndicator1.Percentage = 0!
        Me.ProgressIndicator1.Size = New System.Drawing.Size(102, 102)
        Me.ProgressIndicator1.TabIndex = 11
        Me.ProgressIndicator1.Text = "ProgressIndicator1"
        '
        'GGlowBox1
        '
        Me.GGlowBox1.Controls.Add(Me.TextBox1)
        Me.GGlowBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GGlowBox1.ForeColor = System.Drawing.Color.Silver
        Me.GGlowBox1.Location = New System.Drawing.Point(13, 67)
        Me.GGlowBox1.Name = "GGlowBox1"
        Me.GGlowBox1.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox1.TabIndex = 17
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.ForeColor = System.Drawing.Color.Silver
        Me.TextBox1.Location = New System.Drawing.Point(4, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(353, 22)
        Me.TextBox1.TabIndex = 11
        '
        'GlassButton1
        '
        Me.GlassButton1.Location = New System.Drawing.Point(379, 67)
        Me.GlassButton1.Name = "GlassButton1"
        Me.GlassButton1.Size = New System.Drawing.Size(46, 23)
        Me.GlassButton1.TabIndex = 16
        Me.GlassButton1.Text = "..."
        '
        'GlassButton2
        '
        Me.GlassButton2.Location = New System.Drawing.Point(24, 348)
        Me.GlassButton2.Name = "GlassButton2"
        Me.GlassButton2.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton2.TabIndex = 37
        Me.GlassButton2.Text = "Extrair"
        '
        'GGlowBox2
        '
        Me.GGlowBox2.Controls.Add(Me.TextBox2)
        Me.GGlowBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GGlowBox2.ForeColor = System.Drawing.Color.Silver
        Me.GGlowBox2.Location = New System.Drawing.Point(13, 108)
        Me.GGlowBox2.Name = "GGlowBox2"
        Me.GGlowBox2.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox2.TabIndex = 39
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.ForeColor = System.Drawing.Color.Silver
        Me.TextBox2.Location = New System.Drawing.Point(4, 4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(353, 22)
        Me.TextBox2.TabIndex = 11
        '
        'GlassButton3
        '
        Me.GlassButton3.Location = New System.Drawing.Point(379, 108)
        Me.GlassButton3.Name = "GlassButton3"
        Me.GlassButton3.Size = New System.Drawing.Size(46, 23)
        Me.GlassButton3.TabIndex = 38
        Me.GlassButton3.Text = "..."
        '
        'GlassButton4
        '
        Me.GlassButton4.Location = New System.Drawing.Point(147, 348)
        Me.GlassButton4.Name = "GlassButton4"
        Me.GlassButton4.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton4.TabIndex = 40
        Me.GlassButton4.Text = "Pausar"
        '
        'GlassButton5
        '
        Me.GlassButton5.Location = New System.Drawing.Point(270, 348)
        Me.GlassButton5.Name = "GlassButton5"
        Me.GlassButton5.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton5.TabIndex = 41
        Me.GlassButton5.Text = "Cancelar"
        '
        'Extractor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(463, 463)
        Me.Controls.Add(Me.GlassButton5)
        Me.Controls.Add(Me.GlassButton4)
        Me.Controls.Add(Me.GGlowBox2)
        Me.Controls.Add(Me.GlassButton3)
        Me.Controls.Add(Me.GlassButton2)
        Me.Controls.Add(Me.GGlowBox1)
        Me.Controls.Add(Me.GlassButton1)
        Me.Controls.Add(Me.ProgressIndicator1)
        Me.ForeColor = System.Drawing.Color.Gray
        Me.Name = "Extractor"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Extractor"
        Me.Controls.SetChildIndex(Me.ProgressIndicator1, 0)
        Me.Controls.SetChildIndex(Me.GlassButton1, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox1, 0)
        Me.Controls.SetChildIndex(Me.GlassButton2, 0)
        Me.Controls.SetChildIndex(Me.GlassButton3, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox2, 0)
        Me.Controls.SetChildIndex(Me.GlassButton4, 0)
        Me.Controls.SetChildIndex(Me.GlassButton5, 0)
        Me.GGlowBox1.ResumeLayout(False)
        Me.GGlowBox1.PerformLayout()
        Me.GGlowBox2.ResumeLayout(False)
        Me.GGlowBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ProgressIndicator1 As ProgressControls.ProgressIndicator
    Friend WithEvents GGlowBox1 As gGlowBox.gGlowBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GlassButton1 As Glass.GlassButton
    Friend WithEvents GlassButton2 As Glass.GlassButton
    Friend WithEvents GGlowBox2 As gGlowBox.gGlowBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GlassButton3 As Glass.GlassButton
    Friend WithEvents GlassButton4 As Glass.GlassButton
    Friend WithEvents GlassButton5 As Glass.GlassButton
End Class
