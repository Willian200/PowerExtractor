﻿'
' Created by SharpDevelop.
' User: joaopaulo
' Date: 13/01/2017
' Time: 06:32
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Public Partial Class EmuleISO
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub

    Private Sub GlassButton2_Click(sender As Object, e As EventArgs) Handles GlassButton2.Click

    End Sub
End Class
