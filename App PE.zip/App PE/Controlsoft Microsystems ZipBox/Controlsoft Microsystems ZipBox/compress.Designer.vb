Imports System.ComponentModel

Partial Class compress
    Inherits Metro.Form
    ''' <summary>
    ''' Required designer variable.
    ''' </summary>
    Private components As System.ComponentModel.IContainer = Nothing

    ''' <summary>
    ''' Clean up any resources being used.
    ''' </summary>
    ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    Protected Overrides Sub Dispose(disposing As Boolean)
        If disposing AndAlso (components IsNot Nothing) Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region "Windows Form Designer generated code"

    ''' <summary>
    ''' Required method for Designer support - do not modify
    ''' the contents of this method with the code editor.
    ''' </summary>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(compress))
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.button1 = New System.Windows.Forms.Button()
        Me.textBox1 = New System.Windows.Forms.TextBox()
        Me.saveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.groupBox2 = New System.Windows.Forms.GroupBox()
        Me.comboBox1 = New System.Windows.Forms.ComboBox()
        Me.groupBox3 = New System.Windows.Forms.GroupBox()
        Me.comboBox2 = New System.Windows.Forms.ComboBox()
        Me.groupBox4 = New System.Windows.Forms.GroupBox()
        Me.button4 = New System.Windows.Forms.Button()
        Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.listView1 = New System.Windows.Forms.ListView()
        Me.columnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.folderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.openFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.button5 = New System.Windows.Forms.Button()
        Me.button6 = New System.Windows.Forms.Button()
        Me.label1 = New System.Windows.Forms.Label()
        Me.groupBox1.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.groupBox3.SuspendLayout()
        Me.groupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.button1)
        Me.groupBox1.Controls.Add(Me.textBox1)
        Me.groupBox1.Location = New System.Drawing.Point(12, 12)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(274, 46)
        Me.groupBox1.TabIndex = 0
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Output File"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(204, 17)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(64, 23)
        Me.button1.TabIndex = 1
        Me.button1.Text = "Browse.."
        Me.button1.UseVisualStyleBackColor = True
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(6, 19)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(192, 22)
        Me.textBox1.TabIndex = 0
        '
        'saveFileDialog1
        '
        Me.saveFileDialog1.DefaultExt = "7z"
        Me.saveFileDialog1.Filter = "7-Zip File (*.7z)|*.7z|XZ File (*.xz)|*.xz|bzip2 File (*.bz2)|*.bz2|gzip File (*." &
    "gz)|*.gz|Tarball File (*.tar)|*.tar|ZIP File (*.zip)|*.zip|WIM File (*.wim)|*.wi" &
    "m"
        Me.saveFileDialog1.Title = "Output File"
        '
        'groupBox2
        '
        Me.groupBox2.Controls.Add(Me.comboBox1)
        Me.groupBox2.Location = New System.Drawing.Point(293, 12)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(118, 46)
        Me.groupBox2.TabIndex = 1
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Compression Format"
        '
        'comboBox1
        '
        Me.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBox1.FormattingEnabled = True
        Me.comboBox1.Items.AddRange(New Object() {"7-Zip", "ZIP", "bzip2", "gzip", "XZ", "TAR"})
        Me.comboBox1.Location = New System.Drawing.Point(6, 18)
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(105, 21)
        Me.comboBox1.TabIndex = 0
        '
        'groupBox3
        '
        Me.groupBox3.Controls.Add(Me.comboBox2)
        Me.groupBox3.Location = New System.Drawing.Point(417, 12)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(113, 46)
        Me.groupBox3.TabIndex = 2
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "Compression Level"
        '
        'comboBox2
        '
        Me.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBox2.FormattingEnabled = True
        Me.comboBox2.Items.AddRange(New Object() {"Ultra", "High", "Normal", "Low", "Fast", "None"})
        Me.comboBox2.Location = New System.Drawing.Point(6, 19)
        Me.comboBox2.Name = "comboBox2"
        Me.comboBox2.Size = New System.Drawing.Size(101, 21)
        Me.comboBox2.TabIndex = 0
        '
        'groupBox4
        '
        Me.groupBox4.Controls.Add(Me.button4)
        Me.groupBox4.Controls.Add(Me.listView1)
        Me.groupBox4.Controls.Add(Me.button3)
        Me.groupBox4.Controls.Add(Me.button2)
        Me.groupBox4.Location = New System.Drawing.Point(12, 64)
        Me.groupBox4.Name = "groupBox4"
        Me.groupBox4.Size = New System.Drawing.Size(519, 171)
        Me.groupBox4.TabIndex = 3
        Me.groupBox4.TabStop = False
        Me.groupBox4.Text = "Files to Compress"
        '
        'button4
        '
        Me.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.button4.ImageIndex = 2
        Me.button4.ImageList = Me.imageList1
        Me.button4.Location = New System.Drawing.Point(6, 14)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(114, 23)
        Me.button4.TabIndex = 3
        Me.button4.Text = "Delete Selected"
        Me.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.button4.UseVisualStyleBackColor = True
        '
        'imageList1
        '
        Me.imageList1.ImageStream = CType(resources.GetObject("imageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.imageList1.Images.SetKeyName(0, "folder-add-icon.png")
        Me.imageList1.Images.SetKeyName(1, "page-add-icon.png")
        Me.imageList1.Images.SetKeyName(2, "delete-file-icon.png")
        '
        'listView1
        '
        Me.listView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.columnHeader1, Me.columnHeader2})
        Me.listView1.Location = New System.Drawing.Point(6, 40)
        Me.listView1.Name = "listView1"
        Me.listView1.Size = New System.Drawing.Size(506, 125)
        Me.listView1.TabIndex = 2
        Me.listView1.UseCompatibleStateImageBehavior = False
        Me.listView1.View = System.Windows.Forms.View.Details
        '
        'columnHeader1
        '
        Me.columnHeader1.Text = "File"
        Me.columnHeader1.Width = 404
        '
        'columnHeader2
        '
        Me.columnHeader2.Text = "Size"
        Me.columnHeader2.Width = 75
        '
        'button3
        '
        Me.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.button3.ImageIndex = 1
        Me.button3.ImageList = Me.imageList1
        Me.button3.Location = New System.Drawing.Point(339, 14)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(82, 23)
        Me.button3.TabIndex = 1
        Me.button3.Text = "Add Files"
        Me.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.button3.UseVisualStyleBackColor = True
        '
        'button2
        '
        Me.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver
        Me.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.button2.ImageIndex = 0
        Me.button2.ImageList = Me.imageList1
        Me.button2.Location = New System.Drawing.Point(427, 14)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(85, 23)
        Me.button2.TabIndex = 0
        Me.button2.Text = "Add Folder"
        Me.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.button2.UseVisualStyleBackColor = True
        '
        'folderBrowserDialog1
        '
        Me.folderBrowserDialog1.Description = "Select Folder to Compress"
        '
        'openFileDialog1
        '
        Me.openFileDialog1.FileName = "openFileDialog1"
        Me.openFileDialog1.Filter = "All Files (*.*)|*.*"
        Me.openFileDialog1.Multiselect = True
        '
        'button5
        '
        Me.button5.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.button5.Location = New System.Drawing.Point(12, 241)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(91, 32)
        Me.button5.TabIndex = 4
        Me.button5.Text = "&Cancel"
        Me.button5.UseVisualStyleBackColor = True
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(440, 241)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(91, 32)
        Me.button6.TabIndex = 5
        Me.button6.Text = "&Compress"
        Me.button6.UseVisualStyleBackColor = True
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(109, 251)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(324, 21)
        Me.label1.TabIndex = 6
        Me.label1.Text = "0 files in 0 B"
        Me.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'compress
        '
        Me.AcceptButton = Me.button6
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.button5
        Me.ClientSize = New System.Drawing.Size(543, 281)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.button6)
        Me.Controls.Add(Me.button5)
        Me.Controls.Add(Me.groupBox4)
        Me.Controls.Add(Me.groupBox3)
        Me.Controls.Add(Me.groupBox2)
        Me.Controls.Add(Me.groupBox1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "compress"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Compress Files"
        Me.Controls.SetChildIndex(Me.groupBox1, 0)
        Me.Controls.SetChildIndex(Me.groupBox2, 0)
        Me.Controls.SetChildIndex(Me.groupBox3, 0)
        Me.Controls.SetChildIndex(Me.groupBox4, 0)
        Me.Controls.SetChildIndex(Me.button5, 0)
        Me.Controls.SetChildIndex(Me.button6, 0)
        Me.Controls.SetChildIndex(Me.label1, 0)
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox1.PerformLayout()
        Me.groupBox2.ResumeLayout(False)
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private textBox1 As System.Windows.Forms.TextBox
    Private saveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Private comboBox1 As System.Windows.Forms.ComboBox
    Private comboBox2 As System.Windows.Forms.ComboBox
    Private listView1 As System.Windows.Forms.ListView
    Private columnHeader1 As System.Windows.Forms.ColumnHeader
    Private columnHeader2 As System.Windows.Forms.ColumnHeader
    Private imageList1 As System.Windows.Forms.ImageList
    Private folderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Private openFileDialog1 As System.Windows.Forms.OpenFileDialog
    Private label1 As System.Windows.Forms.Label
    Public WithEvents groupBox1 As GroupBox
    Public WithEvents groupBox2 As GroupBox
    Public WithEvents groupBox3 As GroupBox
    Public WithEvents groupBox4 As GroupBox
    Public WithEvents button5 As Button
    Public WithEvents button6 As Button
    Public WithEvents button1 As Button
    Public WithEvents button2 As Button
    Public WithEvents button3 As Button
    Public WithEvents button4 As Button
End Class
