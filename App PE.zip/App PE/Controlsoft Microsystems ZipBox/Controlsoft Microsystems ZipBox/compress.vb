Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports System.IO
Imports SevenZip

Public Partial Class compress
    Inherits Metro.Form
    Public Sub New(parent As ZipBox)
        InitializeComponent()
        owner = parent
    End Sub

    Public Sub New()
    End Sub

    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, keyData As Keys) As Boolean
        If keyData = (Keys.Control Or Keys.A) Then
            For Each item As ListViewItem In listView1.Items
                item.Selected = True
            Next
            Return True
        End If
        Return MyBase.ProcessCmdKey(msg, keyData)
    End Function


    Public owner As ZipBox
    Public sizeTotal As Long = 0

    Private Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click
        If saveFileDialog1.ShowDialog() = DialogResult.OK Then
            textBox1.Text = saveFileDialog1.FileName
        End If
    End Sub

    Public Function indexToFormat() As OutArchiveFormat
		Dim outf As OutArchiveFormat
		Select Case comboBox1.SelectedIndex
			Case 0
				outf = OutArchiveFormat.SevenZip
				Exit Select
			Case 1
				outf = OutArchiveFormat.Zip
				Exit Select
			Case 2
				outf = OutArchiveFormat.BZip2
				Exit Select
			Case 3
				outf = OutArchiveFormat.GZip
				Exit Select
			Case 4
				outf = OutArchiveFormat.XZ
				Exit Select
			Case 5
				outf = OutArchiveFormat.Tar
				Exit Select
			Case Else
				outf = OutArchiveFormat.SevenZip
				Exit Select
		End Select
		Return outf
	End Function

	Public Function levelToFormat() As CompressionLevel
		Dim outf As CompressionLevel
		Select Case comboBox2.SelectedIndex
			Case 0
				outf = CompressionLevel.Ultra
				Exit Select
			Case 1
				outf = CompressionLevel.High
				Exit Select
			Case 2
				outf = CompressionLevel.Normal
				Exit Select
			Case 3
				outf = CompressionLevel.Low
				Exit Select
			Case 4
				outf = CompressionLevel.Fast
				Exit Select
			Case 5
				outf = CompressionLevel.None
				Exit Select
			Case Else
				outf = CompressionLevel.Ultra
				Exit Select
		End Select
		Return outf
	End Function

    Private Sub compress_Load(sender As Object, e As EventArgs) Handles Me.Load
        comboBox1.SelectedIndex = 0
        comboBox2.SelectedIndex = 0
    End Sub

    Private Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        If folderBrowserDialog1.ShowDialog() = DialogResult.OK Then
            listView1.BeginUpdate()
            Dim newfiles As String() = Directory.GetFiles(folderBrowserDialog1.SelectedPath, "*", SearchOption.AllDirectories)
            For Each newfile As String In newfiles
                Dim fi As New FileInfo(newfile)
                Dim lvi As New ListViewItem(newfile)
                lvi.SubItems.Add(owner.fSize(CULng(fi.Length)))
                sizeTotal = sizeTotal + fi.Length
                listView1.Items.Add(lvi)
            Next
            listView1.EndUpdate()
            updateTotals()
        End If
    End Sub

    Private Sub button3_Click(sender As Object, e As EventArgs) Handles button3.Click
        If openFileDialog1.ShowDialog() = DialogResult.OK Then
            listView1.BeginUpdate()
            For Each newfile As String In openFileDialog1.FileNames
                '
                Dim fi As New FileInfo(newfile)
                Dim lvi As New ListViewItem(newfile)
                lvi.SubItems.Add(owner.fSize(CULng(fi.Length)))
                sizeTotal = sizeTotal + fi.Length
                listView1.Items.Add(lvi)
            Next
            listView1.EndUpdate()
            updateTotals()
        End If
    End Sub

    Public Sub updateTotals()
		label1.Text = listView1.Items.Count.ToString() & " files in " & owner.fSize(CULng(sizeTotal))
	End Sub

	Private Sub openFileDialog2_FileOk(sender As Object, e As CancelEventArgs)

	End Sub

    Private Sub button4_Click(sender As Object, e As EventArgs) Handles button4.Click
        For Each itm As ListViewItem In listView1.SelectedItems
            Dim fi As New FileInfo(itm.Text)
            sizeTotal = sizeTotal - fi.Length
            itm.Remove()
        Next
        updateTotals()
    End Sub

    Private Sub button6_Click(sender As Object, e As EventArgs) Handles button6.Click
        If textBox1.Text = "" Then
            MessageBox.Show("You need to specify an output file!", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            textBox1.Focus()
        Else
            If listView1.Items.Count < 1 Then
                MessageBox.Show("You need to add some files to archive!", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            Else
                Dim fList As New List(Of String)()
                For Each itm As ListViewItem In listView1.Items
                    fList.Add(itm.Text)
                Next
                owner.beginCompression(textBox1.Text, indexToFormat(), levelToFormat(), fList.ToArray())
                Close()
            End If
        End If
    End Sub

    Private Sub button5_Click(sender As Object, e As EventArgs) Handles button5.Click
        Me.Close()
        Me.Dispose()

    End Sub
End Class
