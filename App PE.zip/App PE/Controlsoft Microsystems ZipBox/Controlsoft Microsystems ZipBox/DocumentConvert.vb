﻿Public Class DocumentConvert
    Private Sub GlassButton1_Click(sender As Object, e As EventArgs) Handles GlassButton1.Click
        Dim Open As New OpenFileDialog()
        Open.CheckFileExists = True
        Open.CheckPathExists = True
        Open.Multiselect = False
        Open.Title = "Selecione o Documento a Converter"
        Try
            Open.ShowDialog()
            Dim arquivo As String = Open.FileName : TextBox1.Text = arquivo
            TextBox2.Text = IO.Path.GetDirectoryName(arquivo)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub GlassButton2_Click(sender As Object, e As EventArgs) Handles GlassButton2.Click
        Using Folder As FolderBrowserDialog = New FolderBrowserDialog()
            Folder.Description = "Selecione o local a Salvar"
            Folder.RootFolder = Environment.SpecialFolder.MyComputer
            Folder.ShowNewFolderButton = True
            Try
                Folder.ShowDialog()
                Dim Path As String = Folder.SelectedPath.ToString()
                TextBox2.Text = Path
            Catch ex As Exception

            End Try
        End Using
    End Sub

    Private Sub GlassButton4_Click(sender As Object, e As EventArgs) Handles GlassButton4.Click
        Me.Close()
        Me.Dispose()
    End Sub
End Class