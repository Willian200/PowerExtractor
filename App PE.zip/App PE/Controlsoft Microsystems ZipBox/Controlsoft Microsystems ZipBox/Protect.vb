﻿Public Class Protect
    Private Sub GlassButton1_Click(sender As Object, e As EventArgs) Handles GlassButton1.Click

        Dim FileBrowser As New OpenFileDialog()
        FileBrowser.CheckFileExists = True
        FileBrowser.CheckPathExists = True
        FileBrowser.Title = "Selecione o Arquivo para Criptografar"
        FileBrowser.Multiselect = False

        Try
            FileBrowser.ShowDialog()

            Dim Nome As String = FileBrowser.FileName
            TextBox1.Text = Nome

            FileBrowser.Dispose()
            Nome = Nothing

        Catch ex As Exception
            FileBrowser.Dispose()
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub GlassButton2_Click(sender As Object, e As EventArgs) Handles GlassButton2.Click
        Dim FB As New FolderBrowserDialog()
        FB.Description = "Selecione a Pasta a Salvar"

        FB.RootFolder = Environment.SpecialFolder.MyComputer
        FB.ShowNewFolderButton = True
        Try
            FB.ShowDialog()
            Dim Path As String = FB.SelectedPath.ToString
            TextBox2.Text = Path
            FB.Dispose()
            Path = Nothing
        Catch Erro As Exception
            MsgBox("Erro ao Criptografar Arquivo " & Erro.Message)
        End Try

    End Sub

    Private Sub GlassButton3_Click(sender As Object, e As EventArgs) Handles GlassButton3.Click
        Dim Encrypt As New MyEncryptor(TextBox3.Text) : Dim Arquivo As String = TextBox1.Text : Dim PastaSave As String
        PastaSave = TextBox2.Text
        Encrypt.Encrypt(Arquivo, PastaSave & Arquivo)


    End Sub
End Class