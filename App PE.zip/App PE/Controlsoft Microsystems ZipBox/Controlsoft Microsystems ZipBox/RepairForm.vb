﻿'/// Formulário de Reparo de Arquivos 
'/// Abre com arquivos selecionados ou só com um arquivo
'/// verifica primeiro se um arquivo pode ser acessado 
'/// Se não por segurança e o usuário for administrador 
'/// pede para o usuário reiniciar como Administrador e refazer novamente
'/// Se o arquivo não pode ser acessado por ter outro processo 
'/// usando avisa o usuário que tem outro processo usando o arquivo 
'/// se ele deseja fechar e mostra o nome do processo , se falhar
'/// mostra mensagem que não é possível tentar reparar o arquivo 

Partial Public Class RepairForm

Private Enum ErrorType
PictureCorrupted 
ZipFileCorrupted 
WinPECorrupted 
AndroidAppCorrupted
MacOsAppCorrupted
RarFileCorrupted
PosCompressionCorrupted 
JarCorrupted 
ZipLostPassword
RarLostPassword
FileWithOutExtension - 'arquivo sem extensão
DocxCorrupted
PdfCorrupted
HtmlCorrupted 
VideoFileCorrupted
AudioFilecorrupted 
End Enum

'Reparar Imagen

Private Sub PictureRepair (FileName As String , OutPath As String)
If FileName = Nothing Then
MsgBox("Selecione o arquivo pra tentar reparar")

Elseif OutPath = Nothing Then ' se não ten onde salvar
Dim PathToSave As String = Environment.GetFolderPath(MyPictures)
Try
If Not File.Exists(PathToSave + "/" + Path.GetFileName(FileName) Then
Directory.Create(PathToSave & "/" + Path.GetFileName(FileName)
Else 
End If 

Catch Ex As Exception 
End Try


End If 
End Sub





    Private Sub GlassButton1_Click(sender As Object, e As EventArgs) Handles GlassButton1.Click
        Dim OpenFile As New OpenFileDialog()
        OpenFile.Multiselect = False
        OpenFile.CheckFileExists = True
        OpenFile.CheckPathExists = True
        OpenFile.Title = "Selecione o Arquivo corrompido"
        Try
            OpenFile.ShowDialog()
            Dim Arquivo As String = OpenFile.FileName
            TextBox1.Text = Arquivo
            Label1.Text = "Reparando " & Arquivo
        Catch ex As Exception

        End Try
    End Sub

    Private Sub GlassButton4_Click(sender As Object, e As EventArgs) Handles GlassButton4.Click
        TextBox1.Text = ""
        Me.Close()
        Me.Dispose()
    End Sub

    Private Sub GlassButton3_Click(sender As Object, e As EventArgs) Handles GlassButton3.Click
        Dim FileAndExt As String = TextBox1.Text : Dim IsRar As Boolean = False
        Dim FilePath As String = IO.Path.GetFileName(FileAndExt)
        If FilePath.EndsWith(".rar") Then
            IsRar = True
            RepairRAROrZip()
            'O Rar.exe Repara Arquivos Rar e deve reparar Zip 
        ElseIf FilePath.EndsWith(".zip") Then
        End If
    End Sub

    Private Sub RepairRAROrZip()

    End Sub
End Class
