﻿


Imports System.IO
Imports System.Security.Cryptography
Imports System.Text

Public Class MyEncryptor
    ' Internal value of the phrase used to generate the secret key
    Private _Phrase As String = ""
    'contains input file path and name
    Private _inputFile As String = ""
    'contains output file path and name
    Private _outputFile As String = ""
    Private Enum TransformType
        ENCRYPT = 0
        DECRYPT = 1
    End Enum

    ''' <value>Set the phrase used to generate the secret key.</value>
    Public WriteOnly Property Phrase() As String
        Set
            Me._Phrase = Value
            Me.GenerateKey(Me._Phrase)
        End Set
    End Property

    ' Internal initialization vector value to 
    ' encrypt/decrypt the first block
    Private _IV As Byte()

    ' Internal secret key value
    Private _Key As Byte()

    ''' <summary>
    ''' Constructor
    ''' </summary>
    ''' <param name="SecretPhrase">Secret phrase to generate key</param>
    Public Sub New(SecretPhrase As String)
        Me.Phrase = SecretPhrase
    End Sub

    ''' <summary>
    ''' Encrypt the given value with the Rijndael algorithm.
    ''' </summary>
    ''' <param name="EncryptValue">Value to encrypt</param>
    ''' <returns>Encrypted value. </returns>
    Public Function Encrypt(EncryptValue As String) As String
        Try
            If EncryptValue.Length > 0 Then
                ' Write the encrypted value into memory
                Dim input As Byte() = Encoding.UTF8.GetBytes(EncryptValue)

                ' Retrieve the encrypted value and return it

                Return (Convert.ToBase64String(Transform(input, TransformType.ENCRYPT)))
            Else
                Return ""
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' Decrypt the given value with the Rijndael algorithm.
    ''' </summary>
    ''' <param name="DecryptValue">Value to decrypt</param>
    ''' <returns>Decrypted value. </returns>
    Public Function Decrypt(DecryptValue As String) As String

        Try
            If DecryptValue.Length > 0 Then
                ' Write the encrypted value into memory                    
                Dim input As Byte() = Convert.FromBase64String(DecryptValue)

                ' Retrieve the decrypted value and return it

                Return (Encoding.UTF8.GetString(Transform(input, TransformType.DECRYPT)))
            Else
                Return ""
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' Encrypt the given value with the Rijndael algorithm.
    ''' </summary>
    ''' <param name="EncryptValue">Value to encrypt</param>
    ''' <returns>Encrypted value. </returns>
    Public Sub Encrypt(InputFile As String, OutputFile As String)

        Try
            If (InputFile IsNot Nothing) AndAlso (InputFile.Length > 0) Then
                _inputFile = InputFile
            End If
            If (OutputFile IsNot Nothing) AndAlso (OutputFile.Length > 0) Then
                _outputFile = OutputFile
            End If
            Transform(Nothing, TransformType.ENCRYPT)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    ''' <summary>
    ''' Decrypt the given value with the Rijndael algorithm.
    ''' </summary>
    ''' <param name="DecryptValue">Value to decrypt</param>
    ''' <returns>Decrypted value. </returns>
    Public Sub Decrypt(InputFile As String, OutputFile As String)

        Try
            If (InputFile IsNot Nothing) AndAlso (InputFile.Length > 0) Then
                _inputFile = InputFile
            End If
            If (OutputFile IsNot Nothing) AndAlso (OutputFile.Length > 0) Then
                _outputFile = OutputFile
            End If
            Transform(Nothing, TransformType.DECRYPT)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    '****************************************************************
    '         * Generate an encryption key based on the given phrase.  The 
    '         * phrase is hashed to create a unique 32 character (256-bit) 
    '         * value, of which 24 characters (192 bit) are used for the
    '         * key and the remaining 8 are used for the initialization 
    '         * vector (IV).
    '         * 
    '         * Parameters:  SecretPhrase - phrase to generate the key and 
    '         * IV from.
    '         * 
    '         * Return Val:  None  
    '         **************************************************************

    Private Sub GenerateKey(SecretPhrase As String)
        ' Initialize internal values
        Me._Key = New Byte(23) {}
        Me._IV = New Byte(15) {}

        ' Perform a hash operation using the phrase.  This will 
        ' generate a unique 32 character value to be used as the key.
        Dim bytePhrase As Byte() = Encoding.ASCII.GetBytes(SecretPhrase)
        Dim sha384 As New SHA384Managed()
        sha384.ComputeHash(bytePhrase)
        Dim result As Byte() = sha384.Hash

        ' Transfer the first 24 characters of the hashed value to the key
        ' and the remaining 8 characters to the intialization vector.
        For [loop] As Integer = 0 To 23
            Me._Key([loop]) = result([loop])
        Next
        For [loop] As Integer = 24 To 39
            Me._IV([loop] - 24) = result([loop])
        Next
    End Sub

    '****************************************************************
    '         * Transform one form to anoter based on CryptoTransform
    '         * It is used to encrypt to decrypt as well as decrypt to encrypt
    '         * Parameters:  input [byte array] - which needs to be transform 
    '         *              transformType - encrypt/decrypt transform
    '         * 
    '         * Return Val:  byte array - transformed value.
    '         **************************************************************

    Private Function Transform(input As Byte(), transformType__1 As TransformType) As Byte()
        Dim cryptoStream As CryptoStream = Nothing
        ' Stream used to encrypt
        Dim rijndael As RijndaelManaged = Nothing
        ' Rijndael provider
        Dim rijndaelTransform As ICryptoTransform = Nothing
        ' Encrypting object            
        Dim fsIn As FileStream = Nothing
        'input file
        Dim fsOut As FileStream = Nothing
        'output file
        Dim memStream As MemoryStream = Nothing
        ' Stream to contain data
        Try
            ' Create the crypto objects
            rijndael = New RijndaelManaged()
            rijndael.Key = Me._Key
            rijndael.IV = Me._IV
            If transformType__1 = TransformType.ENCRYPT Then
                rijndaelTransform = rijndael.CreateEncryptor()
            Else
                rijndaelTransform = rijndael.CreateDecryptor()
            End If

            If (input IsNot Nothing) AndAlso (input.Length > 0) Then
                memStream = New MemoryStream()
                cryptoStream = New CryptoStream(memStream, rijndaelTransform, CryptoStreamMode.Write)

                cryptoStream.Write(input, 0, input.Length)

                cryptoStream.FlushFinalBlock()


                Return memStream.ToArray()
            ElseIf (_inputFile.Length > 0) AndAlso (_outputFile.Length > 0) Then
                ' First we are going to open the file streams 
                fsIn = New FileStream(_inputFile, FileMode.Open, FileAccess.Read)
                fsOut = New FileStream(_outputFile, FileMode.OpenOrCreate, FileAccess.Write)

                cryptoStream = New CryptoStream(fsOut, rijndaelTransform, CryptoStreamMode.Write)

                ' Now will will initialize a buffer and will be 
                ' processing the input file in chunks. 
                ' This is done to avoid reading the whole file (which can be
                ' huge) into memory. 
                Dim bufferLen As Integer = 4096
                Dim buffer As Byte() = New Byte(bufferLen - 1) {}
                Dim bytesRead As Integer
                Do
                    ' read a chunk of data from the input file 
                    bytesRead = fsIn.Read(buffer, 0, bufferLen)
                    ' Encrypt it 

                    cryptoStream.Write(buffer, 0, bytesRead)
                Loop While bytesRead <> 0

                cryptoStream.FlushFinalBlock()
            End If

            Return Nothing
        Catch generatedExceptionName As CryptographicException
            Throw New CryptographicException("Password is invalid. Please verify once again.")
        Finally
            If rijndael IsNot Nothing Then
                rijndael.Clear()
            End If
            If rijndaelTransform IsNot Nothing Then
                rijndaelTransform.Dispose()
            End If
            If cryptoStream IsNot Nothing Then
                cryptoStream.Close()
            End If
            If memStream IsNot Nothing Then
                memStream.Close()
            End If
            If fsOut IsNot Nothing Then
                fsOut.Close()
            End If
            If fsIn IsNot Nothing Then
                fsIn.Close()
            End If
        End Try
    End Function

End Class
