'
'Copyright (c)  2008-2009,Domagoj Pintaric
'SharpArchiver is distributed under the terms of the GNU Lesser General Public License
'
'    This file is part of SharpArchiver.
'
'    SharpArchiver is free software: you can redistribute it and/or modify
'    it under the terms of the GNU Lesser General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    SharpArchiver is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with SharpArchiver.  If not, see <http://www.gnu.org/licenses/>.
'
'


Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text

''' <summary>
''' Create a New INI file to store or load data
''' </summary>
Public Class IniFile
	Public path As String

	<DllImport("kernel32")> _
	Private Shared Function WritePrivateProfileString(section As String, key As String, val As String, filePath As String) As Long
	End Function
	<DllImport("kernel32")> _
	Private Shared Function GetPrivateProfileString(section As String, key As String, def As String, retVal As StringBuilder, size As Integer, filePath As String) As Integer
	End Function

	''' <summary>
	''' INIFile Constructor.
	''' </summary>
	''' <param name="INIPath"></param>
	Public Sub New(INIPath As String)
		path = INIPath
	End Sub
	''' <summary>
	''' Write Data to the INI File
	''' </summary>
	''' <param name="Section"></param>
	''' Section name
	''' <param name="Key"></param>
	''' Key Name
	''' <param name="Value"></param>
	''' Value Name
	Public Sub IniWriteValue(Section As String, Key As String, Value As String)
		WritePrivateProfileString(Section, Key, Value, Me.path)
	End Sub

	''' <summary>
	''' Read Data Value From the Ini File
	''' </summary>
	''' <param name="Section"></param>
	''' <param name="Key"></param>
	''' <param name="Path"></param>
	''' <returns></returns>
	Public Function IniReadValue(Section As String, Key As String) As String
		Dim temp As New StringBuilder(255)
		Dim i As Integer = GetPrivateProfileString(Section, Key, "", temp, 255, Me.path)
		Return temp.ToString()

	End Function

	Public Sub IniClearText(filePath As String)
		File.WriteAllText(filePath, "")
	End Sub
End Class
