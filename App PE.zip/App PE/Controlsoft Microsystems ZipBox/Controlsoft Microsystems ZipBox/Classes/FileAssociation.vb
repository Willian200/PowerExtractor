'
'Copyright (c)  2008-2009,Domagoj Pintaric
'SharpArchiver is distributed under the terms of the GNU Lesser General Public License
'
'    This file is part of SharpArchiver.
'
'    SharpArchiver is free software: you can redistribute it and/or modify
'    it under the terms of the GNU Lesser General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    SharpArchiver is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with SharpArchiver.  If not, see <http://www.gnu.org/licenses/>.
'
'

Imports Microsoft.Win32
Imports System.IO
Imports Cake3
Imports System.Windows.Forms

''' <summary>
''' Description of FileAssociation.
''' </summary>
Public Class FileAssociation


	Public Sub Associate(ext As String)
		Dim wkey As RegistryKey = Registry.ClassesRoot
		wkey = wkey.CreateSubKey(ext)
		'.SetValue("", "SharpArchiver");
		wkey.SetValue("", "SharpArchiver")
		wkey.CreateSubKey("DefaultIcon").SetValue("", Utils.GetProgramPath() & "Icons\" & ext.Substring(1).ToUpper() & "Icon.ico")
		wkey = wkey.CreateSubKey("shell")
		Dim keycmd As RegistryKey = wkey.CreateSubKey("Open")
		keycmd.SetValue("", "Open")
		keycmd.CreateSubKey("Command").SetValue("", """" & Utils.GetProgramPath() & "SharpArchiver.exe" & """ ""%1""")


	End Sub
	Public Sub Unassociate(ext As String)

		Dim wkey As RegistryKey = Registry.ClassesRoot
		If wkey.OpenSubKey(ext, False) IsNot Nothing Then
			wkey.DeleteSubKeyTree(ext)
		End If

	End Sub

	Public Sub isAssociated()
	' dali je sharparchiver ascociran sa podrzanim fajlovima
		Dim ext As String() = New String() {".zip", ".7z", ".tar", ".gz", ".bz2", ".arc", _
			".arj", ".asd", ".ace", ".mime", ".b64", ".bel", _
			".deb", ".yz1", ".f", ".frz", ".icl", ".ico", _
			".cab", ".jam", ".lha", ".lzh", ".lzs", ".hqx", _
			".cpt", ".dmg", ".pit", ".pak", ".wad", ".rar", _
			".rpm", ".sqx", ".macbin", ".cpio", ".shar", ".uue", _
			".xxe", ".imp", ".yenc", ".zoo", ".ear", ".jar", _
			".war", ".wsz", ".mskin", ".bzs", ".wal", ".wmz", _
			".sae"}
		Dim extbr As Integer = 0
		Dim wkey As RegistryKey = Registry.ClassesRoot
		For i As Integer = 0 To ext.Length - 1
			Dim readvalue As RegistryKey = Registry.ClassesRoot.CreateSubKey(ext(i))
			If wkey.OpenSubKey(ext(i), False) IsNot Nothing Then
				If readvalue.GetValue("", "").ToString() = "SharpArchiver" Then
					extbr += 1
				End If
			End If
			readvalue.Close()
		Next
		If extbr = 0 Then
			If MessageBox.Show("SharpArchiver is not associated with suported files." & vbCr & " Do you wish to associate now?", "SharpArchiver", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = DialogResult.Yes Then
				Dim [of] As New OptionsForm(2)

				[of].ShowDialog()

			End If
		End If
	End Sub
End Class
