﻿'
' Created by SharpDevelop.
' User: joaopaulo
' Date: 13/01/2017
' Time: 06:32
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class EmuleISO
    Inherits Metro.Form
    ''' <summary>
    ''' Designer variable used to keep track of non-visual components.
    ''' </summary>
    Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.GGlowBox2 = New gGlowBox.gGlowBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GlassButton2 = New Glass.GlassButton()
        Me.GGlowBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GGlowBox2
        '
        Me.GGlowBox2.Controls.Add(Me.TextBox2)
        Me.GGlowBox2.Location = New System.Drawing.Point(20, 73)
        Me.GGlowBox2.Name = "GGlowBox2"
        Me.GGlowBox2.Size = New System.Drawing.Size(403, 27)
        Me.GGlowBox2.TabIndex = 23
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.ForeColor = System.Drawing.Color.Gray
        Me.TextBox2.Location = New System.Drawing.Point(4, 4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(396, 22)
        Me.TextBox2.TabIndex = 11
        Me.TextBox2.Text = "Selecione a Pasta a Salvar"
        '
        'GlassButton2
        '
        Me.GlassButton2.Location = New System.Drawing.Point(429, 73)
        Me.GlassButton2.Name = "GlassButton2"
        Me.GlassButton2.Size = New System.Drawing.Size(40, 23)
        Me.GlassButton2.TabIndex = 22
        Me.GlassButton2.Text = "..."
        '
        'EmuleISO
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(496, 328)
        Me.Controls.Add(Me.GGlowBox2)
        Me.Controls.Add(Me.GlassButton2)
        Me.MaximizeBox = False
        Me.Name = "EmuleISO"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Emular Disco ISO "
        Me.Controls.SetChildIndex(Me.GlassButton2, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox2, 0)
        Me.GGlowBox2.ResumeLayout(False)
        Me.GGlowBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GGlowBox2 As gGlowBox.gGlowBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GlassButton2 As Glass.GlassButton
End Class
