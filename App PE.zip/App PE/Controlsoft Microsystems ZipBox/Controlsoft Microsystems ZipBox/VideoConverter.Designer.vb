﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class VideoConverter
    Inherits Metro.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(VideoConverter))
        Me.openfile = New System.Windows.Forms.OpenFileDialog()
        Me.savefile = New System.Windows.Forms.SaveFileDialog()
        Me.bworker = New System.ComponentModel.BackgroundWorker()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.qal = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tovid = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.from = New System.Windows.Forms.TextBox()
        Me.status = New System.Windows.Forms.Label()
        Me.ProgressIndicator1 = New ProgressControls.ProgressIndicator()
        Me.convert = New Glass.GlassButton()
        Me.Button3 = New Glass.GlassButton()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'bworker
        '
        Me.bworker.WorkerReportsProgress = True
        Me.bworker.WorkerSupportsCancellation = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.qal)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.tovid)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.from)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 31)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(450, 100)
        Me.GroupBox1.TabIndex = 15
        Me.GroupBox1.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label4.Location = New System.Drawing.Point(285, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 15)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "Quality:"
        '
        'qal
        '
        Me.qal.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.qal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.qal.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.qal.FormattingEnabled = True
        Me.qal.Items.AddRange(New Object() {"High", "Optimal", "Medium", "Low"})
        Me.qal.Location = New System.Drawing.Point(340, 61)
        Me.qal.Name = "qal"
        Me.qal.Size = New System.Drawing.Size(100, 23)
        Me.qal.TabIndex = 17
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label2.Location = New System.Drawing.Point(6, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 15)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Format:"
        '
        'tovid
        '
        Me.tovid.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.tovid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.tovid.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.tovid.FormattingEnabled = True
        Me.tovid.Items.AddRange(New Object() {"iPod Video (Apple QuickTime .MOV)", "iPhone Video (MPEG-4 .MP4)", "Windows Media Video (V.7 .WMV)", "Xvid MPEG-4 Codec (.AVI)", "MPEG Audio Layer 3 (.MP3)", "Matroska Multimedia Container (.MKV)", "Flash Video Codec (.FLV)", "WebM Video (.WEBM)"})
        Me.tovid.Location = New System.Drawing.Point(60, 61)
        Me.tovid.Name = "tovid"
        Me.tovid.Size = New System.Drawing.Size(219, 23)
        Me.tovid.TabIndex = 15
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Button1.Location = New System.Drawing.Point(409, 30)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(31, 22)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "..."
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 15)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Input video:"
        '
        'from
        '
        Me.from.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.from.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.from.Location = New System.Drawing.Point(9, 32)
        Me.from.Name = "from"
        Me.from.Size = New System.Drawing.Size(394, 22)
        Me.from.TabIndex = 12
        '
        'status
        '
        Me.status.AutoSize = True
        Me.status.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.status.Location = New System.Drawing.Point(390, 15)
        Me.status.Name = "status"
        Me.status.Size = New System.Drawing.Size(74, 15)
        Me.status.TabIndex = 17
        Me.status.Text = "Converting..."
        Me.status.Visible = False
        '
        'ProgressIndicator1
        '
        Me.ProgressIndicator1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ProgressIndicator1.Location = New System.Drawing.Point(303, 146)
        Me.ProgressIndicator1.Name = "ProgressIndicator1"
        Me.ProgressIndicator1.Percentage = 0!
        Me.ProgressIndicator1.Size = New System.Drawing.Size(153, 153)
        Me.ProgressIndicator1.TabIndex = 18
        Me.ProgressIndicator1.Text = "ProgressIndicator1"
        '
        'convert
        '
        Me.convert.Location = New System.Drawing.Point(16, 231)
        Me.convert.Name = "convert"
        Me.convert.Size = New System.Drawing.Size(124, 22)
        Me.convert.TabIndex = 20
        Me.convert.Text = "Converter"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(16, 259)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(124, 22)
        Me.Button3.TabIndex = 21
        Me.Button3.Text = "Sair"
        '
        'VideoConverter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(504, 304)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.convert)
        Me.Controls.Add(Me.ProgressIndicator1)
        Me.Controls.Add(Me.status)
        Me.Controls.Add(Me.GroupBox1)
        Me.ForeColor = System.Drawing.Color.Silver
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "VideoConverter"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Vídeo Converter"
        Me.Controls.SetChildIndex(Me.GroupBox1, 0)
        Me.Controls.SetChildIndex(Me.status, 0)
        Me.Controls.SetChildIndex(Me.ProgressIndicator1, 0)
        Me.Controls.SetChildIndex(Me.convert, 0)
        Me.Controls.SetChildIndex(Me.Button3, 0)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents openfile As System.Windows.Forms.OpenFileDialog
    Friend WithEvents savefile As System.Windows.Forms.SaveFileDialog
    Friend WithEvents bworker As System.ComponentModel.BackgroundWorker
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents qal As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tovid As System.Windows.Forms.ComboBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents from As System.Windows.Forms.TextBox
    Friend WithEvents status As System.Windows.Forms.Label
    Friend WithEvents ProgressIndicator1 As ProgressControls.ProgressIndicator
    Friend WithEvents convert As Glass.GlassButton
    Friend WithEvents Button3 As Glass.GlassButton
End Class
