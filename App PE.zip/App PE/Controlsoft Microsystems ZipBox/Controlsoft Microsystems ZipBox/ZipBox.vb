﻿Imports SevenZip
Imports System.IO
Imports System.Collections.Generic
Imports System.Net
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Threading
Imports System.Windows.Forms
Imports System.Reflection
Imports System.Diagnostics
Imports System.Security
Imports System.Runtime.InteropServices
Imports System.Security.Principal
Imports System.ComponentModel
Imports System.Data
Imports System.Text
Imports ComponentFactory.Krypton.Toolkit

'Translate comments If your language Is Not Portuguese


'/// Public EmOperacao As Boolean 
'/// se o aplicativo estiver em operação ele não fecha , apenas minimiza


'Remove Duplicados e Duplicados dentro de Comprimidos
'Remove Imagens Duplicadas de Diferentes Tamanhos
'Criptografia Avançada de Dados
'Remoçao de Dados com Segurança
'Reparo de Dados Danificados em Várias Extensões
'Gerenciamento Avançado de Arquivos 
'Conversão de Aúdio , Documento , Imagem , Vídeo 
'Apaga Pastas Vazias 
'Divide Arquivos 

'Remove Duplicates And Duplicates Within Tablets
''Remove Duplicate Images of Different Sizes
'Advanced Data Encryption
'Safe Data Removal
''Repairing Damaged Data Over Multiple Extensions
'Advanced File Management
''Audio Conversion, Document, Image, Video
''Delete Empty Folders
''Divide Files

Public Class ZipBox


    'Private Sub MakeSFX(File As String , SavePath As String)
    'Try
    'Dim compressor As SevenZipSfx = New SevenZipSfx(SfxModule.Default)
    '        compressor.ModuleFileName = "7z.sfx"
    '        compressor.MakeSfx(File , File + Path.GetFileName(File) & .exe))
    ' MsgBox("Criado com sucesso", MsgBoxStyle.Information)

    'Catch ex As Exception
    ' MsgBox("Erro " + ex.Message)

    'End Sub 

    'Dim compressor As SevenZipSfx = New SevenZipSfx("7z.sfx")
    '    compressor.ModuleFileName = "7z.sfx"
    '   compressor.MakeSfx("C:\Temp\cc_seal.7z", "C:\Temp\sfxseal.exe")
    '    End Sub

    '#Region "Parte do SharpArchiver que Deleta Arquivos"

    '    Private Sub RemoverTodosClick(sender As Object, e As EventArgs) Handles RBTNRemoveAll.Click
    '    If Listview
    '///Verifica se o arquivo selecionado é dentro de um comprimido 
    '/// se sim remove apenas ele e os selecionados se estão sendo usados 
    '///alerta o usuário e pergunta secele quer fechar , se sim fecha , se não termina operação
    '/// se são arquivos soltos , verifica se não estão sendo usados por
    '/// nenhum processo e remove 
    '///



    Private Sub DeleteArchiveClick(sender As Object, e As EventArgs)


        '    Dim filePath As String = toolStripLabel1.Text
    End Sub



    '///  Abrir formulário de backup com os arquivos selecionados e pastas
    '/// Se nenhum arquivo tiver Selecionado , abre apenas o formulário
    ' /// se os arquivos estiverem dentro de comprimidos seleciona eles e 
    '/// se forem diretórios dentro de comprimido seleciona eles.
    '/// com o endereço.
    '
    Private Sub RBTNBackupClick(sender As Object, e As EventArgs) Handles RBTNBackup.Click
       Try

        Catch ex As Exception

        End Try
    End Sub
   
   
   '/// se multiplos arquivos estão selecionados e o tamanho deles é maior que o limite permitido 
   '/// no email usado no aplicativo , avisa o usuário 
   '/// se forem menores mesmo com seu tamanho calculado * abre o formulário de email com onime dele
   ' /// Carregado
   
   '/// Verifica se o arquivo é maior de 20 MB 
   ' /// Se sim pergunta se o usuário quer dividir o arquivo porque é maior que o limite pra enviar , abre o split com o arquivo carregado
   '/// Se não , termina a operação
   
   '// /abrir formulário de enviar arquivo , com arquivos selecionados , se não tiver
   '/// arquivos selecionados abre o formulário de enviar arquivo  por email
   
   ' 
 Private Sub RBTNSendClick(sender As Object, e As EventArgs) Handles RBTNSend.Click
        Try
        Catch ex As Exception
        End Try
    End Sub
    
    '/// Abre o formulário de propriedades do arquivo o do Windows ou do aplicativo 
    ' /// de acordo com o que foi configurado nas configurações 
    '/// e o formulário não abrir , abre um mini formulário com informações do arquivo
    Private Sub InfoClick(sender As Object, e As EventArgs) Handles RBTNInfo.Click
        Try
        Catch ex As Exception
        End Try
    End Sub
    
    '///  Testa arquivos selecionados , se nenhum arquivo tiver selecionado avisa
    ' /// o usuário , se o usuário estiver navegando no interior de um arquivo testa ele
    '/// se uma lista estiver selecionado , testa um a um em loop 
    '/// se houver mais de um corrompido faz uma lista de corrompidos e exibe
    '/// em um Listbox , também há o botão reparar.
    
    '/// se o arquivo não puder ser lido avisa o usuáriose ele quer fechar o app que usa o arquivo 
    '///  se sim fecha , se não , termina a operação 
    Private Sub TestarClick(sender As Object, e As EventArgs) Handles RBTNTestar.Click


    End Sub

  '/// Seleciona todos arquivos  exceto Extensão 
  '/// Seleciona todos arquivos somente com extensão
  '/// Seleciona todos arquivos criados ou alterados  acessados entre ou em determinada data 
  '/// seleciona todos arquivos maior , menor ou igual determinado tamanho 
  '/// seleciona apenas arquivos com nome que encaixa em uma combinação de caracteres.
  
  Private Sub SelectAllClick(sender As Object, e As EventArgs) Handles RBTNSelecionarTudo.Click
        Try
        Catch ex As Exception
        End Try
    End Sub




'/// Scaneia arquivo e retorna se é um virus ou não

'/// Scaneia o arquivo no AV selecionado 
'/// verifica se o arquivo pode ser lido se sim 
' /// verifica o arquivo no VirusTotal e abre formulário com detecções se houve 
'/// ou apenas exibe mensagem que o arquivo é seguro

    Private Sub ScanFile(sender As Object, e As EventArgs) Handles RBTNScan.Click
        Try
        
        Catch ex As Exception
        End Try
    End Sub
    
'/// abre arquivo ou arquivos com o programa selecionado
'/// Mostra uma lista de programas pra tentar abrir o arquivo 
'/// junto com opção de abrir sempre com aquele programa 
Private Sub OpenWithClick(sender As Object, e As EventArgs) Handles RBTNOpen.Click
        Try
        Catch ex As Exception
        End Try
    End Sub
  
'/// converte arquivos de imagem selecionados , ou arquivos de imagem dentro
'/// das pastas e subpastas selecionadas ,  adiciona o mesmo nome.
'/// se os arquivos não puderem ser acessados avisa o usuário
'/// Se os arquivos selecionados não forem imagem , avisa o usuário
Private Sub ConvertImageClick(sender As Object, e As EventArgs) Handles RBTNConvertImage.Click
        Try
        Catch ex As Exception
        End Try
    End Sub
    
    '/// verifica se o ou os arquivos podem ser acessados
    '/// se não por ter sendo usado pergunta se o usuário quer fechar o processo 
    '/// se não possuir permissões pergunta se o usuário quer tentar remover permissões
    ' /// abre o Pandoc e envia os argumentos para conversão 
    '/// de um arquivo ou de uma lista
    '/// a viariavel Pública EmOperacao é definida como True
    
    Private Sub ConvertDocumentClick(sender As Object, e As EventArgs) Handles RBTNConvertDoc.Click
        Try
        Catch ex As Exception
        End Try
    End Sub

'/// verifica se o ou os arquivos podem ser acessados
    '/// se não por ter sendo usado pergunta se o usuário quer fechar o processo 
    '/// se não possuir permissões pergunta se o usuário quer tentar remover permissões
    ' /// abre o Fmjpeg e envia os argumentos para conversão 
    
    Private Sub Convert_VideoClick(sender As Object, e As EventArgs) Handles RBTNConvertVideo.Click
        Try
        Catch ex As Exception
        End Try
    End Sub
    
    '/// verifica se o ou os arquivos podem ser acessados
    '/// se não por ter sendo usado pergunta se o usuário quer fechar o processo 
    '/// se não possuir permissões pergunta se o usuário quer tentar remover permissões
    ' /// abre o Pandoc e envia os argumentos para conversão 
    
    Private Sub ConvertAudioClick(sender As Object, e As EventArgs) Handles RBTNConvertAudio.Click
        Try
        Catch ex As Exception
        End Try
    End Sub
    
'/// Verifica se o arquivo pode ser convertido pelo Cake 
'/// Opção aparece apenas se a extensão for suportada
    '/// se o usuário não tem permissões pra usar , pergunta se quer desbloquear
    '/// se não der , verifica se o aplicativo está rodando como administrador
    '/// se não pergunta se o usuário quer reiniciar como administrador
    '/// se sim reinicia , se não termina operação.

Private Sub ConvertFileClick(sender As Object, e As EventArgs) Handles RBTNConvertFile.Click
        Try
        Catch ex As Exception
        End Try
    End Sub
   
' /// Verifica se os arquivos podem ser acessados se sim 
' um a um 
    '/// se o usuário não tem permissões pra usar , pergunta se quer desbloquear
    '/// se não der , verifica se o aplicativo está rodando como administrador
    '/// se não pergunta se o usuário quer reiniciar como administrador
    '/// se sim reinicia , se não termina operação.
'/// converte usando Cake

 Private Sub ConvertAllClick(sender As Object, e As EventArgs) Handles RBTNConvertAll.Click
        Try
        Catch ex As Exception
        End Try
    End Sub



    Public Function Test(ByVal File As String) As Boolean
        Dim Sevenzip As New SevenZipExtractor(File)
        Return Sevenzip.Check()
    End Function
    Public Sub SetLibraryPath()
        Try
            Dim AppPath As String = Nothing
            AppPath = Application.StartupPath & "\7z.dll"
            SevenZip.SevenZipCompressor.SetLibraryPath(@"C:\Program Files (x86)\7-Zip\7z.dll");
            SevenZip.SevenZipExtractor.SetLibraryPath(AppPath)
        Catch ex As Exception
        End Try
    End Sub
    
    '/// abre o formulário de compressão com os arquivos selecionados 
    '/// se o arquivo já está no formato no qual o arquivo quer comprimir
    '/// Alerta o usuário 
    Private Sub ComprimirClick(sender As Object, e As EventArgs) Handles RBNButtonComprimir.Click
        Dim Comprimir As New compress(Me)
        Comprimir.Show()
    End Sub

'/// Retorna o arquivo de log
    Public Shared Function GetLogFile() As String
        Dim Created As Boolean = False
        Dim LogFile As String = Application.StartupPath + "\logfile.txt"
        Try
            If File.Exists(LogFile) Then
                Return LogFile.ToString()
            Else
                File.Create(LogFile)

            End If
        Catch ErroSecure As SecurityException
        'Pergunta se o usuário quer reiniciar como administrador
            MsgBox("O Arquivo de Log não pode ser Escrito , reinicie o App como Administrador", MsgBoxStyle.Information)
            Return Nothing
        Catch IOExp As IOException
	        
            MsgBox("Erro ao Criar Arquivo de Log o Arquivo de Log não será Escrito" & Space(1) & IOExp.ToString(), MsgBoxStyle.Information)
            Return Nothing
        Catch Expp As AccessViolationException
            MsgBox(Expp.ToString(), MsgBoxStyle.Information)
            Return Nothing
        End Try
    End Function
    
    '/// Abre o split com os arquivos selecionados
    '/// se o arquivo selecionado for um diretório pergunta se o usuário quer dividir em volumes
    '/// Verifica se arquivo pode ser lido , se processo tiver usando pergunta se o usuário
    '/// quer fechar , se sim fecha , se não avisa que o arquivo só poderá
    '/// ser dívidido quando o processo não estiver usando o arquivo.
    '/// se o usuário não tem permissões pra usar , pergunta se quer desbloquear
       '/// se o usuário não tem permissões pra usar , pergunta se quer desbloquear
    '/// se não der , verifica se o aplicativo está rodando como administrador
    '/// se não pergunta se o usuário quer reiniciar como administrador
    '/// se sim reinicia , se não termina operação.
 Public Sub RBTNDividir_Click(ByVal sender As Object, e As EventArgs) Handles RBTNDividir.Click
        Try
            Dim Menusplit As New MainForm()
            Menusplit.Show()
        Catch Erro As Exception
        End Try
    End Sub

#Region "Estudo"
    Public Shared Sub Extrair(ByVal Arquivo As String, OutPath As String, Optional ByRef Pass As String = "")
        Dim ContemPassword As Boolean : If String.IsNullOrEmpty(Pass) Then : ContemPassword = False

            Dim Extrair As New SevenZipExtractor(Arquivo)
        Else
            ContemPassword = True
        End If
    End Sub

#End Region

'/// Verifica se arquivo pode ser lido , se processo tiver usando pergunta se o usuário
    '/// quer fechar , se sim fecha , se não avisa que o arquivo só poderá
    '/// ser dívidido quando o processo não estiver usando o arquivo.
    '/// se o usuário não tem permissões pra usar , pergunta se quer desbloquear
    '/// se não der , verifica se o aplicativo está rodando como administrador
    '/// se não pergunta se o usuário quer reiniciar como administrador
    '/// se sim reinicia , se não termina operação.
    Private Sub ConverterIMGClick(sender As Object, e As EventArgs) Handles RBTNConvertImage.Click
        Dim ImgConvert As New PictureConverter()
        ImgConvert.Show()
    End Sub

    Private Sub RibbonOrbOptionButton4Click(sender As Object, e As EventArgs) Handles RibbonOrbOptionButton4.Click
        Dim Setting As New Setting()
        Setting.Show()
    End Sub

    Public Shared Sub ExtrairArquivos(ByVal Arquivo As String, Destino As String, Optional ByRef Pass As String = "")
        Dim ContainsPass As Boolean = False : Dim tmp As New SevenZipExtractor(Arquivo)
        For i = 1 To tmp.ArchiveFileData.Count - 1
            tmp.ExtractFiles(Destino, tmp.ArchiveFileData(i).Index)

            'tmp.ExtractFiles(Destino, tmp.ArchiveFileData(i).Index)
            ContainsPass = tmp.ArchiveFileData(i).Encrypted
        Next
    End Sub

    'Multivolumes
    Private Sub ExtrairArquivos(ByVal Arquivo As String, ByVal Destino As String)
        Dim Tmp As New SevenZipExtractor(Arquivo)
        Try
            Tmp.ExtractArchive(Destino)
            
        Catch ex As Exception
        End Try
    End Sub
    Public Shared Sub Comprimir(ByVal Arquivo As String, ByVal Destino As String)

        Dim Tmp As New SevenZipCompressor()
        Tmp.ScanOnlyWritable = True  'Nome do Arquivo sem Extensão e coloca 7z
        Tmp.CompressFiles(Path.GetFileNameWithoutExtension(Arquivo) & ".7z")
        '     /*var tmp = New SevenZipCompressor();
        '//tmp.ScanOnlyWritable = true;
        '//tmp.CompressFiles(@"d:\Temp\arch.7z", @"d:\Temp\log.txt");
        '//tmp.CompressDirectory(@"c:\Program Files\Microsoft Visual Studio 9.0\Common7\IDE\1033", @"D:\Temp\arch.7z");
        'tmp.CompressDirectory(@"d:\Temp\!Пусто", @"d:\Temp\test.7z");
        '//*/
    End Sub


'/// Abrir Formulário  de enviar arquivo , com os arquivos selecionados 
'/// Se nenhum tiver selecionado seleciona a pasta corrente
    Public Sub SendClick(ByVal sender As Object, ByVal e As EventArgs) Handles RBTNSend.Click
        Dim Send As New FormSendFile()
        Send.Show()
    End Sub

'/// Verifica há arquivos selecionados 
'/// Se há , erifica se as extensões são suportadas
'/// Abre o formulário de conversão com os arquivos selecionados

    Public Sub ConvertDocClick(ByVal sender As Object, ByVal e As EventArgs) Handles RBTNConvertDoc.Click
        Dim DocConvert As New DocumentConvert()
        DocConvert.Show()
    End Sub

'/// Verifica se há arquivos selecionados
'/// se há , verifica se as extensões são suportadas 
'/// Abre formulário de conversão com os arquivos selecionados
    Private Sub ConvertVideoClick(sender As Object, e As EventArgs) Handles RBTNConvertVideo.Click
        Dim VideoConvert As New VideoConverter()
        VideoConvert.Show()
    End Sub

'/// Abre o Menu de encriptação com os arquivos e pastas selecionados
'/// Se nenhum arquivo estiver selecionado , apenas abre o Formulário
'/// Se pastas estiverem selecionadas adiciona ao formulário

    Private Sub EncriptarArquivoClick(sender As Object, e As EventArgs) Handles RBTNEncryptFile.Click
        Dim EncryptFileForm As New Protect()
        EncryptFileForm.Show()
    End Sub

'/// Algoritmo de comprimir arquivos retirado do StackOverflow
Public Shared Function CompressFile(Byval sender As Object , e As EventArgs) 
SevenZip.SevenZipCompressor.SetLibraryPath(System.AppDomain.CurrentDomain.BaseDirectory & "\SevenZipSharp.dll")
Dim theCompressor As New SevenZipCompressor()
            With theCompressor
                .ArchiveFormat = OutArchiveFormat.SevenZip
                .CompressionMode = CompressionMode.Create
                .CompressionMethod = CompressionMethod.Default
                .DirectoryStructure = False
                .CompressionLevel = CompressionLevel.Normal
            End With

theCompressor.CompressFilesEncrypted("c:\Archive\20130322.7z","c:\Backup\FULLBackup.bak")
End Function


    '"/// instância do form , verifica extensão do arquivo 
    '"Public Sub New(ByVal args As String())
    '            InitializeComponent()
    '            If args.Length > 0 Then
    '                If args.Length = 1 Then
    '                    If Path.GetExtension(args(0)) = ".x7" Then " X7 é o formato do app"

    'End Sub 


    '/// Verifica se o arquivo é de formato de texto 
    '/// Se sim abre , se não informa 

    '    Public Shared Sub OpenWithNotepad(File As String)
    'Try
    '    Dim proc As New System.Diagnostics.Process()
    'proc = Process.Start("d:\windows\notepad.exe", File)

    'Catch Ex As Exception 
    'MsgBox("o aplicativo não pode rodar o bloco de notas verifique as permissões")
    'Log.WriteInLog(" o Aplicativo não pode rodar o bloco de notas ")

    'End Try 



    '/// Abre o CMD e faz alterações no Registro pra estabilizar o sistema

    '    Public Function   EstabilizarSO ( ) 
    'System.Diagnostics.Process.Start("D:\estab.bat")
    'Shell("D:\2.bat", AppWinStyle.NormalFocus)
    'End Sub 

    'Private Sub CriarArquivoClick(Sender As Object , e As EventArgs) 
    'Dim Nome As String = InputBox("Digite o nome do Arquivo") 
    'Try
    'File.Create(PastaCorrente & "/" & Nome)
    'Catch ex As Exception 
    'MeuLog.Escrever(ex.Message.ToString())
    'End Try 

    '    End Sub


    '"O esquema de exceções copiei do App de dividir  arquivo "
    '    '" não terminado"

    '    Private Sub CriarDiretorioClick(Sender As Object , e As EventArgs)
    'Dim DiretorioCriado, FalhaNoNome ,ErroSeguranca , ErroDriverReadOnly, DriverNotFound , MemoryError As Boolean
    'Try
    'Dim DirName As String = InputBox("Digite o nome do diretório")
    'Directory.CreateDirectory(CurrentPath & DirName)

    'Catch ex As OutOfMemoryException
    '               MemoryError = True 
    '               Log.WriteInLog("Erro ao criar diretório , exceção de memória " & ex.Message)
    '         MsgBox.Show("Erro de memória ao criar arquivo " & ex.Message)

    '            Catch ex As IOException

    '            Catch ex As UnauthorizedAccessException
    '              ErroSeguranca = True 
    '              Log.WriteInLog("Erro de segurança no aplicativo ao tentar criar diretório " &  Ex.Message)
    '            Catch ex As SecurityException


    '    Private Sub Extract(FileName As String , OutPath As String)
    ' Dim Extractor As SevenZipExtractor = New SevenZipExtractor(FileName)
    ' Try
    ' For i = 0 To Extractor.ArchiveFileData.Count 
    ' Extractor.ExtractFiles(OutPath , Extractor.ArchiveFileData(I).Index

    ' Catch Ex As Exception 

    ' End Try 
    'End Sub 

    '"// para extrair mais de 1 de arquivo em
    'Um momento ou quando você definitivamente 
    'saber quais arquivos para extrair, "// usar algo como
    'Private Sub Extract(FileName As String , OutPath As String)
    'Dim Extractor As SevenZipExtractor = New SevenZipExtractor (FileName)
    '     Try
    'Catch Ex As Exception
    '   For I = 0 To Extractor.ArchiveFileData.Count
    'Extractor.ExtracFiles(OutPath , 1 , 3 , 5) 
    'End Try 
    'End Sub 


    Private Sub ExtrairMultivolume(File As String , OutPath As String) 
Dim Extractor As New SevenZipExtractor(File)
        Extractor.ExtractArchive(OutPath & "\" + Path.GetFileName(File).ToString)


    End Sub











    'Using system;
    'Using System.Collections.Generic;
    'Using System.IO;
    'Using System.Net;
    'Using System.Runtime.Serialization.Formatters.Binary;
    'Using System.Threading;
    'Using System.Windows.Forms;
    'Using System.Reflection;
    'Using SevenZip;
    'Using System.Diagnostics;

    'Namespace SevenZipTest
    '{
    '    Class Program
    '    {
    '        Static void Main(String[] args)
    '        {          
    '            Console.WriteLine("SevenZipSharp test application.");
    '            //Console.ReadKey();




    '            /*
    '             You may specify the custom path To 7-zip dll at SevenZipLibraryManager.LibraryFileName 
    '                Or call SevenZipExtractor.SetLibraryPath(@"c:\Program Files\7-Zip\7z.dll");
    '                Or call SevenZipCompressor.SetLibraryPath(@"c:\Program Files\7-Zip\7z.dll");
    '             You may check If your library fits your goals With
    '                (SevenZipExtractor/Compressor.CurrentLibraryFeatures & LibraryFeature.<name>) != 0
    '             Internal benchmark:
    '                var features = SevenZip.SevenZipExtractor.CurrentLibraryFeatures;
    '                Console.WriteLine(((uint)features).ToString("X6"));
    '            */

    '            #Region Temporary test
    '            var features = SevenZip.SevenZipExtractor.CurrentLibraryFeatures;
    '            Console.WriteLine(((uint)features).ToString("X6"));
    '            #endregion

    '            #region Extraction test - ExtractFiles
    '            /*using (var tmp = New SevenZipExtractor(@"d:\Temp\7z465_extra.7z"))
    '            {
    '                For (int i = 0; i < tmp.ArchiveFileData.Count; i++)
    '                {
    '                    tmp.ExtractFiles(@"d:\Temp\Result\", tmp.ArchiveFileData[i].Index);
    '                }
    '                // To extract more than 1 file at a time Or when you definitely know which files to extract,
    '                // use something Like
    '                //tmp.ExtractFiles(@"d:\Temp\Result", 1, 3, 5);
    '            }
    '            //*/
    '            #endregion

    '            #region Extraction test - multivolumes
    '            //SevenZipExtractor.SetLibraryPath(@"d:\Work\Misc\7zip\9.04\CPP\7zip\Bundles\Format7zF\7z.dll");
    '            /*using (var tmp = New SevenZipExtractor(@"d:\Temp\The_Name_of_the_Wind.part1.rar"))
    '            {                
    '                tmp.ExtractArchive(@"d:\Temp\!Пусто");
    '            }
    '            //*/
    '            #endregion

    '            #region Compression tests - very simple
    '            /*var tmp = New SevenZipCompressor();
    '            //tmp.ScanOnlyWritable = true;
    '            //tmp.CompressFiles(@"d:\Temp\arch.7z", @"d:\Temp\log.txt");
    '            //tmp.CompressDirectory(@"c:\Program Files\Microsoft Visual Studio 9.0\Common7\IDE\1033", @"D:\Temp\arch.7z");
    '            tmp.CompressDirectory(@"d:\Temp\!Пусто", @"d:\Temp\test.7z");
    '            //*/
    '            #endregion

    '            #region Compression test - features Append mode
    '            /*var tmp = New SevenZipCompressor();
    '            tmp.CompressionMode = CompressionMode.Append;            
    '            tmp.CompressDirectory(@"D:\Temp\!Пусто", @"D:\Temp\arch.7z");
    '            tmp = null;
    '            //*/
    '            #endregion

    '            #region Compression test - features Modify mode
    '            /*var tmp = New SevenZipCompressor();
    '            tmp.ModifyArchive(@"d:\Temp\7z465_extra.7z", New Dictionary<int, string>() { { 0, "xxx.bat" } });
    '            //Delete
    '            //tmp.ModifyArchive(@"d:\Temp\7z465_extra.7z", New Dictionary<int, string>() { { 19, null }, { 1, null } });
    '            //*/
    '            #endregion

    '            #region Compression test - multivolumes
    '            /*var tmp = New SevenZipCompressor();
    '            tmp.VolumeSize = 10000;            
    '            tmp.CompressDirectory(@"D:\Temp\!Пусто", @"D:\Temp\arch.7z");            
    '            //*/
    '            #endregion

    '            #region Extraction test. Shows cancel feature.
    '            /*using (var tmp = New SevenZipExtractor(@"D:\Temp\test.7z"))
    '            {
    '                tmp.FileExtractionStarted += (s, e) =>
    '                {
    '                    /*if (e.FileInfo.Index == 10)
    '                    {
    '                        e.Cancel = true;
    '                        Console.WriteLine("Cancelled");
    '                    }
    '                    Else
    '                    {//*//*

    '                       Console.WriteLine(String.Format("[{0}%] {1}",
    '                           e.PercentDone, e.FileInfo.FileName));
    '                   //}
    '               };
    '               tmp.FileExists += (o, e) =>
    '               {
    '                   Console.WriteLine("Warning: file \"" + e.FileName + "\" already exists.");
    '                   //e.Overwrite = false;
    '               };
    '               tmp.ExtractionFinished += (s, e) => { Console.WriteLine("Finished!"); };
    '               tmp.ExtractArchive(@"D:\Temp\!Пусто");
    '            }
    '            //*/
    '            #endregion

    '            #region Compression test - shows lots of features 
    '            /*var tmp = New SevenZipCompressor();
    '            tmp.ArchiveFormat = OutArchiveFormat.SevenZip;
    '            tmp.CompressionLevel = CompressionLevel.High;
    '            tmp.CompressionMethod = CompressionMethod.Ppmd;
    '            tmp.FileCompressionStarted += (s, e) =>
    '            {
    '                /*if (e.PercentDone > 50)
    '                {
    '                    e.Cancel = true;
    '                }
    '                Else
    '                {
    '                //*//*
    '                    Console.WriteLine(String.Format("[{0}%] {1}",
    '                        e.PercentDone, e.FileName));
    '                //*//*}
    '            };
    '            /*
    '            tmp.FilesFound += (se, ea) => 
    '            { 
    '                Console.WriteLine("Number of files: " + ea.Value.ToString()); 
    '            };
    '            //*/
    '            /*
    '            tmp.CompressFiles(
    '                @"d:\Temp\test.bz2", @"c:\log.txt", @"d:\Temp\08022009.jpg");*/
    '            //tmp.CompressDirectory(@"d:\Temp\!Пусто", @"d:\Temp\arch.7z");
    '            #endregion

    '            #region Multi-threaded extraction test
    '            /*var t1 = New Thread(() =>
    '            {
    '                Using (var tmp = New SevenZipExtractor(@"D:\Temp\7z465_extra.7z"))
    '                {
    '                    tmp.FileExtractionStarted += (s, e) =>
    '                    {
    '                        Console.WriteLine(String.Format("[{0}%] {1}",
    '                            e.PercentDone, e.FileInfo.FileName));
    '                    };
    '                    tmp.ExtractionFinished += (s, e) => { Console.WriteLine("Finished!"); };
    '                    tmp.ExtractArchive(@"D:\Temp\t1");
    '                }
    '            });
    '            var t2 = New Thread(() >=
    '            {
    '                using (var tmp = New SevenZipExtractor(@"D:\Temp\7z465_extra.7z"))
    '                {
    '                    tmp.FileExtractionStarted += (s, e) =>
    '                    {
    '                        Console.WriteLine(String.Format("[{0}%] {1}",
    '                            e.PercentDone, e.FileInfo.FileName));
    '                    };
    '                    tmp.ExtractionFinished += (s, e) => { Console.WriteLine("Finished!"); };
    '                    tmp.ExtractArchive(@"D:\Temp\t2");
    '                }
    '            });
    '            t1.Start();
    '            t2.Start();
    '            t1.Join();
    '            t2.Join();
    '             //*/
    '            #endregion

    '            #region Multi-threaded compression test
    '            /*var t1 = New Thread(() =>
    '            {
    '                var tmp = New SevenZipCompressor();
    '                tmp.FileCompressionStarted += (s, e) =>
    '                    Console.WriteLine(String.Format("[{0}%] {1}", e.PercentDone, e.FileName));
    '                tmp.CompressDirectory(@"D:\Temp\t1", @"D:\Temp\arch1.7z");
    '            });
    '            var t2 = New Thread(() >=
    '            {
    '                var tmp = New SevenZipCompressor();
    '                tmp.FileCompressionStarted += (s, e) =>
    '                    Console.WriteLine(String.Format("[{0}%] {1}", e.PercentDone, e.FileName));
    '                tmp.CompressDirectory(@"D:\Temp\t2", @"D:\Temp\arch2.7z");
    '            });           
    '            t1.Start();
    '            t2.Start();           
    '            t1.Join();
    '            t2.Join();
    '            //*/
    '            #endregion

    '            #region Streaming extraction test
    '            /*using (var tmp = New SevenZipExtractor(
    '                File.OpenRead(@"D:\Temp\7z465_extra.7z")))
    '            {
    '                tmp.FileExtractionStarted += (s, e) =>
    '                {
    '                    Console.WriteLine(String.Format("[{0}%] {1}",
    '                        e.PercentDone, e.FileInfo.FileName));
    '                };
    '                tmp.ExtractionFinished += (s, e) => { Console.WriteLine("Finished!"); };
    '                tmp.ExtractArchive(@"D:\Temp\!Пусто");
    '            }//*/
    '            #endregion

    '            #region Streaming compression test
    '            /*var tmp = New SevenZipCompressor();
    '            tmp.FileCompressionStarted += (s, e) =>
    '            {
    '                Console.WriteLine(String.Format("[{0}%] {1}",
    '                    e.PercentDone, e.FileName));
    '            };
    '            tmp.CompressDirectory(@"D:\Temp\1",
    '                File.Create(@"D:\Temp\arch.bz2"));
    '            //*/
    '            #endregion

    '            #region CompressStream (managed) test
    '            /*SevenZipCompressor.CompressStream(File.OpenRead(@"D:\Temp\test.txt"), 
    '                File.Create(@"D:\Temp\test.lzma"), null, (o, e) =>
    '            {
    '                If (e.PercentDelta > 0)
    '                {
    '                    Console.Clear();
    '                    Console.WriteLine(e.PercentDone.ToString() + "%");
    '                }
    '            });
    '            //*/
    '            #endregion

    '            #region ExtractFile(Stream) test
    '            /*using (var tmp = New SevenZipExtractor(@"D:\Temp\7z465_extra.7z"))
    '            {
    '                tmp.FileExtractionStarted += (s, e) =>
    '                {
    '                    Console.WriteLine(String.Format("[{0}%] {1}",
    '                        e.PercentDone, e.FileInfo.FileName));
    '                };
    '                tmp.FileExists += (o, e) =>
    '                {
    '                    Console.WriteLine("Warning: file \"" + e.FileName + "\" already exists.");
    '                    //e.Overwrite = false;
    '                };
    '                tmp.ExtractionFinished += n(s, e) => { Console.WriteLine("Finished!"); };
    '                tmp.ExtractFile(2, File.Create(@"D:\Temp\!Пусто\test.txt"));
    '            }//*/
    '            #endregion

    '            #region ExtractFile(Disk) test
    '            /*using (var tmp = New SevenZipExtractor(@"D:\Temp\7z465_extra.7z"))
    '            {
    '                tmp.FileExtractionStarted += (s, e) =>
    '                {
    '                    Console.WriteLine(String.Format("[{0}%] {1}",
    '                        e.PercentDone, e.FileInfo.FileName));
    '                };
    '                tmp.FileExists += (o, e) =>
    '                {
    '                    Console.WriteLine("Warning: file \"" + e.FileName + "\" already exists.");
    '                    //e.Overwrite = false;
    '                };
    '                tmp.ExtractionFinished += (s, e) => { Console.WriteLine("Finished!"); };
    '                tmp.ExtractFile(4, @"D:\Temp\!Пусто");
    '            }
    '            //*/
    '            #endregion            

    '            #region CompressFiles Zip test
    '            /*var tmp = New SevenZipCompressor();
    '            tmp.ArchiveFormat = OutArchiveFormat.Zip;
    '            tmp.CompressFiles(@"d:\Temp\arch.zip", @"d:\Temp\gpl.txt", @"d:\Temp\ru_office.txt");
    '            //*/
    '            #endregion

    '            #region CompressStream (external) test
    '            /*var tmp = New SevenZipCompressor();
    '            tmp.CompressStream(
    '                File.OpenRead(@"D:\Temp\08022009.jpg"),
    '                File.Create(@"D:\Temp\arch.7z"));
    '            //*/
    '            #endregion

    '            #region CompressFileDictionary test
    '            /*var tmp = New SevenZipCompressor();
    '            Dictionary<string, string> fileDict = New Dictionary<string, string>();
    '            fileDict.Add("test.ini", @"d:\Temp\temp.ini");
    '            tmp.FileCompressionStarted += (o, e) =>
    '            {               
    '                Console.WriteLine(String.Format("[{0}%] {1}",
    '                        e.PercentDone, e.FileName));
    '            };
    '            tmp.CompressFileDictionary(fileDict, @"d:\Temp\arch.7z");
    '            //*/
    '            #endregion

    '            #region Toughness test - throws no exceptions And no leaks
    '            /*
    '            Console.ReadKey();
    '            String exeAssembly = Assembly.GetAssembly(TypeOf (SevenZipExtractor)).FullName;
    '            AppDomain dom = AppDomain.CreateDomain("Extract");
    '            For (int i = 0; i < 1000; i++)
    '            {
    '                Using (SevenZipExtractor tmp = 
    '                    (SevenZipExtractor)dom.CreateInstance(
    '                    exeAssembly, TypeOf(SevenZipExtractor).FullName,
    '                    false, BindingFlags.CreateInstance, null, 
    '                    New object[] {@"D:\Temp\7z465_extra.7z"}, 
    '                    System.Globalization.CultureInfo.CurrentCulture, null, null).Unwrap())
    '                {                    
    '                    tmp.ExtractArchive(@"D:\Temp\!Пусто");
    '                }
    '                Console.Clear();
    '                Console.WriteLine(i);
    '            }
    '            AppDomain.Unload(dom);           
    '            //No errors, no leaks*/
    '            #endregion

    '            #region Serialization demo
    '            /*ArgumentException ex = New ArgumentException("blahblah");
    '            BinaryFormatter bf = New BinaryFormatter();
    '            Using (MemoryStream ms = New MemoryStream())
    '            {
    '                bf.Serialize(ms, ex);
    '                SevenZipCompressor cmpr = New SevenZipCompressor();
    '                cmpr.CompressStream(ms, File.Create(@"d:\Temp\test.7z"));
    '            }
    '            //*/
    '            #endregion

    '            #region Compress with custom parameters demo
    '            /*var tmp = New SevenZipCompressor();            
    '            tmp.ArchiveFormat = OutArchiveFormat.Zip;
    '            tmp.CompressionMethod = CompressionMethod.Deflate;
    '            tmp.CompressionLevel = CompressionLevel.Ultra;
    '            //Number of fast bytes
    '            tmp.CustomParameters.Add("fb", "256");
    '            //Number of deflate passes
    '            tmp.CustomParameters.Add("pass", "4");
    '            //Multi-threading on
    '            tmp.CustomParameters.Add("mt", "on");
    '            tmp.ZipEncryptionMethod = ZipEncryptionMethod.AES256;
    '            tmp.Compressing += (s, e) =>
    '            {
    '                Console.Clear();
    '                Console.WriteLine(String.Format("{0}%", e.PercentDone));
    '            };
    '            tmp.CompressDirectory(@"d:\Temp\!Пусто", @"d:\Temp\arch.zip", "test");
    '            //*/

    '            /*SevenZipCompressor tmp = New SevenZipCompressor();
    '            tmp.CompressionMethod = CompressionMethod.Ppmd;
    '            tmp.CompressionLevel = CompressionLevel.Ultra;
    '            tmp.EncryptHeadersSevenZip = true;
    '            tmp.ScanOnlyWritable = true;
    '            tmp.CompressDirectory(@"d:\Temp\!Пусто", @"d:\Temp\arch.7z", "test");  
    '            //*/
    '            #endregion

    '            #region Sfx demo
    '            /*var sfx = New SevenZipSfx();
    '            SevenZipCompressor tmp = New SevenZipCompressor();
    '            Using (MemoryStream ms = New MemoryStream())
    '            {
    '                tmp.CompressDirectory(@"d:\Temp\!Пусто", ms);               
    '                sfx.MakeSfx(ms, @"d:\Temp\test.exe");
    '            }
    '            //*/
    '            #endregion

    '            #region Lzma Encode/Decode Stream test
    '            /*using (var output = New FileStream(@"d:\Temp\arch.lzma", FileMode.Create))
    '            {
    '                var encoder = New LzmaEncodeStream(output);
    '                Using (var inputSample = New FileStream(@"d:\Temp\tolstoi_lev_voina_i_mir_kniga_1.rtf", FileMode.Open))
    '                {
    '                    int bufSize = 24576, count;
    '                    Byte[] buf = New Byte[bufSize];
    '                    While ((count = inputSample.Read(buf, 0, bufSize)) > 0)
    '                    {
    '                        encoder.Write(buf, 0, count);
    '                    }
    '                }
    '                encoder.Close();
    '            }//*/
    '            /*using (var input = New FileStream(@"d:\Temp\arch.lzma", FileMode.Open))
    '            {
    '                var decoder = New LzmaDecodeStream(Input);
    '                Using (var output = New FileStream(@"d:\Temp\res.rtf", FileMode.Create))
    '                {
    '                    int bufSize = 24576, count;
    '                    Byte[] buf = New Byte[bufSize];
    '                    While ((count = decoder.Read(buf, 0, bufSize)) > 0)
    '                    {
    '                        output.Write(buf, 0, count);
    '                    }
    '                }
    '            }//*/
    '            #endregion

    '            Console.WriteLine("Press any key to finish.");
    '            Console.ReadKey();
    '        }
    '    }    
    '}



#End Region

    Public Sub LoadDrivers()
For Each drive As IO.DriveInfo In My.Computer.FileSystem.Drives
      ComboBox1.Items.Add(drive.Name)
Next drive
End Sub


" ##############################################"

Dim lvi As ListViewItem
Dim di As New DirectoryInfo(Combobox1.Selecteditem.ToString)
Dim myIcon As Icon

' ext/icon lookup
Dim exts As New List(Of String)
ImageList1.Images.Clear()

For Each fi As FileInfo In di.EnumerateFiles("*.*")

    lvi = New ListViewItem
    lvi.Text = fi.Name
    lvi.SubItems.Add(Path.GetDirectoryName(fi.FullName))

    lvi.SubItems.Add(((fi.Length / 1024)).ToString("0.00"))
    lvi.SubItems.Add(fi.CreationTime.ToShortDateString)

    If exts.Contains(fi.Extension) = False Then
        myIcon = Icon.ExtractAssociatedIcon(fi.FullName)
        ImageList1.Images.Add(fi.Extension, myIcon)
        exts.Add(fi.Extension)
    End If

    lvi.ImageKey = fi.Extension
    myLV.Items.Add(lvi)
Next
"The code uses a List(of String) to keep track of which icons have been added so that you do not add the same image over and over for repeated file types. other wise, it displays the Name, Folder, Size, Date and icon.

"enter image description here

"The code using Directory would rely on System.io.Path more and Size and Date would not be available:"


For Each s As String In Directory.EnumerateFiles(Comboboxdriver.selecteditem) 


    lvi = New ListViewItem
    lvi.Text = Path.GetFileName(s)
    lvi.SubItems.Add(Path.GetDirectoryName(s))

    Dim fileExt = Path.GetExtension(s)
    If exts.Contains(fileExt) = False Then
        myIcon = Icon.ExtractAssociatedIcon(s)
        ImageList1.Images.Add(fileExt, myIcon)
        exts.Add(fileExt)
    End If

    lvi.ImageKey = fileExt
    myLV.Items.Add(lvi)
Next


"#######################$$$####$##########$$$$$$$








Private Sub toolStripButton1_Click(sender As Object, e As EventArgs) Handles RBNButtonExtrair.Click
        " Open archive
       Dim fo As New FileBrowserDialog ()
        fo.Filter = "Supported Archives (*.shitloads)|*.7z;*.zip;*.rar;*.cab;*.ace;*.tar;*.gz;*.bz2;*.xz;*.wim;*.apm;*.arj;*.chm;*.cpio;*.deb;*.flv;*.jar;*.lha;*.lzh;*.lzma;*.rpm;*.swf;*.xar;*.z;*.iso;*.udf;*.vhd|All Files (*.*)|*.*"
        
        If fo.FileName <> "" Then
            StatusStrip1.Items(1).Text = "Loading: " & Path.GetFileName(fo.FileName)
            ActiveForm.Text = "Zipbox [" & Path.GetFileName(fo.FileName) & "]" & adminTitle()
            archName = fo.FileName
            zipengine = loadArchive(fo.FileName)
        End If
    End Sub





Private Sub toolStripButton1_Click(sender As Object, e As EventArgs) Handles RBNButtonExtrair.Click
        ' Open archive
       dim fo As FileInfo(Listview1.subitems(2))
        If fo <> "" Then
            StatusStrip1.Items(1).Text = "Loading: " & Path.GetFileName(fo.FileName)
            ActiveForm.Text = "Zipbox [" & Path.GetFileName(fo.FileName) & "]" & adminTitle()
            archName = fo.FileName
            zipengine = loadArchive(fo.FileName)
        End If
    End Sub




#Region " JTS Archiver "

    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, keyData As Keys) As Boolean
        If keyData = (Keys.Control Or Keys.A) Then
            For Each item As ListViewItem In listView1.Items
                item.Selected = True
            Next
            Return True
        End If
        Return MyBase.ProcessCmdKey(msg, keyData)
    End Function

    'mecanismo do JTS Archiver
    '#######################################################################################################

    Public archName As String = ""
    Public extractDir As String = ""
    Public zipengine As SevenZipExtractor
    Public newperc As Integer = 0
    Public selCurFile As String = ""
    Public onlyViewing As Boolean = False
    Public ReadOnly Property IsElevated() As Boolean
        Get
            Return New WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator)
        End Get
    End Property
    Public Function adminTitle() As String
        If IsElevated Then
            Return " [Admin]"
        Else
            Return ""
        End If
    End Function
    Private Sub toolStripButton1_Click(sender As Object, e As EventArgs) Handles RBNButtonExtrair.Click
        ' Open archive
        Dim fo As New OpenFileDialog()
        fo.Filter = "Supported Archives (*.shitloads)|*.7z;*.zip;*.rar;*.cab;*.ace;*.tar;*.gz;*.bz2;*.xz;*.wim;*.apm;*.arj;*.chm;*.cpio;*.deb;*.flv;*.jar;*.lha;*.lzh;*.lzma;*.rpm;*.swf;*.xar;*.z;*.iso;*.udf;*.vhd|All Files (*.*)|*.*"
        fo.ShowDialog()
        If fo.FileName <> "" Then
            StatusStrip1.Items(1).Text = "Loading: " & Path.GetFileName(fo.FileName)
            ActiveForm.Text = "Zipbox [" & Path.GetFileName(fo.FileName) & "]" & adminTitle()
            archName = fo.FileName
            zipengine = loadArchive(fo.FileName)
        End If
    End Sub

    Public Function fSize(sz As ULong) As String
        If sz < 1024 Then
            Return Convert.ToString(sz) & "B"
        ElseIf (sz >= 1024) AndAlso (sz < 1048576) Then
            Return Convert.ToString(Math.Round(CDec(sz) / 1024, 2)) & "KB"
        ElseIf (sz >= 1048576) AndAlso (sz < 1073741824) Then
            Return Convert.ToString(Math.Round(CDec(sz) / 1048576, 2)) & "MB"
        ElseIf sz >= 1073741824 Then
            Return Convert.ToString(Math.Round(CDec(sz) / 1073741824, 2)) & "GB"
        Else
            Return "N/A"
        End If
    End Function

    Public Shared Function GetFileIcon(name As String, linkOverlay As Boolean) As System.Drawing.Icon
        Dim shfi As New Shell32.SHFILEINFO()
        Dim flags As UInteger = Shell32.SHGFI_ICON Or Shell32.SHGFI_USEFILEATTRIBUTES
        If True = linkOverlay Then
            flags += Shell32.SHGFI_LINKOVERLAY
        End If
        flags += Shell32.SHGFI_SMALLICON
        Shell32.SHGetFileInfo(name, Shell32.FILE_ATTRIBUTE_NORMAL, shfi, CUInt(System.Runtime.InteropServices.Marshal.SizeOf(shfi)), flags)
        Dim icon As System.Drawing.Icon = DirectCast(System.Drawing.Icon.FromHandle(shfi.hIcon).Clone(), System.Drawing.Icon)
        User32.DestroyIcon(shfi.hIcon)
        Return icon
    End Function

    Public Function loadArchive(fName As String) As SevenZipExtractor
        listView1.Items.Clear()
        imageList1.Images.Clear()
        listView1.SmallImageList = imageList1
        Dim engine As New SevenZipExtractor(fName)
        AddHandler engine.Extracting, New EventHandler(Of ProgressEventArgs)(AddressOf progExtracting)
        AddHandler engine.FileExtractionStarted, New EventHandler(Of FileInfoEventArgs)(AddressOf progExtractStarted)
        AddHandler engine.FileExists, New EventHandler(Of FileOverwriteEventArgs)(AddressOf progFileExists)
        AddHandler engine.ExtractionFinished, New EventHandler(Of EventArgs)(AddressOf progExtractDone)
        Dim i As Integer
        ToolStripProgressBar1.Value = 0
        ToolStripProgressBar1.Maximum = engine.ArchiveFileData.Count
        listView1.BeginUpdate()
        For i = 0 To engine.ArchiveFileData.Count - 1
            ActiveForm.Refresh()
            ToolStripProgressBar1.Value = i
            If Not engine.ArchiveFileData(i).IsDirectory Then
                Dim appIcon As Icon = GetFileIcon(engine.ArchiveFileData(i).FileName, False)
                imageList1.Images.Add(appIcon)
                Dim itm As New ListViewItem("")
                itm.ImageIndex = imageList1.Images.Count - 1
                itm.SubItems.Add(Path.GetFileName(engine.ArchiveFileData(i).FileName))
                itm.SubItems.Add(fSize(engine.ArchiveFileData(i).Size))
                itm.SubItems.Add(Path.GetDirectoryName(engine.ArchiveFileData(i).FileName))
                listView1.Items.Add(itm)
            End If
        Next
        listView1.EndUpdate()
        toolStripProgressBar1.Value = toolStripProgressBar1.Maximum
        StatusStrip1.Items(1).Text = "Loaded: " & Path.GetFileName(archName)
        toolStripProgressBar1.Value = 0
        Return engine
    End Function



    Public Sub extractFiles(dir As String)
        extractDir = dir
        toolStripProgressBar1.Maximum = CInt(zipengine.FilesCount)
        toolStripProgressBar1.Value = 0
        zipengine.BeginExtractArchive(dir)
    End Sub

    Private Sub progExtracting(sender As Object, e As ProgressEventArgs)
        toolStripStatusLabel2.Text = Convert.ToString(e.PercentDone) & "%"
        'statusStrip1.Refresh();
    End Sub
    Private Sub progExtractStarted(sender As Object, e As FileInfoEventArgs)
        toolStripProgressBar1.Increment(1)
        toolStripProgressBar1.ProgressBar.Refresh()
        toolStripStatusLabel1.Text = "Extracting: " & Path.GetFileName(e.FileInfo.FileName)
        StatusStrip1.Refresh()
    End Sub
    Private Sub progFileExists(sender As Object, e As FileOverwriteEventArgs)

    End Sub
    Private Sub progExtractDone(sender As Object, e As EventArgs)
        toolStripProgressBar1.Value = 0
        StatusStrip1.Items(1).Text = "Extraction complete!"
        StatusStrip1.Items(2).Text = ""
        If onlyViewing = False Then
            If MessageBox.Show("Extraction completed successfully!" & Environment.NewLine & Environment.NewLine & "Open target directory?", "All Good", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1) = System.Windows.Forms.DialogResult.Yes Then
                Process.Start("" & extractDir)
            End If
        Else
            onlyViewing = False
        End If
    End Sub

    Private Sub Form1_Shown(sender As Object, e As EventArgs)
        ActiveForm.Text = ActiveForm.Text & adminTitle()
        Dim args As String() = Environment.GetCommandLineArgs()
        If args.Count() > 1 Then
            If File.Exists(args(1)) Then
                StatusStrip1.Items(1).Text = "Loading: " & Path.GetFileName(args(1))
                ActiveForm.Text = "Zipbox [" & Path.GetFileName(args(1)) & "]" & adminTitle()
                archName = args(1)
                zipengine = loadArchive(args(1))
            End If
        End If
    End Sub

    Private Sub extractAllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExtractAll.Click
        If archName <> "" Then
            Dim fd As New FolderBrowserDialog()
            fd.Description = "Choose path to extract files.."
            If fd.ShowDialog() = DialogResult.OK Then
                extractFiles(fd.SelectedPath)
            End If
        Else
            MessageBox.Show("You need to open an archive first!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End If
    End Sub

    Private Sub extractSelectedToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExtractSelectedFiles.Click
        If archName <> "" Then
            If listView1.SelectedItems.Count > 0 Then
                Dim fd As New FolderBrowserDialog()
                fd.Description = "Choose path to extract files.."
                If fd.ShowDialog() = DialogResult.OK Then
                    extractSelected(fd.SelectedPath)
                    
                End If
            Else
                MessageBox.Show("Nothing is selected!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            End If
        Else
            MessageBox.Show("You need to open an archive first!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End If
    End Sub

    Public Sub extractSelected(dir As String)
        extractDir = dir
        toolStripProgressBar1.Maximum = listView1.SelectedItems.Count
        toolStripProgressBar1.Value = 0

        Dim i As Integer
        Dim fileList As New List(Of String)()
        For i = 0 To listView1.SelectedItems.Count - 1
            Dim itm As String
            If listView1.SelectedItems(i).SubItems(3).Text = "" Then
                itm = listView1.SelectedItems(i).SubItems(1).Text
            Else
                itm = listView1.SelectedItems(i).SubItems(3).Text & "\" & listView1.SelectedItems(i).SubItems(1).Text
            End If
            fileList.Add(itm)
        Next
        zipengine.ExtractFiles(dir, fileList.ToArray())

    End Sub

    Public Sub extractAndRun(itm As ListViewItem, editor As String)
        Dim tmpdir As String = Path.GetTempPath()
        Dim fn As String
        If itm.SubItems(3).Text = "" Then
            fn = itm.SubItems(1).Text
        Else
            fn = itm.SubItems(3).Text & "\" & itm.SubItems(1).Text
        End If
        Dim outpath As String = tmpdir & "\" & itm.SubItems(1).Text

        Dim fs As New StreamWriter(outpath, False)
        onlyViewing = True
        zipengine.ExtractFile(fn, fs.BaseStream)
        fs.Close()

        If editor = "" Then

            Process.Start("" & outpath)
                Else
                Process.Start("" & editor, outpath)

        End If
    End Sub



"Abrir Com 
    Private Sub inAnotherEditorToolStripMenuItem_Click(sender As Object, e As EventArgs)
        If listView1.SelectedItems.Count > 0 Then
            Dim ed As New OpenFileDialog()
            ed.Filter = "Application (*.exe)|*.exe|All Files (*.*)|*.*"
            If ed.ShowDialog() = DialogResult.OK Then
                extractAndRun(listView1.SelectedItems(0), ed.FileName)
            End If
        Else
            MessageBox.Show("Nothing selected!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End If
    End Sub

    Private Sub inNotepadToolStripMenuItem_Click(sender As Object, e As EventArgs)
        If listView1.SelectedItems.Count > 0 Then

            extractAndRun(listView1.SelectedItems(0), "c:\windows\system32\notepad.exe")
        Else
            MessageBox.Show("Nothing selected!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End If
    End Sub

    Private Sub listView1_DoubleClick(sender As Object, e As EventArgs) Handles listView1.DoubleClick
       Try
 If listView1.SelectedItems.Count > 0 Then
 
 
 "Se for arquivo "
            Dim fo As new FileInfo(Listview1.subitems(2).Text)
        Dim File = fo.FullName
  Dim SourcePath As String = Path.GetDirectoryName(File)
          If File <> "" Then
            StatusStrip1.Items(1).Text = "Loading: " & Path.GetFileName(File)
            ActiveForm.Text = "Zipbox " & Path.GetFileName(File) & "]" & adminTitle()
            archName = File
            zipengine = loadArchive(File)
    extractAndRun(listView1.SelectedItems(0), "")
        Else
            MessageBox.Show("Nothing selected!", "Oops!", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End If
        
        Catch ex As Exception 
    End Sub

    Private Sub runThisFileToolStripMenuItem_Click(sender As Object, e As EventArgs)
        listView1_DoubleClick(sender, e)
    End Sub



    'Private Sub toolStripButton4_Click(sender As Object, e As EventArgs)
    '    Using settingsbox As New settings(Me)
    '        settingsbox.ShowDialog(Me)
    '    End Using
    'End Sub

    Public Sub settingsQuit()
        Close()
    End Sub

    Private Sub toolStripButton5_Click(sender As Object, e As EventArgs)
        Using compressFrm As New compress(Me)
            compressFrm.ShowDialog(Me)
        End Using
    End Sub
    Public Sub beginCompression(in_archFile As String, in_archType As OutArchiveFormat, in_compLevel As CompressionLevel, in_fileList As String())
        Using pcompressFrm As New progresscompress(Me, in_archFile, in_archType, in_compLevel, in_fileList)
            pcompressFrm.ShowDialog()
        End Using
    End Sub


End Class

''' <summary>
''' Wraps necessary Shell32.dll structures and functions required to retrieve Icon Handles using SHGetFileInfo. Code
''' courtesy of MSDN Cold Rooster Consulting case study.
''' </summary>
''' 

Public Class Shell32

    Public Const MAX_PATH As Integer = 256
    <StructLayout(LayoutKind.Sequential)>
    Public Structure SHITEMID
        Public cb As UShort
        <MarshalAs(UnmanagedType.LPArray)>
        Public abID As Byte()
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Public Structure ITEMIDLIST
        Public mkid As SHITEMID
    End Structure

    <StructLayout(LayoutKind.Sequential)>
    Public Structure BROWSEINFO
        Public hwndOwner As IntPtr
        Public pidlRoot As IntPtr
        Public pszDisplayName As IntPtr
        <MarshalAs(UnmanagedType.LPTStr)>
        Public lpszTitle As String
        Public ulFlags As UInteger
        Public lpfn As IntPtr
        Public lParam As Integer
        Public iImage As IntPtr
    End Structure

    ' Browsing for directory.
    Public Const BIF_RETURNONLYFSDIRS As UInteger = &H1
    Public Const BIF_DONTGOBELOWDOMAIN As UInteger = &H2
    Public Const BIF_STATUSTEXT As UInteger = &H4
    Public Const BIF_RETURNFSANCESTORS As UInteger = &H8
    Public Const BIF_EDITBOX As UInteger = &H10
    Public Const BIF_VALIDATE As UInteger = &H20
    Public Const BIF_NEWDIALOGSTYLE As UInteger = &H40
    Public Const BIF_USENEWUI As UInteger = (BIF_NEWDIALOGSTYLE Or BIF_EDITBOX)
    Public Const BIF_BROWSEINCLUDEURLS As UInteger = &H80
    Public Const BIF_BROWSEFORCOMPUTER As UInteger = &H1000
    Public Const BIF_BROWSEFORPRINTER As UInteger = &H2000
    Public Const BIF_BROWSEINCLUDEFILES As UInteger = &H4000
    Public Const BIF_SHAREABLE As UInteger = &H8000

    <StructLayout(LayoutKind.Sequential)>
    Public Structure SHFILEINFO
        Public Const NAMESIZE As Integer = 80
        Public hIcon As IntPtr
        Public iIcon As Integer
        Public dwAttributes As UInteger
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=MAX_PATH)>
        Public szDisplayName As String
        <MarshalAs(UnmanagedType.ByValTStr, SizeConst:=NAMESIZE)>
        Public szTypeName As String
    End Structure

    Public Const SHGFI_ICON As UInteger = &H100
    ' get icon
    Public Const SHGFI_DISPLAYNAME As UInteger = &H200
    ' get display name
    Public Const SHGFI_TYPENAME As UInteger = &H400
    ' get type name
    Public Const SHGFI_ATTRIBUTES As UInteger = &H800
    ' get attributes
    Public Const SHGFI_ICONLOCATION As UInteger = &H1000
    ' get icon location
    Public Const SHGFI_EXETYPE As UInteger = &H2000
    ' return exe type
    Public Const SHGFI_SYSICONINDEX As UInteger = &H4000
    ' get system icon index
    Public Const SHGFI_LINKOVERLAY As UInteger = &H8000
    ' put a link overlay on icon
    Public Const SHGFI_SELECTED As UInteger = &H10000
    ' show icon in selected state
    Public Const SHGFI_ATTR_SPECIFIED As UInteger = &H20000
    ' get only specified attributes
    Public Const SHGFI_LARGEICON As UInteger = &H0
    ' get large icon
    Public Const SHGFI_SMALLICON As UInteger = &H1
    ' get small icon
    Public Const SHGFI_OPENICON As UInteger = &H2
    ' get open icon
    Public Const SHGFI_SHELLICONSIZE As UInteger = &H4
    ' get shell size icon
    Public Const SHGFI_PIDL As UInteger = &H8
    ' pszPath is a pidl
    Public Const SHGFI_USEFILEATTRIBUTES As UInteger = &H10
    ' use passed dwFileAttribute
    Public Const SHGFI_ADDOVERLAYS As UInteger = &H20
    ' apply the appropriate overlays
    Public Const SHGFI_OVERLAYINDEX As UInteger = &H40
    ' Get the index of the overlay
    Public Const FILE_ATTRIBUTE_DIRECTORY As UInteger = &H10
    Public Const FILE_ATTRIBUTE_NORMAL As UInteger = &H80

    <DllImport("Shell32.dll")>
    Public Shared Function SHGetFileInfo(pszPath As String, dwFileAttributes As UInteger, ByRef psfi As SHFILEINFO, cbFileInfo As UInteger, uFlags As UInteger) As IntPtr
    End Function
End Class

''' <summary>
''' Wraps necessary functions imported from User32.dll. Code courtesy of MSDN Cold Rooster Consulting example.
''' </summary>
Public Class User32
    ''' <summary>
    ''' Provides access to function required to delete handle. This method is used internally
    ''' and is not required to be called separately.
    ''' </summary>
    ''' <param name="hIcon">Pointer to icon handle.</param>
    ''' <returns>N/A</returns>
    <DllImport("User32.dll")>
    Public Shared Function DestroyIcon(hIcon As IntPtr) As Integer
    End Function
End Class



#End Region


