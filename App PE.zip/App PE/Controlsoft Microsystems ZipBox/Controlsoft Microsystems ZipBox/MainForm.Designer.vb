﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits Metro.Form
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
            If disposing AndAlso m_StreamReader IsNot Nothing Then
                m_StreamReader.Dispose()
            End If
            If disposing AndAlso m_StreamWriter IsNot Nothing Then
                m_StreamWriter.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPageFileSplitter = New System.Windows.Forms.TabPage()
        Me.ButtonPauseSplit = New System.Windows.Forms.Button()
        Me.GroupBoxSplitInfo = New System.Windows.Forms.GroupBox()
        Me.LabelSplitFileSize = New System.Windows.Forms.Label()
        Me.LabelSplitNumberOfPieces = New System.Windows.Forms.Label()
        Me.GroupBoxSplitFile = New System.Windows.Forms.GroupBox()
        Me.ButtonBrowseSplitFile = New System.Windows.Forms.Button()
        Me.TextBoxSplitFileName = New System.Windows.Forms.TextBox()
        Me.ButtonSplitFile = New System.Windows.Forms.Button()
        Me.LabelNumberOfFiles = New System.Windows.Forms.Label()
        Me.CheckBoxGenerateJoinFile = New System.Windows.Forms.CheckBox()
        Me.TextBoxNumberOfFiles = New System.Windows.Forms.TextBox()
        Me.ProgressBarSplit = New System.Windows.Forms.ProgressBar()
        Me.GroupBoxSplitFolder = New System.Windows.Forms.GroupBox()
        Me.ButtonBrowseSplitFolder = New System.Windows.Forms.Button()
        Me.TextBoxSplitFolder = New System.Windows.Forms.TextBox()
        Me.GroupBoxNumberOfBytes = New System.Windows.Forms.GroupBox()
        Me.TextBoxNumberOfBytesAfterSplit = New System.Windows.Forms.TextBox()
        Me.TabPageFileJoiner = New System.Windows.Forms.TabPage()
        Me.ButtonPauseJoin = New System.Windows.Forms.Button()
        Me.GroupBoxJoinInfo = New System.Windows.Forms.GroupBox()
        Me.LabelJoinFileName = New System.Windows.Forms.Label()
        Me.LabelJoinNumberOfPieces = New System.Windows.Forms.Label()
        Me.CheckBoxDeletePieces = New System.Windows.Forms.CheckBox()
        Me.GroupBoxJoinFolder = New System.Windows.Forms.GroupBox()
        Me.ButtonBrowseJoinFolder = New System.Windows.Forms.Button()
        Me.TextBoxJoinFolder = New System.Windows.Forms.TextBox()
        Me.GroupBoxJoinFile = New System.Windows.Forms.GroupBox()
        Me.TextBoxJoinFileName = New System.Windows.Forms.TextBox()
        Me.ButtonBrowseJoinFile = New System.Windows.Forms.Button()
        Me.ProgressBarJoin = New System.Windows.Forms.ProgressBar()
        Me.ButtonJoinFile = New System.Windows.Forms.Button()
        Me.TabPageOptions = New System.Windows.Forms.TabPage()
        Me.LabelBiggerIsFaster = New System.Windows.Forms.Label()
        Me.ButtonRefreshDebugInfo = New System.Windows.Forms.Button()
        Me.LabelNotRespond = New System.Windows.Forms.Label()
        Me.LabelDoEvents = New System.Windows.Forms.Label()
        Me.ComboBoxDoEvents = New System.Windows.Forms.ComboBox()
        Me.ButtonPauseResume = New System.Windows.Forms.Button()
        Me.GroupBoxDebugVariables = New System.Windows.Forms.GroupBox()
        Me.TextBoxDebugVariables = New System.Windows.Forms.TextBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.KB360ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.KB720ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MB12ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MB138ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.CustomToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabelStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TabControl1.SuspendLayout()
        Me.TabPageFileSplitter.SuspendLayout()
        Me.GroupBoxSplitInfo.SuspendLayout()
        Me.GroupBoxSplitFile.SuspendLayout()
        Me.GroupBoxSplitFolder.SuspendLayout()
        Me.GroupBoxNumberOfBytes.SuspendLayout()
        Me.TabPageFileJoiner.SuspendLayout()
        Me.GroupBoxJoinInfo.SuspendLayout()
        Me.GroupBoxJoinFolder.SuspendLayout()
        Me.GroupBoxJoinFile.SuspendLayout()
        Me.TabPageOptions.SuspendLayout()
        Me.GroupBoxDebugVariables.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPageFileSplitter)
        Me.TabControl1.Controls.Add(Me.TabPageFileJoiner)
        Me.TabControl1.Controls.Add(Me.TabPageOptions)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(2, 30)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(440, 396)
        Me.TabControl1.TabIndex = 7
        '
        'TabPageFileSplitter
        '
        Me.TabPageFileSplitter.Controls.Add(Me.ButtonPauseSplit)
        Me.TabPageFileSplitter.Controls.Add(Me.GroupBoxSplitInfo)
        Me.TabPageFileSplitter.Controls.Add(Me.GroupBoxSplitFile)
        Me.TabPageFileSplitter.Controls.Add(Me.ButtonSplitFile)
        Me.TabPageFileSplitter.Controls.Add(Me.LabelNumberOfFiles)
        Me.TabPageFileSplitter.Controls.Add(Me.CheckBoxGenerateJoinFile)
        Me.TabPageFileSplitter.Controls.Add(Me.TextBoxNumberOfFiles)
        Me.TabPageFileSplitter.Controls.Add(Me.ProgressBarSplit)
        Me.TabPageFileSplitter.Controls.Add(Me.GroupBoxSplitFolder)
        Me.TabPageFileSplitter.Controls.Add(Me.GroupBoxNumberOfBytes)
        Me.TabPageFileSplitter.Location = New System.Drawing.Point(4, 24)
        Me.TabPageFileSplitter.Name = "TabPageFileSplitter"
        Me.TabPageFileSplitter.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageFileSplitter.Size = New System.Drawing.Size(432, 368)
        Me.TabPageFileSplitter.TabIndex = 0
        Me.TabPageFileSplitter.Text = "File Splitter"
        Me.TabPageFileSplitter.UseVisualStyleBackColor = True
        '
        'ButtonPauseSplit
        '
        Me.ButtonPauseSplit.Location = New System.Drawing.Point(13, 243)
        Me.ButtonPauseSplit.Name = "ButtonPauseSplit"
        Me.ButtonPauseSplit.Size = New System.Drawing.Size(75, 25)
        Me.ButtonPauseSplit.TabIndex = 26
        Me.ButtonPauseSplit.Text = "Pause"
        Me.ButtonPauseSplit.UseVisualStyleBackColor = True
        '
        'GroupBoxSplitInfo
        '
        Me.GroupBoxSplitInfo.Controls.Add(Me.LabelSplitFileSize)
        Me.GroupBoxSplitInfo.Controls.Add(Me.LabelSplitNumberOfPieces)
        Me.GroupBoxSplitInfo.Location = New System.Drawing.Point(132, 122)
        Me.GroupBoxSplitInfo.Name = "GroupBoxSplitInfo"
        Me.GroupBoxSplitInfo.Size = New System.Drawing.Size(295, 63)
        Me.GroupBoxSplitInfo.TabIndex = 25
        Me.GroupBoxSplitInfo.TabStop = False
        Me.GroupBoxSplitInfo.Text = "Info"
        '
        'LabelSplitFileSize
        '
        Me.LabelSplitFileSize.AutoSize = True
        Me.LabelSplitFileSize.Location = New System.Drawing.Point(6, 19)
        Me.LabelSplitFileSize.Name = "LabelSplitFileSize"
        Me.LabelSplitFileSize.Size = New System.Drawing.Size(48, 15)
        Me.LabelSplitFileSize.TabIndex = 7
        Me.LabelSplitFileSize.Text = "FileSize:"
        '
        'LabelSplitNumberOfPieces
        '
        Me.LabelSplitNumberOfPieces.AutoSize = True
        Me.LabelSplitNumberOfPieces.Location = New System.Drawing.Point(6, 35)
        Me.LabelSplitNumberOfPieces.Name = "LabelSplitNumberOfPieces"
        Me.LabelSplitNumberOfPieces.Size = New System.Drawing.Size(104, 15)
        Me.LabelSplitNumberOfPieces.TabIndex = 8
        Me.LabelSplitNumberOfPieces.Text = "Number of pieces:"
        '
        'GroupBoxSplitFile
        '
        Me.GroupBoxSplitFile.Controls.Add(Me.ButtonBrowseSplitFile)
        Me.GroupBoxSplitFile.Controls.Add(Me.TextBoxSplitFileName)
        Me.GroupBoxSplitFile.Location = New System.Drawing.Point(6, 6)
        Me.GroupBoxSplitFile.Name = "GroupBoxSplitFile"
        Me.GroupBoxSplitFile.Size = New System.Drawing.Size(421, 51)
        Me.GroupBoxSplitFile.TabIndex = 21
        Me.GroupBoxSplitFile.TabStop = False
        Me.GroupBoxSplitFile.Text = "Select file to split"
        '
        'ButtonBrowseSplitFile
        '
        Me.ButtonBrowseSplitFile.Location = New System.Drawing.Point(374, 18)
        Me.ButtonBrowseSplitFile.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ButtonBrowseSplitFile.Name = "ButtonBrowseSplitFile"
        Me.ButtonBrowseSplitFile.Size = New System.Drawing.Size(41, 26)
        Me.ButtonBrowseSplitFile.TabIndex = 0
        Me.ButtonBrowseSplitFile.Text = "..."
        Me.ButtonBrowseSplitFile.UseVisualStyleBackColor = True
        '
        'TextBoxSplitFileName
        '
        Me.TextBoxSplitFileName.BackColor = System.Drawing.SystemColors.Window
        Me.TextBoxSplitFileName.Location = New System.Drawing.Point(6, 20)
        Me.TextBoxSplitFileName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxSplitFileName.MaxLength = 1000
        Me.TextBoxSplitFileName.Name = "TextBoxSplitFileName"
        Me.TextBoxSplitFileName.ReadOnly = True
        Me.TextBoxSplitFileName.Size = New System.Drawing.Size(362, 23)
        Me.TextBoxSplitFileName.TabIndex = 4
        '
        'ButtonSplitFile
        '
        Me.ButtonSplitFile.Location = New System.Drawing.Point(132, 243)
        Me.ButtonSplitFile.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ButtonSplitFile.Name = "ButtonSplitFile"
        Me.ButtonSplitFile.Size = New System.Drawing.Size(289, 26)
        Me.ButtonSplitFile.TabIndex = 9
        Me.ButtonSplitFile.Text = "Split file"
        Me.ButtonSplitFile.UseVisualStyleBackColor = True
        '
        'LabelNumberOfFiles
        '
        Me.LabelNumberOfFiles.AutoSize = True
        Me.LabelNumberOfFiles.Location = New System.Drawing.Point(9, 194)
        Me.LabelNumberOfFiles.Name = "LabelNumberOfFiles"
        Me.LabelNumberOfFiles.Size = New System.Drawing.Size(209, 15)
        Me.LabelNumberOfFiles.TabIndex = 24
        Me.LabelNumberOfFiles.Text = "Number of equal size files to split into:"
        '
        'CheckBoxGenerateJoinFile
        '
        Me.CheckBoxGenerateJoinFile.AutoSize = True
        Me.CheckBoxGenerateJoinFile.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBoxGenerateJoinFile.Checked = True
        Me.CheckBoxGenerateJoinFile.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBoxGenerateJoinFile.Location = New System.Drawing.Point(296, 193)
        Me.CheckBoxGenerateJoinFile.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBoxGenerateJoinFile.Name = "CheckBoxGenerateJoinFile"
        Me.CheckBoxGenerateJoinFile.Size = New System.Drawing.Size(119, 19)
        Me.CheckBoxGenerateJoinFile.TabIndex = 17
        Me.CheckBoxGenerateJoinFile.Text = "Generate .Join file"
        Me.CheckBoxGenerateJoinFile.UseVisualStyleBackColor = True
        '
        'TextBoxNumberOfFiles
        '
        Me.TextBoxNumberOfFiles.Location = New System.Drawing.Point(230, 194)
        Me.TextBoxNumberOfFiles.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxNumberOfFiles.MaxLength = 4
        Me.TextBoxNumberOfFiles.Name = "TextBoxNumberOfFiles"
        Me.TextBoxNumberOfFiles.Size = New System.Drawing.Size(47, 23)
        Me.TextBoxNumberOfFiles.TabIndex = 16
        '
        'ProgressBarSplit
        '
        Me.ProgressBarSplit.Location = New System.Drawing.Point(13, 225)
        Me.ProgressBarSplit.Name = "ProgressBarSplit"
        Me.ProgressBarSplit.Size = New System.Drawing.Size(408, 11)
        Me.ProgressBarSplit.TabIndex = 20
        '
        'GroupBoxSplitFolder
        '
        Me.GroupBoxSplitFolder.Controls.Add(Me.ButtonBrowseSplitFolder)
        Me.GroupBoxSplitFolder.Controls.Add(Me.TextBoxSplitFolder)
        Me.GroupBoxSplitFolder.Location = New System.Drawing.Point(6, 64)
        Me.GroupBoxSplitFolder.Name = "GroupBoxSplitFolder"
        Me.GroupBoxSplitFolder.Size = New System.Drawing.Size(421, 51)
        Me.GroupBoxSplitFolder.TabIndex = 22
        Me.GroupBoxSplitFolder.TabStop = False
        Me.GroupBoxSplitFolder.Text = "Save pieces in folder"
        '
        'ButtonBrowseSplitFolder
        '
        Me.ButtonBrowseSplitFolder.Location = New System.Drawing.Point(374, 18)
        Me.ButtonBrowseSplitFolder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ButtonBrowseSplitFolder.Name = "ButtonBrowseSplitFolder"
        Me.ButtonBrowseSplitFolder.Size = New System.Drawing.Size(41, 26)
        Me.ButtonBrowseSplitFolder.TabIndex = 1
        Me.ButtonBrowseSplitFolder.Text = "..."
        Me.ButtonBrowseSplitFolder.UseVisualStyleBackColor = True
        '
        'TextBoxSplitFolder
        '
        Me.TextBoxSplitFolder.BackColor = System.Drawing.SystemColors.Window
        Me.TextBoxSplitFolder.Location = New System.Drawing.Point(6, 20)
        Me.TextBoxSplitFolder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxSplitFolder.MaxLength = 1000
        Me.TextBoxSplitFolder.Name = "TextBoxSplitFolder"
        Me.TextBoxSplitFolder.ReadOnly = True
        Me.TextBoxSplitFolder.Size = New System.Drawing.Size(362, 23)
        Me.TextBoxSplitFolder.TabIndex = 5
        '
        'GroupBoxNumberOfBytes
        '
        Me.GroupBoxNumberOfBytes.Controls.Add(Me.TextBoxNumberOfBytesAfterSplit)
        Me.GroupBoxNumberOfBytes.Location = New System.Drawing.Point(6, 122)
        Me.GroupBoxNumberOfBytes.Name = "GroupBoxNumberOfBytes"
        Me.GroupBoxNumberOfBytes.Size = New System.Drawing.Size(120, 63)
        Me.GroupBoxNumberOfBytes.TabIndex = 23
        Me.GroupBoxNumberOfBytes.TabStop = False
        Me.GroupBoxNumberOfBytes.Text = "Number of bytes after split occurs"
        '
        'TextBoxNumberOfBytesAfterSplit
        '
        Me.TextBoxNumberOfBytesAfterSplit.Location = New System.Drawing.Point(6, 32)
        Me.TextBoxNumberOfBytesAfterSplit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxNumberOfBytesAfterSplit.MaxLength = 14
        Me.TextBoxNumberOfBytesAfterSplit.Name = "TextBoxNumberOfBytesAfterSplit"
        Me.TextBoxNumberOfBytesAfterSplit.Size = New System.Drawing.Size(108, 23)
        Me.TextBoxNumberOfBytesAfterSplit.TabIndex = 14
        '
        'TabPageFileJoiner
        '
        Me.TabPageFileJoiner.Controls.Add(Me.ButtonPauseJoin)
        Me.TabPageFileJoiner.Controls.Add(Me.GroupBoxJoinInfo)
        Me.TabPageFileJoiner.Controls.Add(Me.CheckBoxDeletePieces)
        Me.TabPageFileJoiner.Controls.Add(Me.GroupBoxJoinFolder)
        Me.TabPageFileJoiner.Controls.Add(Me.GroupBoxJoinFile)
        Me.TabPageFileJoiner.Controls.Add(Me.ProgressBarJoin)
        Me.TabPageFileJoiner.Controls.Add(Me.ButtonJoinFile)
        Me.TabPageFileJoiner.Location = New System.Drawing.Point(4, 24)
        Me.TabPageFileJoiner.Name = "TabPageFileJoiner"
        Me.TabPageFileJoiner.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageFileJoiner.Size = New System.Drawing.Size(436, 400)
        Me.TabPageFileJoiner.TabIndex = 1
        Me.TabPageFileJoiner.Text = "File Joiner"
        Me.TabPageFileJoiner.UseVisualStyleBackColor = True
        '
        'ButtonPauseJoin
        '
        Me.ButtonPauseJoin.Location = New System.Drawing.Point(13, 243)
        Me.ButtonPauseJoin.Name = "ButtonPauseJoin"
        Me.ButtonPauseJoin.Size = New System.Drawing.Size(75, 25)
        Me.ButtonPauseJoin.TabIndex = 27
        Me.ButtonPauseJoin.Text = "Pause"
        Me.ButtonPauseJoin.UseVisualStyleBackColor = True
        '
        'GroupBoxJoinInfo
        '
        Me.GroupBoxJoinInfo.Controls.Add(Me.LabelJoinFileName)
        Me.GroupBoxJoinInfo.Controls.Add(Me.LabelJoinNumberOfPieces)
        Me.GroupBoxJoinInfo.Location = New System.Drawing.Point(6, 122)
        Me.GroupBoxJoinInfo.Name = "GroupBoxJoinInfo"
        Me.GroupBoxJoinInfo.Size = New System.Drawing.Size(421, 63)
        Me.GroupBoxJoinInfo.TabIndex = 26
        Me.GroupBoxJoinInfo.TabStop = False
        Me.GroupBoxJoinInfo.Text = "Info (.Join file content)"
        '
        'LabelJoinFileName
        '
        Me.LabelJoinFileName.AutoSize = True
        Me.LabelJoinFileName.Location = New System.Drawing.Point(6, 19)
        Me.LabelJoinFileName.Name = "LabelJoinFileName"
        Me.LabelJoinFileName.Size = New System.Drawing.Size(60, 15)
        Me.LabelJoinFileName.TabIndex = 7
        Me.LabelJoinFileName.Text = "FileName:"
        '
        'LabelJoinNumberOfPieces
        '
        Me.LabelJoinNumberOfPieces.AutoSize = True
        Me.LabelJoinNumberOfPieces.Location = New System.Drawing.Point(6, 35)
        Me.LabelJoinNumberOfPieces.Name = "LabelJoinNumberOfPieces"
        Me.LabelJoinNumberOfPieces.Size = New System.Drawing.Size(104, 15)
        Me.LabelJoinNumberOfPieces.TabIndex = 8
        Me.LabelJoinNumberOfPieces.Text = "Number of pieces:"
        '
        'CheckBoxDeletePieces
        '
        Me.CheckBoxDeletePieces.AutoSize = True
        Me.CheckBoxDeletePieces.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckBoxDeletePieces.Checked = True
        Me.CheckBoxDeletePieces.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBoxDeletePieces.Location = New System.Drawing.Point(180, 193)
        Me.CheckBoxDeletePieces.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CheckBoxDeletePieces.Name = "CheckBoxDeletePieces"
        Me.CheckBoxDeletePieces.Size = New System.Drawing.Size(231, 19)
        Me.CheckBoxDeletePieces.TabIndex = 24
        Me.CheckBoxDeletePieces.Text = "Delete pieces and .Join file after joining"
        Me.CheckBoxDeletePieces.UseVisualStyleBackColor = True
        '
        'GroupBoxJoinFolder
        '
        Me.GroupBoxJoinFolder.Controls.Add(Me.ButtonBrowseJoinFolder)
        Me.GroupBoxJoinFolder.Controls.Add(Me.TextBoxJoinFolder)
        Me.GroupBoxJoinFolder.Location = New System.Drawing.Point(6, 64)
        Me.GroupBoxJoinFolder.Name = "GroupBoxJoinFolder"
        Me.GroupBoxJoinFolder.Size = New System.Drawing.Size(421, 51)
        Me.GroupBoxJoinFolder.TabIndex = 23
        Me.GroupBoxJoinFolder.TabStop = False
        Me.GroupBoxJoinFolder.Text = "Save joined file in folder"
        '
        'ButtonBrowseJoinFolder
        '
        Me.ButtonBrowseJoinFolder.Location = New System.Drawing.Point(374, 18)
        Me.ButtonBrowseJoinFolder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ButtonBrowseJoinFolder.Name = "ButtonBrowseJoinFolder"
        Me.ButtonBrowseJoinFolder.Size = New System.Drawing.Size(41, 26)
        Me.ButtonBrowseJoinFolder.TabIndex = 1
        Me.ButtonBrowseJoinFolder.Text = "..."
        Me.ButtonBrowseJoinFolder.UseVisualStyleBackColor = True
        '
        'TextBoxJoinFolder
        '
        Me.TextBoxJoinFolder.BackColor = System.Drawing.SystemColors.Window
        Me.TextBoxJoinFolder.Location = New System.Drawing.Point(6, 20)
        Me.TextBoxJoinFolder.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxJoinFolder.MaxLength = 1000
        Me.TextBoxJoinFolder.Name = "TextBoxJoinFolder"
        Me.TextBoxJoinFolder.ReadOnly = True
        Me.TextBoxJoinFolder.Size = New System.Drawing.Size(362, 23)
        Me.TextBoxJoinFolder.TabIndex = 5
        '
        'GroupBoxJoinFile
        '
        Me.GroupBoxJoinFile.Controls.Add(Me.TextBoxJoinFileName)
        Me.GroupBoxJoinFile.Controls.Add(Me.ButtonBrowseJoinFile)
        Me.GroupBoxJoinFile.Location = New System.Drawing.Point(6, 6)
        Me.GroupBoxJoinFile.Name = "GroupBoxJoinFile"
        Me.GroupBoxJoinFile.Size = New System.Drawing.Size(421, 51)
        Me.GroupBoxJoinFile.TabIndex = 22
        Me.GroupBoxJoinFile.TabStop = False
        Me.GroupBoxJoinFile.Text = "Browse for .Join file"
        '
        'TextBoxJoinFileName
        '
        Me.TextBoxJoinFileName.BackColor = System.Drawing.SystemColors.Window
        Me.TextBoxJoinFileName.Location = New System.Drawing.Point(6, 20)
        Me.TextBoxJoinFileName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TextBoxJoinFileName.MaxLength = 1000
        Me.TextBoxJoinFileName.Name = "TextBoxJoinFileName"
        Me.TextBoxJoinFileName.ReadOnly = True
        Me.TextBoxJoinFileName.Size = New System.Drawing.Size(362, 23)
        Me.TextBoxJoinFileName.TabIndex = 5
        '
        'ButtonBrowseJoinFile
        '
        Me.ButtonBrowseJoinFile.Location = New System.Drawing.Point(374, 18)
        Me.ButtonBrowseJoinFile.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ButtonBrowseJoinFile.Name = "ButtonBrowseJoinFile"
        Me.ButtonBrowseJoinFile.Size = New System.Drawing.Size(41, 26)
        Me.ButtonBrowseJoinFile.TabIndex = 6
        Me.ButtonBrowseJoinFile.Text = "..."
        Me.ButtonBrowseJoinFile.UseVisualStyleBackColor = True
        '
        'ProgressBarJoin
        '
        Me.ProgressBarJoin.Location = New System.Drawing.Point(13, 225)
        Me.ProgressBarJoin.Name = "ProgressBarJoin"
        Me.ProgressBarJoin.Size = New System.Drawing.Size(408, 11)
        Me.ProgressBarJoin.TabIndex = 21
        '
        'ButtonJoinFile
        '
        Me.ButtonJoinFile.Location = New System.Drawing.Point(132, 243)
        Me.ButtonJoinFile.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ButtonJoinFile.Name = "ButtonJoinFile"
        Me.ButtonJoinFile.Size = New System.Drawing.Size(289, 26)
        Me.ButtonJoinFile.TabIndex = 10
        Me.ButtonJoinFile.Text = ".Join file"
        Me.ButtonJoinFile.UseVisualStyleBackColor = True
        '
        'TabPageOptions
        '
        Me.TabPageOptions.Controls.Add(Me.LabelBiggerIsFaster)
        Me.TabPageOptions.Controls.Add(Me.ButtonRefreshDebugInfo)
        Me.TabPageOptions.Controls.Add(Me.LabelNotRespond)
        Me.TabPageOptions.Controls.Add(Me.LabelDoEvents)
        Me.TabPageOptions.Controls.Add(Me.ComboBoxDoEvents)
        Me.TabPageOptions.Controls.Add(Me.ButtonPauseResume)
        Me.TabPageOptions.Controls.Add(Me.GroupBoxDebugVariables)
        Me.TabPageOptions.Location = New System.Drawing.Point(4, 24)
        Me.TabPageOptions.Name = "TabPageOptions"
        Me.TabPageOptions.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPageOptions.Size = New System.Drawing.Size(436, 400)
        Me.TabPageOptions.TabIndex = 2
        Me.TabPageOptions.Text = "Options"
        Me.TabPageOptions.UseVisualStyleBackColor = True
        '
        'LabelBiggerIsFaster
        '
        Me.LabelBiggerIsFaster.AutoSize = True
        Me.LabelBiggerIsFaster.Location = New System.Drawing.Point(226, 10)
        Me.LabelBiggerIsFaster.Name = "LabelBiggerIsFaster"
        Me.LabelBiggerIsFaster.Size = New System.Drawing.Size(92, 15)
        Me.LabelBiggerIsFaster.TabIndex = 6
        Me.LabelBiggerIsFaster.Text = "(bigger is faster)"
        '
        'ButtonRefreshDebugInfo
        '
        Me.ButtonRefreshDebugInfo.Location = New System.Drawing.Point(349, 134)
        Me.ButtonRefreshDebugInfo.Name = "ButtonRefreshDebugInfo"
        Me.ButtonRefreshDebugInfo.Size = New System.Drawing.Size(75, 57)
        Me.ButtonRefreshDebugInfo.TabIndex = 3
        Me.ButtonRefreshDebugInfo.Text = "Refresh debug info"
        Me.ButtonRefreshDebugInfo.UseVisualStyleBackColor = True
        '
        'LabelNotRespond
        '
        Me.LabelNotRespond.AutoSize = True
        Me.LabelNotRespond.Location = New System.Drawing.Point(8, 33)
        Me.LabelNotRespond.Name = "LabelNotRespond"
        Me.LabelNotRespond.Size = New System.Drawing.Size(381, 15)
        Me.LabelNotRespond.TabIndex = 5
        Me.LabelNotRespond.Text = "(the application may not respond for a long time if the value is too big)"
        '
        'LabelDoEvents
        '
        Me.LabelDoEvents.AutoSize = True
        Me.LabelDoEvents.Location = New System.Drawing.Point(8, 10)
        Me.LabelDoEvents.Name = "LabelDoEvents"
        Me.LabelDoEvents.Size = New System.Drawing.Size(130, 15)
        Me.LabelDoEvents.TabIndex = 4
        Me.LabelDoEvents.Text = "Do events also at every:"
        '
        'ComboBoxDoEvents
        '
        Me.ComboBoxDoEvents.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxDoEvents.FormattingEnabled = True
        Me.ComboBoxDoEvents.Items.AddRange(New Object() {" 1 MB", " 5 MB", "15 MB", "25 MB", "35 MB", "45 MB"})
        Me.ComboBoxDoEvents.Location = New System.Drawing.Point(154, 6)
        Me.ComboBoxDoEvents.Name = "ComboBoxDoEvents"
        Me.ComboBoxDoEvents.Size = New System.Drawing.Size(66, 23)
        Me.ComboBoxDoEvents.TabIndex = 0
        '
        'ButtonPauseResume
        '
        Me.ButtonPauseResume.Location = New System.Drawing.Point(349, 71)
        Me.ButtonPauseResume.Name = "ButtonPauseResume"
        Me.ButtonPauseResume.Size = New System.Drawing.Size(75, 57)
        Me.ButtonPauseResume.TabIndex = 2
        Me.ButtonPauseResume.Text = "Pause Resume"
        Me.ButtonPauseResume.UseVisualStyleBackColor = True
        '
        'GroupBoxDebugVariables
        '
        Me.GroupBoxDebugVariables.Controls.Add(Me.TextBoxDebugVariables)
        Me.GroupBoxDebugVariables.Location = New System.Drawing.Point(11, 51)
        Me.GroupBoxDebugVariables.Name = "GroupBoxDebugVariables"
        Me.GroupBoxDebugVariables.Size = New System.Drawing.Size(332, 219)
        Me.GroupBoxDebugVariables.TabIndex = 0
        Me.GroupBoxDebugVariables.TabStop = False
        Me.GroupBoxDebugVariables.Text = "Debug variables"
        '
        'TextBoxDebugVariables
        '
        Me.TextBoxDebugVariables.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBoxDebugVariables.Location = New System.Drawing.Point(3, 19)
        Me.TextBoxDebugVariables.Name = "TextBoxDebugVariables"
        Me.TextBoxDebugVariables.Size = New System.Drawing.Size(326, 23)
        Me.TextBoxDebugVariables.TabIndex = 0
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.KB360ToolStripMenuItem, Me.KB720ToolStripMenuItem, Me.MB12ToolStripMenuItem, Me.MB138ToolStripMenuItem, Me.ToolStripSeparator1, Me.CustomToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "contextMenuStrip1"
        Me.ContextMenuStrip1.ShowImageMargin = False
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(149, 120)
        '
        'KB360ToolStripMenuItem
        '
        Me.KB360ToolStripMenuItem.Name = "KB360ToolStripMenuItem"
        Me.KB360ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.KB360ToolStripMenuItem.Text = "360 KB (minimum)"
        '
        'KB720ToolStripMenuItem
        '
        Me.KB720ToolStripMenuItem.Name = "KB720ToolStripMenuItem"
        Me.KB720ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.KB720ToolStripMenuItem.Text = "720 KB"
        '
        'MB12ToolStripMenuItem
        '
        Me.MB12ToolStripMenuItem.Name = "MB12ToolStripMenuItem"
        Me.MB12ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.MB12ToolStripMenuItem.Text = "1.2 MB"
        '
        'MB138ToolStripMenuItem
        '
        Me.MB138ToolStripMenuItem.Name = "MB138ToolStripMenuItem"
        Me.MB138ToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.MB138ToolStripMenuItem.Text = "1.38 MB"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(145, 6)
        '
        'CustomToolStripMenuItem
        '
        Me.CustomToolStripMenuItem.Name = "CustomToolStripMenuItem"
        Me.CustomToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.CustomToolStripMenuItem.Text = "Custom"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabelStatus})
        Me.StatusStrip1.Location = New System.Drawing.Point(2, 426)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 17, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(440, 22)
        Me.StatusStrip1.SizingGrip = False
        Me.StatusStrip1.TabIndex = 6
        Me.StatusStrip1.Text = "statusStrip1"
        '
        'ToolStripStatusLabelStatus
        '
        Me.ToolStripStatusLabelStatus.Name = "ToolStripStatusLabelStatus"
        Me.ToolStripStatusLabelStatus.Size = New System.Drawing.Size(26, 17)
        Me.ToolStripStatusLabelStatus.Text = "Idle"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(444, 450)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "File Splitter and Joiner"
        Me.Controls.SetChildIndex(Me.StatusStrip1, 0)
        Me.Controls.SetChildIndex(Me.TabControl1, 0)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPageFileSplitter.ResumeLayout(False)
        Me.TabPageFileSplitter.PerformLayout()
        Me.GroupBoxSplitInfo.ResumeLayout(False)
        Me.GroupBoxSplitInfo.PerformLayout()
        Me.GroupBoxSplitFile.ResumeLayout(False)
        Me.GroupBoxSplitFile.PerformLayout()
        Me.GroupBoxSplitFolder.ResumeLayout(False)
        Me.GroupBoxSplitFolder.PerformLayout()
        Me.GroupBoxNumberOfBytes.ResumeLayout(False)
        Me.GroupBoxNumberOfBytes.PerformLayout()
        Me.TabPageFileJoiner.ResumeLayout(False)
        Me.TabPageFileJoiner.PerformLayout()
        Me.GroupBoxJoinInfo.ResumeLayout(False)
        Me.GroupBoxJoinInfo.PerformLayout()
        Me.GroupBoxJoinFolder.ResumeLayout(False)
        Me.GroupBoxJoinFolder.PerformLayout()
        Me.GroupBoxJoinFile.ResumeLayout(False)
        Me.GroupBoxJoinFile.PerformLayout()
        Me.TabPageOptions.ResumeLayout(False)
        Me.TabPageOptions.PerformLayout()
        Me.GroupBoxDebugVariables.ResumeLayout(False)
        Me.GroupBoxDebugVariables.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents TabControl1 As System.Windows.Forms.TabControl
    Private WithEvents TabPageFileSplitter As System.Windows.Forms.TabPage
    Private WithEvents ButtonPauseSplit As System.Windows.Forms.Button
    Private WithEvents GroupBoxSplitInfo As System.Windows.Forms.GroupBox
    Private WithEvents LabelSplitFileSize As System.Windows.Forms.Label
    Private WithEvents LabelSplitNumberOfPieces As System.Windows.Forms.Label
    Private WithEvents GroupBoxSplitFile As System.Windows.Forms.GroupBox
    Private WithEvents ButtonBrowseSplitFile As System.Windows.Forms.Button
    Private WithEvents TextBoxSplitFileName As System.Windows.Forms.TextBox
    Private WithEvents ButtonSplitFile As System.Windows.Forms.Button
    Private WithEvents LabelNumberOfFiles As System.Windows.Forms.Label
    Private WithEvents CheckBoxGenerateJoinFile As System.Windows.Forms.CheckBox
    Private WithEvents TextBoxNumberOfFiles As System.Windows.Forms.TextBox
    Private WithEvents ProgressBarSplit As System.Windows.Forms.ProgressBar
    Private WithEvents GroupBoxSplitFolder As System.Windows.Forms.GroupBox
    Private WithEvents ButtonBrowseSplitFolder As System.Windows.Forms.Button
    Private WithEvents TextBoxSplitFolder As System.Windows.Forms.TextBox
    Private WithEvents GroupBoxNumberOfBytes As System.Windows.Forms.GroupBox
    Private WithEvents TextBoxNumberOfBytesAfterSplit As System.Windows.Forms.TextBox
    Private WithEvents TabPageFileJoiner As System.Windows.Forms.TabPage
    Private WithEvents ButtonPauseJoin As System.Windows.Forms.Button
    Private WithEvents GroupBoxJoinInfo As System.Windows.Forms.GroupBox
    Private WithEvents LabelJoinFileName As System.Windows.Forms.Label
    Private WithEvents LabelJoinNumberOfPieces As System.Windows.Forms.Label
    Private WithEvents CheckBoxDeletePieces As System.Windows.Forms.CheckBox
    Private WithEvents GroupBoxJoinFolder As System.Windows.Forms.GroupBox
    Private WithEvents ButtonBrowseJoinFolder As System.Windows.Forms.Button
    Private WithEvents TextBoxJoinFolder As System.Windows.Forms.TextBox
    Private WithEvents GroupBoxJoinFile As System.Windows.Forms.GroupBox
    Private WithEvents TextBoxJoinFileName As System.Windows.Forms.TextBox
    Private WithEvents ButtonBrowseJoinFile As System.Windows.Forms.Button
    Private WithEvents ProgressBarJoin As System.Windows.Forms.ProgressBar
    Private WithEvents ButtonJoinFile As System.Windows.Forms.Button
    Private WithEvents TabPageOptions As System.Windows.Forms.TabPage
    Private WithEvents LabelBiggerIsFaster As System.Windows.Forms.Label
    Private WithEvents ButtonRefreshDebugInfo As System.Windows.Forms.Button
    Private WithEvents LabelNotRespond As System.Windows.Forms.Label
    Private WithEvents LabelDoEvents As System.Windows.Forms.Label
    Private WithEvents ComboBoxDoEvents As System.Windows.Forms.ComboBox
    Private WithEvents ButtonPauseResume As System.Windows.Forms.Button
    Private WithEvents GroupBoxDebugVariables As System.Windows.Forms.GroupBox
    Private WithEvents TextBoxDebugVariables As System.Windows.Forms.TextBox
    Private WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Private WithEvents KB360ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents KB720ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents MB12ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents MB138ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Private WithEvents CustomToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Private WithEvents ToolStripStatusLabelStatus As System.Windows.Forms.ToolStripStatusLabel

End Class
