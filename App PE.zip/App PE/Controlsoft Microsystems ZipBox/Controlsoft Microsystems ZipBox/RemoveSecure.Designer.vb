﻿
Partial Class RemoveSecure
    Inherits Metro.Form
    ''' <summary>
    ''' Designer variable used to keep track of non-visual components.
    ''' </summary>
    Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RemoveSecure))
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.GlassButton4 = New Glass.GlassButton()
        Me.GlassButton3 = New Glass.GlassButton()
        Me.listView1 = New WindowsFormsAero.ListView()
        Me.GGlowBox1 = New gGlowBox.gGlowBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GlassButton1 = New Glass.GlassButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GGlowBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.ForeColor = System.Drawing.Color.LightGray
        Me.CheckBox2.Location = New System.Drawing.Point(37, 105)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(231, 17)
        Me.CheckBox2.TabIndex = 33
        Me.CheckBox2.Text = "Incluir Imagens de Diferentes Tamanhos"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.ForeColor = System.Drawing.Color.LightGray
        Me.CheckBox1.Location = New System.Drawing.Point(37, 128)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(132, 17)
        Me.CheckBox1.TabIndex = 32
        Me.CheckBox1.Text = "Incluir SubDiretórios"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'GlassButton4
        '
        Me.GlassButton4.Location = New System.Drawing.Point(145, 538)
        Me.GlassButton4.Name = "GlassButton4"
        Me.GlassButton4.Size = New System.Drawing.Size(111, 29)
        Me.GlassButton4.TabIndex = 31
        Me.GlassButton4.Text = "Remover "
        '
        'GlassButton3
        '
        Me.GlassButton3.Location = New System.Drawing.Point(23, 538)
        Me.GlassButton3.Name = "GlassButton3"
        Me.GlassButton3.Size = New System.Drawing.Size(111, 29)
        Me.GlassButton3.TabIndex = 30
        Me.GlassButton3.Text = "Remover"
        '
        'listView1
        '
        Me.listView1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.listView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.listView1.ForeColor = System.Drawing.Color.Silver
        Me.listView1.Location = New System.Drawing.Point(23, 302)
        Me.listView1.Name = "listView1"
        Me.listView1.Size = New System.Drawing.Size(703, 208)
        Me.listView1.TabIndex = 29
        Me.listView1.UseCompatibleStateImageBehavior = False
        '
        'GGlowBox1
        '
        Me.GGlowBox1.Controls.Add(Me.TextBox1)
        Me.GGlowBox1.Location = New System.Drawing.Point(17, 260)
        Me.GGlowBox1.Name = "GGlowBox1"
        Me.GGlowBox1.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox1.TabIndex = 26
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.ForeColor = System.Drawing.Color.Silver
        Me.TextBox1.Location = New System.Drawing.Point(4, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(353, 22)
        Me.TextBox1.TabIndex = 11
        '
        'GlassButton1
        '
        Me.GlassButton1.Location = New System.Drawing.Point(383, 260)
        Me.GlassButton1.Name = "GlassButton1"
        Me.GlassButton1.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton1.TabIndex = 25
        Me.GlassButton1.Text = "Adicionar"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(645, 168)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(81, 91)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 34
        Me.PictureBox1.TabStop = False
        '
        'RemoveSecure
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(748, 593)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.GlassButton4)
        Me.Controls.Add(Me.GlassButton3)
        Me.Controls.Add(Me.listView1)
        Me.Controls.Add(Me.GGlowBox1)
        Me.Controls.Add(Me.GlassButton1)
        Me.ForeColor = System.Drawing.Color.Silver
        Me.MaximizeBox = False
        Me.Name = "RemoveSecure"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "RemoveSecure"
        Me.Controls.SetChildIndex(Me.GlassButton1, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox1, 0)
        Me.Controls.SetChildIndex(Me.listView1, 0)
        Me.Controls.SetChildIndex(Me.GlassButton3, 0)
        Me.Controls.SetChildIndex(Me.GlassButton4, 0)
        Me.Controls.SetChildIndex(Me.CheckBox1, 0)
        Me.Controls.SetChildIndex(Me.CheckBox2, 0)
        Me.Controls.SetChildIndex(Me.PictureBox1, 0)
        Me.GGlowBox1.ResumeLayout(False)
        Me.GGlowBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents GlassButton4 As Glass.GlassButton
    Friend WithEvents GlassButton3 As Glass.GlassButton
    Private WithEvents listView1 As WindowsFormsAero.ListView
    Friend WithEvents GGlowBox1 As gGlowBox.gGlowBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GlassButton1 As Glass.GlassButton
    Friend WithEvents PictureBox1 As PictureBox
End Class
