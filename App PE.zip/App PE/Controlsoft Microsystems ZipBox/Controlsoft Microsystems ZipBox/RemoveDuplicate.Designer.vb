﻿
Partial Class RemoveDuplicate
    Inherits Metro.Form
    ''' <summary>
    ''' Designer variable used to keep track of non-visual components.
    ''' </summary>
    Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.GGlowBox2 = New gGlowBox.gGlowBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GlassButton2 = New Glass.GlassButton()
        Me.GGlowBox1 = New gGlowBox.gGlowBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GlassButton1 = New Glass.GlassButton()
        Me.listView1 = New WindowsFormsAero.ListView()
        Me.GlassButton3 = New Glass.GlassButton()
        Me.GlassButton4 = New Glass.GlassButton()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.GGlowBox2.SuspendLayout()
        Me.GGlowBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GGlowBox2
        '
        Me.GGlowBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GGlowBox2.Controls.Add(Me.TextBox2)
        Me.GGlowBox2.Location = New System.Drawing.Point(29, 139)
        Me.GGlowBox2.Name = "GGlowBox2"
        Me.GGlowBox2.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox2.TabIndex = 19
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(4, 4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(353, 22)
        Me.TextBox2.TabIndex = 11
        '
        'GlassButton2
        '
        Me.GlassButton2.Location = New System.Drawing.Point(395, 139)
        Me.GlassButton2.Name = "GlassButton2"
        Me.GlassButton2.Size = New System.Drawing.Size(46, 23)
        Me.GlassButton2.TabIndex = 18
        Me.GlassButton2.Text = "..."
        '
        'GGlowBox1
        '
        Me.GGlowBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GGlowBox1.Controls.Add(Me.TextBox1)
        Me.GGlowBox1.Location = New System.Drawing.Point(29, 86)
        Me.GGlowBox1.Name = "GGlowBox1"
        Me.GGlowBox1.Size = New System.Drawing.Size(360, 27)
        Me.GGlowBox1.TabIndex = 17
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Location = New System.Drawing.Point(4, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(353, 22)
        Me.TextBox1.TabIndex = 11
        '
        'GlassButton1
        '
        Me.GlassButton1.Location = New System.Drawing.Point(395, 86)
        Me.GlassButton1.Name = "GlassButton1"
        Me.GlassButton1.Size = New System.Drawing.Size(46, 23)
        Me.GlassButton1.TabIndex = 16
        Me.GlassButton1.Text = "..."
        '
        'listView1
        '
        Me.listView1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.listView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.listView1.Location = New System.Drawing.Point(12, 311)
        Me.listView1.Name = "listView1"
        Me.listView1.Size = New System.Drawing.Size(614, 208)
        Me.listView1.TabIndex = 20
        Me.listView1.UseCompatibleStateImageBehavior = False
        '
        'GlassButton3
        '
        Me.GlassButton3.Location = New System.Drawing.Point(32, 559)
        Me.GlassButton3.Name = "GlassButton3"
        Me.GlassButton3.Size = New System.Drawing.Size(111, 29)
        Me.GlassButton3.TabIndex = 21
        Me.GlassButton3.Text = "Procurar"
        '
        'GlassButton4
        '
        Me.GlassButton4.Location = New System.Drawing.Point(160, 559)
        Me.GlassButton4.Name = "GlassButton4"
        Me.GlassButton4.Size = New System.Drawing.Size(111, 29)
        Me.GlassButton4.TabIndex = 22
        Me.GlassButton4.Text = "Remover "
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.ForeColor = System.Drawing.Color.LightGray
        Me.CheckBox1.Location = New System.Drawing.Point(23, 274)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(132, 17)
        Me.CheckBox1.TabIndex = 23
        Me.CheckBox1.Text = "Incluir SubDiretórios"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.ForeColor = System.Drawing.Color.LightGray
        Me.CheckBox2.Location = New System.Drawing.Point(23, 251)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(231, 17)
        Me.CheckBox2.TabIndex = 24
        Me.CheckBox2.Text = "Incluir Imagens de Diferentes Tamanhos"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'RemoveDuplicate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(642, 606)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.GlassButton4)
        Me.Controls.Add(Me.GlassButton3)
        Me.Controls.Add(Me.listView1)
        Me.Controls.Add(Me.GGlowBox2)
        Me.Controls.Add(Me.GlassButton2)
        Me.Controls.Add(Me.GGlowBox1)
        Me.Controls.Add(Me.GlassButton1)
        Me.ForeColor = System.Drawing.Color.Silver
        Me.MaximizeBox = False
        Me.Name = "RemoveDuplicate"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Remover Arquivos Duplicados"
        Me.Controls.SetChildIndex(Me.GlassButton1, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox1, 0)
        Me.Controls.SetChildIndex(Me.GlassButton2, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox2, 0)
        Me.Controls.SetChildIndex(Me.listView1, 0)
        Me.Controls.SetChildIndex(Me.GlassButton3, 0)
        Me.Controls.SetChildIndex(Me.GlassButton4, 0)
        Me.Controls.SetChildIndex(Me.CheckBox1, 0)
        Me.Controls.SetChildIndex(Me.CheckBox2, 0)
        Me.GGlowBox2.ResumeLayout(False)
        Me.GGlowBox2.PerformLayout()
        Me.GGlowBox1.ResumeLayout(False)
        Me.GGlowBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GGlowBox2 As gGlowBox.gGlowBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GlassButton2 As Glass.GlassButton
    Friend WithEvents GGlowBox1 As gGlowBox.gGlowBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GlassButton1 As Glass.GlassButton
    Private WithEvents listView1 As WindowsFormsAero.ListView
    Friend WithEvents GlassButton3 As Glass.GlassButton
    Friend WithEvents GlassButton4 As Glass.GlassButton
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
End Class
