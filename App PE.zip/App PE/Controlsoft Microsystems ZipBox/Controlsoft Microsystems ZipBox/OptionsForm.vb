'
'Copyright (c)  2008-2009,Domagoj Pintaric
'SharpArchiver is distributed under the terms of the GNU Lesser General Public License
'
'    This file is part of SharpArchiver.
'
'    SharpArchiver is free software: you can redistribute it and/or modify
'    it under the terms of the GNU Lesser General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    SharpArchiver is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with SharpArchiver.  If not, see <http://www.gnu.org/licenses/>.
'
'


Imports System.Text
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Runtime.InteropServices
Imports Microsoft.Win32
Imports System.IO
Imports Cake3

''' <summary>
''' Description of OptionsForm.
''' </summary>
Public Partial Class OptionsForm
	Inherits Form







	<DllImport("kernel32.dll", CharSet := CharSet.Auto)> _
	Public Shared Function GetShortPathName(<MarshalAs(UnmanagedType.LPTStr)> path As String, <MarshalAs(UnmanagedType.LPTStr)> shortPath As StringBuilder, shortPathLength As Integer) As Integer

	End Function

	Private ext As String() = New String() {".zip", ".7z", ".tar", ".gz", ".bz2", ".arc", _
		".arj", ".asd", ".ace", ".mime", ".b64", ".bel", _
		".deb", ".yz1", ".f", ".frz", ".icl", ".ico", _
		".cab", ".jam", ".lha", ".lzh", ".lzs", ".hqx", _
		".cpt", ".dmg", ".pit", ".pak", ".wad", ".rar", _
		".rpm", ".sqx", ".macbin", ".cpio", ".shar", ".uue", _
		".xxe", ".imp", ".yenc", ".zoo", ".ear", ".jar", _
		".war", ".wsz", ".mskin", ".bzs", ".wal", ".wmz", _
		".sae"}

	Public Sub New(tabPageIndex As Integer)
		'
		' The InitializeComponent() call is required for Windows Forms designer support.
		'
		InitializeComponent()
			'
			' TODO: Add constructor code after the InitializeComponent() call.
			'
		Me.tabControl1.SelectedIndex = tabPageIndex
	End Sub

	'Set
	Private Sub SetButtonClick(sender As Object, e As EventArgs)

		Dim br As Integer = 2

		Dim shortPath As New StringBuilder(255)
		GetShortPathName(Utils.GetProgramPath() & "ShellExtension\FEShlExt.dll", shortPath, shortPath.Capacity)

		Dim shellExtIniPath As String = Utils.GetProgramPath() & "ShellExtension\FastExplorer.ini"
		Dim exePath As String = Utils.GetProgramPath() & "SharpArchiver.exe"
		Dim shellExtPath As String = Utils.GetProgramPath() & "ShellExtension\FEShlExt.dll"


		Dim ini As New IniFile(Utils.GetProgramPath() & "settings.ini")
		Dim ini2 As New IniFile(Utils.GetProgramPath() & "ShellExtension\FastExplorer.ini")







		'#Region "File Preview"
		If Me.listRadioButton.Checked = True Then
			ini.IniWriteValue("ListView", "LargeIcons", "false")
			ini.IniWriteValue("ListView", "Details", "false")
			ini.IniWriteValue("ListView", "SmallIcons", "false")
			ini.IniWriteValue("ListView", "List", "true")
		End If

		If Me.detailsRadioButton.Checked = True Then
			ini.IniWriteValue("ListView", "LargeIcons", "false")
			ini.IniWriteValue("ListView", "Details", "true")
			ini.IniWriteValue("ListView", "SmallIcons", "false")
			ini.IniWriteValue("ListView", "List", "false")
		End If

		If Me.largeIconsRadioButton.Checked = True Then
			ini.IniWriteValue("ListView", "LargeIcons", "true")
			ini.IniWriteValue("ListView", "Details", "false")
			ini.IniWriteValue("ListView", "SmallIcons", "false")
			ini.IniWriteValue("ListView", "List", "false")
		End If

		If Me.smallIconsRadioButton.Checked = True Then
			ini.IniWriteValue("ListView", "LargeIcons", "false")
			ini.IniWriteValue("ListView", "Details", "false")
			ini.IniWriteValue("ListView", "SmallIcons", "true")
			ini.IniWriteValue("ListView", "List", "false")
		End If
		'#End Region

		'#Region "Look"
		If Me.classicLookRadioButton.Checked = True Then
			ini.IniWriteValue("Look", "Clasic", "true")
			ini.IniWriteValue("Look", "ModernBlue", "false")
			ini.IniWriteValue("Look", "ModernSilver", "false")
			ini.IniWriteValue("Look", "ModernBlack", "false")
		End If

		If Me.blueLookRadioButton.Checked = True Then
			ini.IniWriteValue("Look", "Clasic", "false")
			ini.IniWriteValue("Look", "ModernBlue", "true")
			ini.IniWriteValue("Look", "ModernSilver", "false")
			ini.IniWriteValue("Look", "ModernBlack", "false")
		End If

		If Me.silverLookRadioButton.Checked = True Then
			ini.IniWriteValue("Look", "Clasic", "false")
			ini.IniWriteValue("Look", "ModernBlue", "false")
			ini.IniWriteValue("Look", "ModernSilver", "true")
			ini.IniWriteValue("Look", "ModernBlack", "false")
		End If

		If Me.blackLookRadioButton.Checked = True Then
			ini.IniWriteValue("Look", "Clasic", "false")
			ini.IniWriteValue("Look", "ModernBlue", "false")
			ini.IniWriteValue("Look", "ModernSilver", "false")
			ini.IniWriteValue("Look", "ModernBlack", "true")
		End If
		'#End Region

		'#Region "Grid"
		If Me.showGridCheckBox.Checked = True Then
			ini.IniWriteValue("ListView", "ShowGrid", "true")
		Else

			ini.IniWriteValue("ListView", "ShowGrid", "false")
		End If
		'#End Region

		'#Region "TempPath"

		ini.IniWriteValue("TempPath", "Path", Me.tempFolderTextBox.Text)

		'#End Region

		'#Region "Default Extract Folder"

		If Me.lastSelectedFolderRadioButton1.Checked = True Then
			ini.IniWriteValue("ExtractFolder", "LastSelectedFolder", "true")
		Else
			ini.IniWriteValue("ExtractFolder", "MyExtractFolderPath", Me.myExtractFolderTextBox.Text)
			ini.IniWriteValue("ExtractFolder", "LastSelectedFolder", "false")
		End If

		'#End Region

		'#Region "Default Add Folder"

		If Me.lastSelectedFolderRadioButton2.Checked = True Then
			ini.IniWriteValue("AddFolder", "LastSelectedFolder", "true")
		Else
			ini.IniWriteValue("AddFolder", "MyAddFolderPath", Me.myExtractFolderTextBox.Text)
			ini.IniWriteValue("AddFolder", "LastSelectedFolder", "false")
		End If


		'#End Region

		'#Region "File Association"



		Dim fa As New FileAssociation()

		For i As Integer = 0 To (fileCheckedListBox.Items.Count - 1)
			If fileCheckedListBox.GetItemCheckState(i) = CheckState.Checked Then

				fa.Associate(ext(i))
			End If
			If fileCheckedListBox.GetItemCheckState(i) = CheckState.Unchecked Then

				fa.Unassociate(ext(i))

			End If
		Next


		'#End Region

		'#Region "Shell Extension"




		If checkBox1.Checked = True Then
			ini.IniClearText(shellExtIniPath)
			Dim checkedItems As New ListView.CheckedListViewItemCollection(listView1)

			ini2.IniWriteValue("Dynamic Items", "Parent" & 1, "0")
			ini2.IniWriteValue("Dynamic Items", "IsSeparator1", "1")
			ini2.IniWriteValue("Dynamic Items", "Checked1", "1")
			ini2.IniWriteValue("Dynamic Items", "FileType1", "AllFileSystemObjects")


			For Each item As ListViewItem In checkedItems
				ini2.IniWriteValue("Dynamic Items", "Parent" & br, "0")
				ini2.IniWriteValue("Dynamic Items", "Application" & br, exePath)
				ini2.IniWriteValue("Dynamic Items", "Caption" & br, item.Text)
				ini2.IniWriteValue("Dynamic Items", "Checked" & br, "1")
				ini2.IniWriteValue("Dynamic Items", "FileType" & br, "AllFileSystemObjects")
				ini2.IniWriteValue("Dynamic Items", "Hint" & br, "")
				ini2.IniWriteValue("Dynamic Items", "IconFile" & br, exePath)
				ini2.IniWriteValue("Dynamic Items", "IconIndex" & br, "0")

				If item.Text = "Extract Here" Then
					ini2.IniWriteValue("Dynamic Items", "Parameters" & br, "eh %1")
				ElseIf item.Text = "Extract To" Then
					ini2.IniWriteValue("Dynamic Items", "Parameters" & br, "et %1")
				ElseIf item.Text = "Compress To Zip File" Then
					ini2.IniWriteValue("Dynamic Items", "Parameters" & br, "c %1")
				ElseIf item.Text = "Encrypt" Then
					ini2.IniWriteValue("Dynamic Items", "Parameters" & br, "enc %1")
				End If

				br += 1
			Next
			ini2.IniWriteValue("Dynamic Items", "Parent" & br, "0")
			ini2.IniWriteValue("Dynamic Items", "IsSeparator" & br, "1")
			ini2.IniWriteValue("Dynamic Items", "Checked" & br, "1")
			ini2.IniWriteValue("Dynamic Items", "FileType" & br, "AllFileSystemObjects")

			ini2.IniWriteValue("Dynamic Items", "Count", br.ToString())

			listView1.Enabled = True
			ini.IniWriteValue("ShellExtension", "Enabled", "true")
				' " /s" da ne prikaze message
			System.Diagnostics.Process.Start("regsvr32", shortPath.ToString() & " /s")
		Else
			listView1.Enabled = False
			ini.IniClearText(shellExtIniPath)
			ini.IniWriteValue("ShellExtension", "Enabled", "false")
			System.Diagnostics.Process.Start("regsvr32", "-u " & shortPath.ToString() & " /s")
		End If
		'#End Region

		Application.Restart()

	End Sub
	'Cancel
	Private Sub CancelButtonClick(sender As Object, e As EventArgs)
		Me.Hide()
	End Sub

	'On Load
	Public Sub OptionsForm_Load(sender As Object, e As System.EventArgs)

		Dim ini As New IniFile(Utils.GetProgramPath() & "settings.ini")
		Dim ini2 As New IniFile(Utils.GetProgramPath() & "\ShellExtension\FastExplorer.ini")




		'#Region "ShellExtension"
		If ini.IniReadValue("ShellExtension", "Enabled") = "true" Then
			checkBox1.Checked = True
			listView1.Enabled = True

			For i As Integer = 1 To 5
				If ini2.IniReadValue("Dynamic Items", "Caption" & i) = "Extract Here" Then
					listView1.Items(0).Checked = True
				End If
				If ini2.IniReadValue("Dynamic Items", "Caption" & i) = "Extract To" Then
					listView1.Items(1).Checked = True
				End If
				If ini2.IniReadValue("Dynamic Items", "Caption" & i) = "Compress To Zip File" Then
					listView1.Items(2).Checked = True
				End If
				If ini2.IniReadValue("Dynamic Items", "Caption" & i) = "Encrypt" Then
					listView1.Items(3).Checked = True

				End If
			Next
		Else
			checkBox1.Checked = False
			listView1.Enabled = False
		End If


		'#End Region

		'#Region "File Association"
		Dim wkey As RegistryKey = Registry.ClassesRoot
		For i As Integer = 0 To (fileCheckedListBox.Items.Count - 1)
			Dim readvalue As RegistryKey = Registry.ClassesRoot.CreateSubKey(ext(i))
			If wkey.OpenSubKey(ext(i), False) IsNot Nothing Then
				If readvalue.GetValue("", "").ToString() = "SharpArchiver" Then
					fileCheckedListBox.SetItemChecked(i, True)
				End If
			End If
			readvalue.Close()
		Next
		'#End Region

		'#Region "File Preview"
		If ini.IniReadValue("ListView", "LargeIcons") = "true" Then
			Me.largeIconsRadioButton.Checked = True
		End If
		If ini.IniReadValue("ListView", "Details") = "true" Then
			Me.detailsRadioButton.Checked = True
		End If
		If ini.IniReadValue("ListView", "SmallIcons") = "true" Then

			Me.smallIconsRadioButton.Checked = True
		End If
		If ini.IniReadValue("ListView", "List") = "true" Then

			Me.listRadioButton.Checked = True
		End If

		'#End Region

		'#Region "Show Grid"
		If ini.IniReadValue("ListView", "ShowGrid") = "true" Then
			Me.showGridCheckBox.Checked = True
		End If

		'#End Region

		'#Region "Look"
		If ini.IniReadValue("Look", "ModernBlue") = "true" Then

			Me.blueLookRadioButton.Checked = True
		End If
		If ini.IniReadValue("Look", "ModernSilver") = "true" Then

			Me.silverLookRadioButton.Checked = True
		End If
		If ini.IniReadValue("Look", "ModernBlack") = "true" Then
			Me.blackLookRadioButton.Checked = True
		End If

		If ini.IniReadValue("Look", "Clasic") = "true" Then
			Me.classicLookRadioButton.Checked = True
		End If

		'#End Region

		'#Region "Temp Path"

		If ini.IniReadValue("TempPath", "Path") = "" Then
			ini.IniWriteValue("TempPath", "Path", Path.GetTempPath())
		End If

		Me.tempFolderTextBox.Text = ini.IniReadValue("TempPath", "Path")


		'#End Region

		'#Region "Default Extract Folder"

		If ini.IniReadValue("ExtractFolder", "LastSelectedFolder") = "true" Then
			Me.lastSelectedFolderRadioButton1.Checked = True
			Me.myExtractFolderTextBox.Enabled = False

			Me.myExtractFolderButton.Enabled = False
		Else
			Me.myExtractFolderRadioButton.Checked = True
			Me.myExtractFolderTextBox.Text = ini.IniReadValue("ExtractFolder", "MyExtractFolderPath")
		End If

		'#End Region

		'#Region "Default Add Folder"
		If ini.IniReadValue("AddFolder", "LastSelectedFolder") = "true" Then
			Me.lastSelectedFolderRadioButton2.Checked = True
			Me.myAddFolderTextBox.Enabled = False

			Me.myAddFolderButton.Enabled = False
		Else
			Me.myAddFolderRadioButton.Checked = True
			Me.myAddFolderTextBox.Text = ini.IniReadValue("AddFolder", "MyAddFolderPath")
		End If

		'#End Region
	End Sub





	Private Sub TempFolderBrowseButtonClick(sender As Object, e As EventArgs)
		If folderBrowserDialog1.ShowDialog() = DialogResult.OK Then

			Me.tempFolderTextBox.Text = folderBrowserDialog1.SelectedPath
		End If
	End Sub

	Private Sub MyExtractFolderButtonClick(sender As Object, e As EventArgs)
		If folderBrowserDialog1.ShowDialog() = DialogResult.OK Then

			Me.myExtractFolderTextBox.Text = folderBrowserDialog1.SelectedPath
		End If

	End Sub

	Private Sub LastSelectedFolderRadioButton1CheckedChanged(sender As Object, e As EventArgs)
		Me.myExtractFolderTextBox.Enabled = False
		Me.myExtractFolderButton.Enabled = False
	End Sub

	Private Sub MyExtractFolderRadioButtonCheckedChanged(sender As Object, e As EventArgs)
		Me.myExtractFolderTextBox.Enabled = True
		Me.myExtractFolderButton.Enabled = True

	End Sub

	Private Sub LastSelectedFolderRadioButton2CheckedChanged(sender As Object, e As EventArgs)
		Me.myAddFolderTextBox.Enabled = False
		Me.myAddFolderButton.Enabled = False
	End Sub

	Private Sub MyAddFolderRadioButtonCheckedChanged(sender As Object, e As EventArgs)
		Me.myAddFolderTextBox.Enabled = True
		Me.myAddFolderButton.Enabled = True
	End Sub

	Private Sub MyAddFolderButtonClick(sender As Object, e As EventArgs)
		If folderBrowserDialog1.ShowDialog() = DialogResult.OK Then

			Me.myAddFolderTextBox.Text = folderBrowserDialog1.SelectedPath
		End If

	End Sub

	Private Sub Button1Click(sender As Object, e As EventArgs)
		For i As Integer = 0 To fileCheckedListBox.Items.Count - 1
			fileCheckedListBox.SetItemChecked(i, True)
		Next
	End Sub

	Private Sub Button2Click(sender As Object, e As EventArgs)
		For i As Integer = 0 To fileCheckedListBox.Items.Count - 1
			fileCheckedListBox.SetItemChecked(i, False)
		Next
	End Sub

	Private Sub Button3Click(sender As Object, e As EventArgs)
		Dim recArchives As Integer() = {0, 1, 2, 3, 4, 5, _
			6, 8, 18, 20, 21, 22, _
			29, 31, 39, 41, 48}
		For Each i As Integer In recArchives
			fileCheckedListBox.SetItemChecked(i, True)
		Next

	End Sub

	Private Sub CheckBox1CheckedChanged(sender As Object, e As EventArgs)
		If checkBox1.Checked = True Then

			listView1.Enabled = True
		Else

			listView1.Enabled = False
		End If
	End Sub

    Private Sub OptionsForm_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
