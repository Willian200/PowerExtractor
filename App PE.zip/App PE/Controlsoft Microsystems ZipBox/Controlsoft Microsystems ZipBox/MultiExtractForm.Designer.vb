'
'Copyright (c)  2008-2009,Domagoj Pintaric
'SharpArchiver is distributed under the terms of the GNU Lesser General Public License
'
'    This file is part of SharpArchiver.
'
'    SharpArchiver is free software: you can redistribute it and/or modify
'    it under the terms of the GNU Lesser General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    SharpArchiver is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with SharpArchiver.  If not, see <http://www.gnu.org/licenses/>.
'
'

Partial Class MultiExtractForm
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer = Nothing

	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Dim resources As New System.ComponentModel.ComponentResourceManager(GetType(MultiExtractForm))
		Me.listView1 = New System.Windows.Forms.ListView()
		Me.columnHeader1 = New System.Windows.Forms.ColumnHeader()
		Me.columnHeader2 = New System.Windows.Forms.ColumnHeader()
		Me.columnHeader3 = New System.Windows.Forms.ColumnHeader()
		Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
		Me.kryptonHeader1 = New ComponentFactory.Krypton.Toolkit.KryptonHeader()
		Me.button1 = New System.Windows.Forms.Button()
		Me.button2 = New System.Windows.Forms.Button()
		Me.textBox1 = New System.Windows.Forms.TextBox()
		Me.button3 = New System.Windows.Forms.Button()
		Me.label1 = New System.Windows.Forms.Label()
		Me.button4 = New System.Windows.Forms.Button()
		Me.button5 = New System.Windows.Forms.Button()
		Me.groupBox1 = New System.Windows.Forms.GroupBox()
		Me.checkBox2 = New System.Windows.Forms.CheckBox()
		Me.checkBox1 = New System.Windows.Forms.CheckBox()
		Me.openFileDialog1 = New System.Windows.Forms.OpenFileDialog()
		Me.folderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
		Me.groupBox1.SuspendLayout()
		Me.SuspendLayout()
		' 
		' listView1
		' 
		Me.listView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.columnHeader1, Me.columnHeader2, Me.columnHeader3})
		Me.listView1.FullRowSelect = True
		Me.listView1.Location = New System.Drawing.Point(0, 54)
		Me.listView1.Name = "listView1"
		Me.listView1.Size = New System.Drawing.Size(488, 168)
		Me.listView1.SmallImageList = Me.imageList1
		Me.listView1.TabIndex = 0
		Me.listView1.UseCompatibleStateImageBehavior = False
		Me.listView1.View = System.Windows.Forms.View.Details
		' 
		' columnHeader1
		' 
		Me.columnHeader1.Text = "File"
		Me.columnHeader1.Width = 81
		' 
		' columnHeader2
		' 
		Me.columnHeader2.Text = "Size"
		Me.columnHeader2.Width = 138
		' 
		' columnHeader3
		' 
		Me.columnHeader3.Text = "Path"
		Me.columnHeader3.Width = 220
		' 
		' imageList1
		' 
		Me.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
		Me.imageList1.ImageSize = New System.Drawing.Size(16, 16)
		Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
		' 
		' kryptonHeader1
		' 
		Me.kryptonHeader1.AutoSize = False
		Me.kryptonHeader1.Dock = System.Windows.Forms.DockStyle.Top
		Me.kryptonHeader1.Location = New System.Drawing.Point(0, 0)
		Me.kryptonHeader1.Name = "kryptonHeader1"
		Me.kryptonHeader1.Size = New System.Drawing.Size(488, 54)
		Me.kryptonHeader1.TabIndex = 1
		Me.kryptonHeader1.Text = "Multi Extract"
		Me.kryptonHeader1.Values.Description = ""
		Me.kryptonHeader1.Values.Heading = "Multi Extract"
		Me.kryptonHeader1.Values.Image = DirectCast(resources.GetObject("kryptonHeader1.Values.Image"), System.Drawing.Image)
		' 
		' button1
		' 
		Me.button1.Location = New System.Drawing.Point(314, 228)
		Me.button1.Name = "button1"
		Me.button1.Size = New System.Drawing.Size(75, 23)
		Me.button1.TabIndex = 2
		Me.button1.Text = "Add File"
		Me.button1.UseVisualStyleBackColor = True
		AddHandler Me.button1.Click, New System.EventHandler(AddressOf Me.Button1Click)
		' 
		' button2
		' 
		Me.button2.Location = New System.Drawing.Point(395, 228)
		Me.button2.Name = "button2"
		Me.button2.Size = New System.Drawing.Size(75, 23)
		Me.button2.TabIndex = 3
		Me.button2.Text = "Remove File"
		Me.button2.UseVisualStyleBackColor = True
		AddHandler Me.button2.Click, New System.EventHandler(AddressOf Me.Button2Click)
		' 
		' textBox1
		' 
		Me.textBox1.Location = New System.Drawing.Point(6, 33)
		Me.textBox1.Name = "textBox1"
		Me.textBox1.Size = New System.Drawing.Size(371, 20)
		Me.textBox1.TabIndex = 4
		' 
		' button3
		' 
		Me.button3.Location = New System.Drawing.Point(383, 31)
		Me.button3.Name = "button3"
		Me.button3.Size = New System.Drawing.Size(75, 23)
		Me.button3.TabIndex = 5
		Me.button3.Text = "Browse"
		Me.button3.UseVisualStyleBackColor = True
		AddHandler Me.button3.Click, New System.EventHandler(AddressOf Me.Button3Click)
		' 
		' label1
		' 
		Me.label1.Location = New System.Drawing.Point(6, 16)
		Me.label1.Name = "label1"
		Me.label1.Size = New System.Drawing.Size(100, 14)
		Me.label1.TabIndex = 6
		Me.label1.Text = "Extract To:"
		' 
		' button4
		' 
		Me.button4.Location = New System.Drawing.Point(320, 367)
		Me.button4.Name = "button4"
		Me.button4.Size = New System.Drawing.Size(75, 23)
		Me.button4.TabIndex = 7
		Me.button4.Text = "Extract"
		Me.button4.UseVisualStyleBackColor = True
		AddHandler Me.button4.Click, New System.EventHandler(AddressOf Me.Button4Click)
		' 
		' button5
		' 
		Me.button5.Location = New System.Drawing.Point(401, 367)
		Me.button5.Name = "button5"
		Me.button5.Size = New System.Drawing.Size(75, 23)
		Me.button5.TabIndex = 8
		Me.button5.Text = "Cancel"
		Me.button5.UseVisualStyleBackColor = True
		AddHandler Me.button5.Click, New System.EventHandler(AddressOf Me.Button5Click)
		' 
		' groupBox1
		' 
		Me.groupBox1.Controls.Add(Me.checkBox2)
		Me.groupBox1.Controls.Add(Me.checkBox1)
		Me.groupBox1.Controls.Add(Me.label1)
		Me.groupBox1.Controls.Add(Me.textBox1)
		Me.groupBox1.Controls.Add(Me.button3)
		Me.groupBox1.Location = New System.Drawing.Point(12, 259)
		Me.groupBox1.Name = "groupBox1"
		Me.groupBox1.Size = New System.Drawing.Size(464, 102)
		Me.groupBox1.TabIndex = 9
		Me.groupBox1.TabStop = False
		Me.groupBox1.Text = "Options"
		' 
		' checkBox2
		' 
		Me.checkBox2.Checked = True
		Me.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked
		Me.checkBox2.Location = New System.Drawing.Point(6, 80)
		Me.checkBox2.Name = "checkBox2"
		Me.checkBox2.Size = New System.Drawing.Size(104, 15)
		Me.checkBox2.TabIndex = 8
		Me.checkBox2.Text = "Overwrite Files"
		Me.checkBox2.UseVisualStyleBackColor = True
		' 
		' checkBox1
		' 
		Me.checkBox1.Checked = True
		Me.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked
		Me.checkBox1.Location = New System.Drawing.Point(6, 59)
		Me.checkBox1.Name = "checkBox1"
		Me.checkBox1.Size = New System.Drawing.Size(104, 15)
		Me.checkBox1.TabIndex = 7
		Me.checkBox1.Text = "Create Folders"
		Me.checkBox1.UseVisualStyleBackColor = True
		' 
		' openFileDialog1
		' 
		Me.openFileDialog1.FileName = "openFileDialog1"
		' 
		' MultiExtractForm
		' 
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(488, 397)
		Me.ControlBox = False
		Me.Controls.Add(Me.groupBox1)
		Me.Controls.Add(Me.button5)
		Me.Controls.Add(Me.button4)
		Me.Controls.Add(Me.button2)
		Me.Controls.Add(Me.button1)
		Me.Controls.Add(Me.kryptonHeader1)
		Me.Controls.Add(Me.listView1)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
		Me.Icon = DirectCast(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.MaximizeBox = False
		Me.Name = "MultiExtractForm"
		Me.ShowInTaskbar = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "SharpArchiver"
		Me.groupBox1.ResumeLayout(False)
		Me.groupBox1.PerformLayout()
		Me.ResumeLayout(False)
	End Sub
	Private imageList1 As System.Windows.Forms.ImageList
	Private folderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
	Private openFileDialog1 As System.Windows.Forms.OpenFileDialog
	Private checkBox1 As System.Windows.Forms.CheckBox
	Private checkBox2 As System.Windows.Forms.CheckBox
	Private groupBox1 As System.Windows.Forms.GroupBox
	Private button5 As System.Windows.Forms.Button
	Private button4 As System.Windows.Forms.Button
	Private label1 As System.Windows.Forms.Label
	Private button3 As System.Windows.Forms.Button
	Private textBox1 As System.Windows.Forms.TextBox
	Private button2 As System.Windows.Forms.Button
	Private button1 As System.Windows.Forms.Button
	Private kryptonHeader1 As ComponentFactory.Krypton.Toolkit.KryptonHeader
	Private columnHeader3 As System.Windows.Forms.ColumnHeader
	Private columnHeader2 As System.Windows.Forms.ColumnHeader
	Private columnHeader1 As System.Windows.Forms.ColumnHeader
	Private listView1 As System.Windows.Forms.ListView
End Class
