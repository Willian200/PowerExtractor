﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PictureConverter
    Inherits Metro.Form
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GlassButton8 = New Glass.GlassButton()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.GlassButton5 = New Glass.GlassButton()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GlassButton7 = New Glass.GlassButton()
        Me.GlassButton6 = New Glass.GlassButton()
        Me.GlassButton4 = New Glass.GlassButton()
        Me.GlassButton3 = New Glass.GlassButton()
        Me.GlassButton2 = New Glass.GlassButton()
        Me.GlassButton1 = New Glass.GlassButton()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 55)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(509, 431)
        Me.TabControl1.TabIndex = 11
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GlassButton8)
        Me.TabPage1.Controls.Add(Me.TextBox2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.ComboBox1)
        Me.TabPage1.Controls.Add(Me.GlassButton5)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(501, 405)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Converter Imagem"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GlassButton8
        '
        Me.GlassButton8.Location = New System.Drawing.Point(359, 195)
        Me.GlassButton8.Name = "GlassButton8"
        Me.GlassButton8.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton8.TabIndex = 30
        Me.GlassButton8.Text = "Selecionar"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(21, 197)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(332, 22)
        Me.TextBox2.TabIndex = 29
        Me.TextBox2.Text = "Local a Salvar"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 110)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 13)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Selecione o Formato"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(21, 126)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 27
        '
        'GlassButton5
        '
        Me.GlassButton5.Location = New System.Drawing.Point(359, 59)
        Me.GlassButton5.Name = "GlassButton5"
        Me.GlassButton5.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton5.TabIndex = 26
        Me.GlassButton5.Text = "Selecionar"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(21, 59)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(332, 22)
        Me.TextBox1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GlassButton7)
        Me.TabPage2.Controls.Add(Me.GlassButton6)
        Me.TabPage2.Controls.Add(Me.GlassButton4)
        Me.TabPage2.Controls.Add(Me.GlassButton3)
        Me.TabPage2.Controls.Add(Me.GlassButton2)
        Me.TabPage2.Controls.Add(Me.GlassButton1)
        Me.TabPage2.Controls.Add(Me.ListBox1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(501, 405)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Converter Lista"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GlassButton7
        '
        Me.GlassButton7.Location = New System.Drawing.Point(288, 368)
        Me.GlassButton7.Name = "GlassButton7"
        Me.GlassButton7.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton7.TabIndex = 31
        Me.GlassButton7.Text = "Adicionar"
        '
        'GlassButton6
        '
        Me.GlassButton6.Location = New System.Drawing.Point(288, 339)
        Me.GlassButton6.Name = "GlassButton6"
        Me.GlassButton6.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton6.TabIndex = 30
        Me.GlassButton6.Text = "Adicionar Pasta"
        '
        'GlassButton4
        '
        Me.GlassButton4.Location = New System.Drawing.Point(165, 368)
        Me.GlassButton4.Name = "GlassButton4"
        Me.GlassButton4.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton4.TabIndex = 29
        Me.GlassButton4.Text = "Converter"
        '
        'GlassButton3
        '
        Me.GlassButton3.Location = New System.Drawing.Point(165, 339)
        Me.GlassButton3.Name = "GlassButton3"
        Me.GlassButton3.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton3.TabIndex = 28
        Me.GlassButton3.Text = "Limpar Lista"
        '
        'GlassButton2
        '
        Me.GlassButton2.Location = New System.Drawing.Point(42, 368)
        Me.GlassButton2.Name = "GlassButton2"
        Me.GlassButton2.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton2.TabIndex = 27
        Me.GlassButton2.Text = "Remover"
        '
        'GlassButton1
        '
        Me.GlassButton1.Location = New System.Drawing.Point(42, 339)
        Me.GlassButton1.Name = "GlassButton1"
        Me.GlassButton1.Size = New System.Drawing.Size(117, 23)
        Me.GlassButton1.TabIndex = 26
        Me.GlassButton1.Text = "Adicionar"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(17, 19)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(468, 277)
        Me.ListBox1.TabIndex = 0
        '
        'PictureConverter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(537, 503)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "PictureConverter"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Converter Imagem"
        Me.Controls.SetChildIndex(Me.TabControl1, 0)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents GlassButton8 As Glass.GlassButton
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents GlassButton5 As Glass.GlassButton
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GlassButton7 As Glass.GlassButton
    Friend WithEvents GlassButton6 As Glass.GlassButton
    Friend WithEvents GlassButton4 As Glass.GlassButton
    Friend WithEvents GlassButton3 As Glass.GlassButton
    Friend WithEvents GlassButton2 As Glass.GlassButton
    Friend WithEvents GlassButton1 As Glass.GlassButton
    Public WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
End Class
