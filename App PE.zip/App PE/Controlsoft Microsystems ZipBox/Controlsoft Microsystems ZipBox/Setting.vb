﻿

Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports System.Security.Principal
Imports System.Diagnostics
Imports JTS_Archiver.Associations
Imports System.IO
Partial Public Class Setting
    Public Sub New()
    End Sub
    Public ReadOnly Property IsElevated() As Boolean
        Get
            Return New WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator)
        End Get
    End Property
    Public Function addAssoc(ext As String) As Boolean
        Dim assoc As New AF_FileAssociator(ext)
        Dim ico As String = Path.GetDirectoryName(Application.ExecutablePath) & "\icons\" & ext & ".ico"
        If File.Exists(ico) Then
            assoc.Create("JTS_Archiver", ext.ToUpper() & " Archive", New ProgramIcon(ico), New ExecApplication(Application.ExecutablePath), New OpenWithList(New String() {"JTS_Archiver"}))
            Return True
        Else
            MessageBox.Show("Unable to locate icon file for " & ext & " file association! Please check to ensure your installation is not corrupt!", "Error Associating Files", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            Return False
        End If
    End Function
    Public Sub delAssoc(ext As String)
        Dim assoc As New AF_FileAssociator(ext)
        If assoc.Exists Then
            If assoc.Executable.Path = Application.ExecutablePath Then
                assoc.Delete()
            End If
        End If
    End Sub
    Private Sub button1_Click(sender As Object, e As EventArgs)
            If Not Me.IsElevated Then
                If MessageBox.Show("You need to run JTS Archiver as an Administrator in order to update the file associations." & Environment.NewLine & Environment.NewLine & "Would you like to run as Administrator now?", "Need Admin rights!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                    Dim startInfo As ProcessStartInfo
                    startInfo = New ProcessStartInfo()
                    startInfo.FileName = Application.ExecutablePath
                    startInfo.Arguments = String.Empty
                    startInfo.UseShellExecute = True
                    startInfo.Verb = "runas"
                    Process.Start(startInfo)
                    '  m_parent.settingsQuit()
                    Close()
                End If
            Else
                Dim isErrors As Boolean = False
                For itmno As Integer = 0 To checkedListBox1.Items.Count - 1
                    Dim ext As String = checkedListBox1.Items(itmno).ToString()
                    Dim chkd As CheckState = checkedListBox1.GetItemCheckState(itmno)
                    If chkd = CheckState.Checked Then
                        If addAssoc(ext) = False Then
                            isErrors = True
                        End If
                    Else
                        delAssoc(ext)
                    End If
                Next
                If isErrors = False Then
                    MessageBox.Show("Your selected filetypes has been successfully associated with JTS Archiver.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Close()
                End If
            End If
        End Sub
    End Class






