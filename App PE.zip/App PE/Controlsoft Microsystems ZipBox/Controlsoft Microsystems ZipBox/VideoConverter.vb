﻿Imports System.IO
Public Class VideoConverter
    Dim proc As New Process
    Dim out As String
    Dim stopc As Boolean = False
    Function startConversion()
        stopc = False
        Control.CheckForIllegalCrossThreadCalls = False
        Dim input As String = Me.openfile.FileName
        Dim exepath As String = Application.StartupPath + "\ffmpeg.exe"
        Dim quality As Integer

        If qal.Text = "Low" Then
            quality = "8"
        End If
        If qal.Text = "Medium" Then
            quality = "16"
        End If
        If qal.Text = "Optimal" Then
            quality = "24"
        End If
        If qal.Text = "High" Then
            quality = "30"
        End If

        Dim res As String = ""
        Dim codec As String = ""
        Dim rate As String = ""
        Dim brate As String = ""
        Dim ab As String = ""
        Dim ac As String = ""

        If tovid.Text = "PSP Video (H.264 MP4)" Then
            res = " -s "
            res = res & "368x208"
            codec = " -vcodec "
            codec = codec & "libx264 "
        End If
        If tovid.Text = "iPhone Video (MPEG-4 MP4)" Then
            codec = " -vcodec "
            codec = codec & "libx264 "
        End If


        Dim cmd As String = " -i """ + input + """ -ar 22050 -qscale " & quality & codec & res & " -y """ + out + """" 'ffmpeg commands -y replace
        Dim startinfo As New System.Diagnostics.ProcessStartInfo
        Dim sr As StreamReader

        'If tovid.Text = "Cell Phone (H.263 3GP)" Then
        'cmd = " -i " & input & " -qscale 15 -s 176x144 -r 12 -b 30k -ar 8000 -ab 12.2k -ac 1 -y " & out 'ffmpeg commands -y replace
        'End If

        Dim ffmpegOutput As String

        ' all parameters required to run the process
        startinfo.FileName = exepath
        startinfo.Arguments = cmd
        startinfo.UseShellExecute = False
        startinfo.WindowStyle = ProcessWindowStyle.Hidden
        startinfo.RedirectStandardError = True
        startinfo.RedirectStandardOutput = True
        startinfo.CreateNoWindow = True
        proc.StartInfo = startinfo
        proc.Start() ' start the process



        sr = proc.StandardError 'standard error is used by ffmpeg
        Me.convert.Text = "Cancel"
        Do Until proc.HasExited
            ffmpegOutput = sr.ReadLine
            If bworker.CancellationPending Then 'check if a cancellation request was made
                Exit Function
            End If

        Loop
        Me.convert.Text = "Convert"
        status.Visible = False
        If stopc = False Then
            MsgBox("Conversion of video file completed!", MsgBoxStyle.Information)
        End If

        Return 0
    End Function

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If convert.Text = "Cancel" Then
            stopc = True
            proc.Kill()
            MsgBox("Conversion of video file canceled!", MsgBoxStyle.Information)
            convert.Text = "Convert"
            status.Visible = False
            Kill(out)
            Exit Sub
        End If
        If from.Text = "" Or from.Text <> openfile.FileName Or tovid.Text = "" Or qal.Text = "" Then
            MsgBox("Select a file to convert, format and quality.", MsgBoxStyle.Information, "Select a file")
            Exit Sub
        End If

        out = from.Text
        If out.Contains(".wmv") = True Then
            out = out.Replace(".wmv", "")
        End If
        If out.Contains(".avi") = True Then
            out = out.Replace(".avi", "")
        End If
        If out.Contains(".mov") = True Then
            out = out.Replace(".mov", "")
        End If
        If out.Contains(".mp4") = True Then
            out = out.Replace(".mp4", "")
        End If
        If out.Contains(".3gp") = True Then
            out = out.Replace(".3gp", "")
        End If
        If out.Contains(".flv") = True Then
            out = out.Replace(".flv", "")
        End If
        If out.Contains(".vob") = True Then
            out = out.Replace(".vob", "")
        End If
        If out.Contains(".flv") = True Then
            out = out.Replace(".flv", "")
        End If
        If out.Contains(".mkv") = True Then
            out = out.Replace(".mkv", "")
        End If
        If out.Contains(".webm") = True Then
            out = out.Replace(".webm", "")
        End If

        If tovid.Text = "Windows Media Video (V.7 .WMV)" Then
            out = out & ".wmv"
        End If
        If tovid.Text = "Xvid MPEG-4 Codec (.AVI)" Then
            out = out & ".avi"
        End If
        If tovid.Text = "iPod Video (Apple QuickTime .MOV)" Then
            out = out & ".mov"
        End If
        If tovid.Text = "iPhone Video (MPEG-4 .MP4)" Then
            out = out & ".mp4"
        End If
        If tovid.Text = "Cell Phone (H.263 .3GP)" Then
            out = out & ".3gp"
        End If
        If tovid.Text = "Flash Video Codec (.FLV)" Then
            out = out & ".flv"
        End If
        If tovid.Text = "MPEG Audio Layer 3 (.MP3)" Then
            out = out & ".mp3"
        End If
        If tovid.Text = "Matroska Multimedia Container (.MKV)" Then
            out = out & ".mkv"
        End If
        If tovid.Text = "WebM Video (.WEBM)" Then
            out = out & ".webm"
        End If

        status.Visible = True
        bworker.RunWorkerAsync()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        openfile.ShowDialog()
        from.Text = openfile.FileName

        Button1.Focus()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()

    End Sub

    Private Sub bworker_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles bworker.DoWork
        startConversion()
    End Sub

    Private Sub Main_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        convert.Focus()
    End Sub

    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        qal.Text = "High"
        tovid.Text = "iPhone Video (MPEG-4 .MP4)"
        from.Focus()
    End Sub

    Private Sub from_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles from.Click
        openfile.ShowDialog()
        from.Text = openfile.FileName

        Button1.Focus()
    End Sub


End Class
