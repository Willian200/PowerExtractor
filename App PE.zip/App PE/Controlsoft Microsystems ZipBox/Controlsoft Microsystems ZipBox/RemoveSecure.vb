﻿
Public Partial Class RemoveSecure
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub

    Private Sub RemoveSecure_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GlassButton1_Click(sender As Object, e As EventArgs) Handles GlassButton1.Click

    End Sub
End Class
