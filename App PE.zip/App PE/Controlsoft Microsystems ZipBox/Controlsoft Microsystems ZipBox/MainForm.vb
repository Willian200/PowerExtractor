﻿Imports System.Text
Imports System.IO
Imports System.Security

Public Class MainForm

#Region " Private Members "

    Private m_FileSize As Long                      ' file size divided into byte
    Private m_NumberOfParts As Integer              ' number of parts in the file is divided
    Private m_PieceSize As Long                     ' a portion size in byte
    Private m_Pause As Boolean                      ' specify if it break
    Private m_Part As Integer = 1                   ' the numbers of current trails in work
    Private m_IPart As Integer = 1                  ' the numbers of smaller pieces of Part
    Private m_ToJoin As String() = New String(1) {} ' Join details
    Private m_InputFileName As String = ""          ' file to join
    Private m_OutputFileName As String = ""         ' file to split
    Private m_StreamWriter As StreamWriter          ' file where write
    Private m_StreamReader As StreamReader          ' file where read
    Private m_CloseStreamReader As Boolean          ' specify if stream reader must be closed
    Private m_CloseStreamWriter As Boolean          ' specify if stream writer must be closed
    Private m_IPiece As Long = 5 * 1024 * 1024      ' refresh after every 5 MB
    Private m_SmallParts As Integer                 ' number of small parts in a Part

#End Region

#Region " Form Event Handlers "

    Private Sub MainForm_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Me.CenterToScreen()
        TextBoxSplitFileName.AllowDrop = True
        TextBoxJoinFileName.AllowDrop = True
        Dim items As String() = New String(ComboBoxDoEvents.Items.Count - 1) {}
        ComboBoxDoEvents.Items.CopyTo(items, 0)
        ComboBoxDoEvents.Text = items(0)
        Debug()
    End Sub

    Private Sub MainForm_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing

        If ToolStripStatusLabelStatus.Text <> "Idle" Then
            If ToolStripStatusLabelStatus.Text = "Busy" Then
                ButtonPauseSplit.PerformClick()
                ButtonPauseJoin.PerformClick()
            End If
            If MessageBox.Show("Application is now paused. Really quit?", My.Application.Info.Title, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = DialogResult.No Then
                e.Cancel = True
            End If
            ' Moved to Sub Dispose in MainForm.Designer.vb
            'If Not e.Cancel Then
            '    If m_CloseStreamReader Then
            '        m_StreamReader.Close()
            '    End If
            '    If m_CloseStreamWriter Then
            '        m_StreamWriter.Close()
            '    End If
            'End If
        End If
    End Sub

#End Region

#Region " Button Event Handlers "

    Private Sub ButtonPauseResume_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonPauseResume.Click
        ButtonPauseSplit.PerformClick()
        ButtonPauseJoin.PerformClick()
    End Sub

    Private Sub ButtonRefreshDebugInfo_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonRefreshDebugInfo.Click
        Debug()
    End Sub

    Private Sub ButtonBrowseSplitFile_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonBrowseSplitFile.Click
        Dim OpenFileDialog1 As New OpenFileDialog()
        OpenFileDialog1.Title = "Select file to split"
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            OnFileLoad(OpenFileDialog1.FileName)
        End If
    End Sub

    Private Sub ButtonBrowseJoinFolder_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonBrowseJoinFolder.Click
        ' Save join file in folder button.
        If String.IsNullOrEmpty(TextBoxJoinFileName.Text) Then
            If MessageBox.Show("Would you like to select the .Join file", My.Application.Info.Title, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                ButtonBrowseJoinFile.PerformClick()
            End If
        Else
            Dim FolderBrowserDialog1 As New FolderBrowserDialog()
            FolderBrowserDialog1.ShowNewFolderButton = True
            FolderBrowserDialog1.Description = "Select or create the folder to store the joined file"
            If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then
                TextBoxJoinFolder.Text = FolderBrowserDialog1.SelectedPath
            End If
        End If
    End Sub

    Private Sub ButtonPauseSplit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonPauseSplit.Click
        ' Pause for split.
        If Not ButtonSplitFile.Enabled Then
            m_Pause = Not m_Pause
            If ButtonPauseSplit.Text = "Pause" Then
                ButtonPauseSplit.Text = "Resume"
                ToolStripStatusLabelStatus.Text = "Paused"
            Else
                If ToolStripStatusLabelStatus.Text = "Paused" Then
                    ButtonPauseSplit.Text = "Pause"
                    Split()
                End If
            End If
        End If
    End Sub

    Private Sub ButtonPauseJoin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonPauseJoin.Click
        ' Pauase for join.
        If Not ButtonJoinFile.Enabled Then
            m_Pause = Not m_Pause
            If ButtonPauseJoin.Text = "Pause" Then
                ButtonPauseJoin.Text = "Resume"
                ToolStripStatusLabelStatus.Text = "Paused"
            Else
                If ToolStripStatusLabelStatus.Text = "Paused" Then
                    ButtonPauseJoin.Text = "Pause"
                    Join()
                End If
            End If
        End If
    End Sub

    Private Sub ButtonBrowseSplitFolder_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonBrowseSplitFolder.Click
        ' Browse for a folder in witch to store the files.
        If String.IsNullOrEmpty(TextBoxSplitFileName.Text) Then
            If MessageBox.Show("Would you like to select a file to split", My.Application.Info.Title, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                ButtonBrowseSplitFile.PerformClick()
            End If
        Else
            Dim FolderBrowserDialog1 As New FolderBrowserDialog()
            FolderBrowserDialog1.ShowNewFolderButton = True
            FolderBrowserDialog1.Description = "Select or create the folder to store the splitted files"
            If FolderBrowserDialog1.ShowDialog() = DialogResult.OK Then
                TextBoxSplitFolder.Text = FolderBrowserDialog1.SelectedPath
            End If
        End If
    End Sub

    Private Sub ButtonSplitFile_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonSplitFile.Click
        ' The split button.
        If ToolStripStatusLabelStatus.Text = "Idle" And TextBoxSplitFileName.Text <> "" And TextBoxSplitFolder.Text <> "" And m_NumberOfParts > 1 And TextBoxNumberOfBytesAfterSplit.Text <> "" Then
            If Convert.ToInt64(TextBoxNumberOfBytesAfterSplit.Text) < 1024 * 360 Then
                MessageBox.Show("Piece size to small", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            ElseIf CreateFolder(TextBoxSplitFolder.Text) Then
                Split()
            End If
        End If
    End Sub

    Private Sub ButtonJoinFile_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonJoinFile.Click
        ' The execute join file button.
        If ToolStripStatusLabelStatus.Text = "Idle" And TextBoxJoinFileName.Text <> "" And TextBoxJoinFolder.Text <> "" Then
            If CreateFolder(TextBoxJoinFolder.Text) Then
                Join()
            End If
        End If
    End Sub

    Private Sub ButtonBrowseJoinFile_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonBrowseJoinFile.Click
        ' Browse for the join file.
        Dim OpenFileDialog1 As New OpenFileDialog()
        OpenFileDialog1.Title = "Select .Join file"
        OpenFileDialog1.Filter = "Join file|*.Join;"
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            OnJoin(OpenFileDialog1.FileName)
        End If
    End Sub

#End Region

#Region " ComboBox Event Handlers "

    ' Join succeded.
    ' Manage speed and refresh rate.
    Private Sub ComboBoxDoEvents_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ComboBoxDoEvents.SelectedIndexChanged
        Select Case ComboBoxDoEvents.Text
            Case " 1 MB"
                m_IPiece = 1024 * 1024
                Exit Select
            Case " 5 MB"
                m_IPiece = 5 * 1024 * 1024
                Exit Select
            Case "15 MB"
                m_IPiece = 15 * 1024 * 1024
                Exit Select
            Case "25 MB"
                m_IPiece = 25 * 1024 * 1024
                Exit Select
            Case "35 MB"
                m_IPiece = 35 * 1024 * 1024
                Exit Select
            Case "45 MB"
                m_IPiece = 45 * 1024 * 1024
                Exit Select
        End Select
        Debug()
    End Sub

#End Region

#Region " TextBox Event Handlers "

    Private Sub TextBoxNumberOfBytesAfterSplit_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles TextBoxNumberOfBytesAfterSplit.TextChanged
        ' Number of bytes after the file is split.
        m_PieceSize = Convert.ToInt64(TextBoxNumberOfBytesAfterSplit.Text)
        m_NumberOfParts = ReturnNumberOfParts(m_FileSize, m_PieceSize)
        If m_FileSize < m_PieceSize Then
            TextBoxNumberOfBytesAfterSplit.Text = m_FileSize.ToString()
        End If
        LabelSplitNumberOfPieces.Text = "Number of pieces: " & m_NumberOfParts
    End Sub

    Private Sub TextBoxNumberOfBytesAfterSplit_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles TextBoxNumberOfBytesAfterSplit.KeyDown
        ' Suppress some keys.
        Select Case e.KeyCode
            Case Keys.D0, Keys.D1, Keys.D2, Keys.D3, Keys.D4, Keys.D5, _
            Keys.D6, Keys.D7, Keys.D8, Keys.D9, Keys.NumPad0, Keys.NumPad1, _
            Keys.NumPad2, Keys.NumPad3, Keys.NumPad4, Keys.NumPad5, Keys.NumPad6, Keys.NumPad7, _
            Keys.NumPad8, Keys.NumPad9, Keys.Back, Keys.Left, Keys.Right, Keys.Up, _
            Keys.Down, Keys.Delete
                Exit Select
            Case Keys.Enter
                Exit Select
            Case Else
                e.SuppressKeyPress = True
                Exit Select
        End Select
    End Sub

    Private Sub TextBoxNumberOfFiles_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles TextBoxNumberOfFiles.KeyDown
        ' Suppress some keys.
        Select Case e.KeyCode
            Case Keys.D0, Keys.D1, Keys.D2, Keys.D3, Keys.D4, Keys.D5, _
            Keys.D6, Keys.D7, Keys.D8, Keys.D9, Keys.NumPad0, Keys.NumPad1, _
            Keys.NumPad2, Keys.NumPad3, Keys.NumPad4, Keys.NumPad5, Keys.NumPad6, Keys.NumPad7, _
            Keys.NumPad8, Keys.NumPad9, Keys.Back, Keys.Left, Keys.Right, Keys.Up, _
            Keys.Down, Keys.Delete
                Exit Select
            Case Keys.Enter
                Exit Select
            Case Else
                e.SuppressKeyPress = True
                Exit Select
        End Select
    End Sub

    Private Sub TextBoxNumberOfFiles_TextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles TextBoxNumberOfFiles.TextChanged
        ' Split in equal parts (the last part may be smaller).
        If TextBoxNumberOfFiles.Text <> "" Then
            m_NumberOfParts = Convert.ToInt32(TextBoxNumberOfFiles.Text)
            If m_NumberOfParts = 0 Then
                m_NumberOfParts = 1
            End If
            Dim d As Double = m_FileSize / m_NumberOfParts
            m_PieceSize = Convert.ToInt64(Math.Truncate(d))
            If m_FileSize Mod m_NumberOfParts <> 0 Then
                m_PieceSize += 1
            End If
            TextBoxNumberOfBytesAfterSplit.Text = m_PieceSize.ToString()
        Else
            TextBoxNumberOfBytesAfterSplit.Text = m_FileSize.ToString()
        End If
    End Sub

    Private Sub TextBoxSplitFileName_DragDrop(ByVal sender As Object, ByVal e As DragEventArgs) Handles TextBoxSplitFileName.DragDrop
        ' Same as ButtonSplitFile.
        If Not e.Data.GetDataPresent(DataFormats.Text) Then
            e.Effect = DragDropEffects.None
            Dim fileNames As String() = TryCast(e.Data.GetData(DataFormats.FileDrop), String())
            ' In Visual Basic this fires before the button event resulting in a error. So check for null.
            If fileNames IsNot Nothing Then
                OnFileLoad(fileNames(0))
            End If
        End If
    End Sub

    Private Sub TextBoxJoinFileName_DragDrop(ByVal sender As Object, ByVal e As DragEventArgs) Handles TextBoxJoinFileName.DragDrop
        ' Same as ButtonBrowseJoinFile.
        If Not e.Data.GetDataPresent(DataFormats.Text) Then
            e.Effect = DragDropEffects.None
            Dim fileNames As String() = TryCast(e.Data.GetData(DataFormats.FileDrop), String())
            Dim fileType As String = fileNames(0).Substring(fileNames(0).LastIndexOf("\") + 1)
            ' In Visual Basic, this fires before the button event, so check for null.
            If fileNames IsNot Nothing Then
                If fileType.IndexOf(".Join") <> -1 Then
                    OnJoin(fileNames(0))
                Else
                    MessageBox.Show("Not a .Join file", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            End If
        End If
    End Sub

    Private Sub TextBoxSplitFileName_DragEnter(ByVal sender As Object, ByVal e As DragEventArgs) Handles TextBoxSplitFileName.DragEnter
        ' Can be dragdrop required if autodragdrop = false
        e.Effect = DragDropEffects.Copy
    End Sub

    Private Sub TextBoxJoinFileName_DragEnter(ByVal sender As Object, ByVal e As DragEventArgs) Handles TextBoxJoinFileName.DragEnter
        ' Can be dragdrop required if autodragdrop = false
        e.Effect = DragDropEffects.Copy
    End Sub

#End Region

#Region " ToolStripMenuItem Event Handlers "





    Private Sub TextBoxNumberOfBytesAfterSplit_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles TextBoxNumberOfBytesAfterSplit.MouseDown
        If e.Button = MouseButtons.Right Then
            ContextMenuStrip1.Show(MousePosition.X, MousePosition.Y)
        End If
    End Sub

    Private Sub CustomToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles CustomToolStripMenuItem.Click
        Dim f2 As New PieceSizeDialog()
        If f2.ShowDialog() = DialogResult.OK Then
            TextBoxNumberOfBytesAfterSplit.Text = Convert.ToString(f2.PieceSize)
        End If
    End Sub

    Private Sub KB360ToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles KB360ToolStripMenuItem.Click
        Dim d As Double = 360 * 1024
        'minimum
        m_PieceSize = Convert.ToInt64(d)
        If m_PieceSize > m_FileSize Then
            m_PieceSize = m_FileSize
        End If
        TextBoxNumberOfBytesAfterSplit.Text = Convert.ToString(m_PieceSize)
    End Sub

    Private Sub KB720ToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles KB720ToolStripMenuItem.Click
        Dim d As Double = 720 * 1024
        m_PieceSize = Convert.ToInt64(d)
        If m_PieceSize > m_FileSize Then
            m_PieceSize = m_FileSize
        End If
        TextBoxNumberOfBytesAfterSplit.Text = Convert.ToString(m_PieceSize)
    End Sub

    Private Sub MB12ToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles MB12ToolStripMenuItem.Click
        Dim d As Double = 12 * 1024 * 1024 / 10
        m_PieceSize = Convert.ToInt64(d)
        If m_PieceSize > m_FileSize Then
            m_PieceSize = m_FileSize
        End If
        TextBoxNumberOfBytesAfterSplit.Text = Convert.ToString(m_PieceSize)
    End Sub

    Private Sub MB138ToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles MB138ToolStripMenuItem.Click
        Dim d As Double = 138 * 1024 * 1024 / 100
        '3.5 inch floppy disk
        m_PieceSize = Convert.ToInt64(d)
        If m_PieceSize > m_FileSize Then
            m_PieceSize = m_FileSize
        End If
        TextBoxNumberOfBytesAfterSplit.Text = Convert.ToString(m_PieceSize)
    End Sub

#End Region

#Region " Private Methods "

    ''' <summary>
    ''' Same thing as onload but for Join used by ButtonBrowseJoinFile and TextBoxJoinFileName.
    ''' </summary>
    ''' <param name="fileName">Name of file to join</param>
    Private Sub OnJoin(ByVal fileName As String)
        Dim message As String = ""

        Try
            TextBoxJoinFileName.Text = fileName
            m_ToJoin = LoadFile(fileName)
            LabelJoinFileName.Text = "FileName: " & m_ToJoin(0)
            LabelJoinNumberOfPieces.Text = "Number of Pieces: " & m_ToJoin(1)

            TextBoxJoinFolder.Text = UntilFind(fileName, "\")
            If TextBoxJoinFolder.Text.Length < 3 Then
                TextBoxJoinFolder.Text += "\"
            End If
        Catch ex As NullReferenceException
            message = ex.Message
        Catch ex As IndexOutOfRangeException
            message = ex.Message
        Finally
            If Not String.IsNullOrEmpty(message) Then
                MessageBox.Show("Unable to select join file: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End Try

    End Sub

    ''' <summary>
    ''' Used by TextBoxSplitFileName dragdrop and ButtonBrowseSplitFile.
    ''' </summary>
    ''' <param name="fileName">Name of file to split</param>
    Private Sub OnFileLoad(ByVal fileName As String)
        Dim message As String = ""
        Dim reader As System.IO.StreamReader = Nothing

        Try
            TextBoxSplitFileName.Text = fileName
            TextBoxSplitFolder.Text = UntilFind(fileName, "\")
            If TextBoxSplitFolder.Text.Length < 3 Then
                TextBoxSplitFolder.Text += "\"
            End If
            reader = New System.IO.StreamReader(fileName)
            m_FileSize = reader.BaseStream.Length
            LabelSplitFileSize.Text = "FileSize: " & m_FileSize.ToString()
        Catch ex As OutOfMemoryException
            message = ex.Message
        Catch ex As IOException
            message = ex.Message
        Catch ex As UnauthorizedAccessException
            message = ex.Message
        Catch ex As SecurityException
            message = ex.Message
        Finally
            If reader IsNot Nothing Then
                reader.Close()
            End If
            If Not String.IsNullOrEmpty(message) Then
                MessageBox.Show("Unable get file size: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End Try

        TextBoxNumberOfBytesAfterSplit.Text = m_FileSize.ToString()
        TextBoxNumberOfFiles.Text = ""
        If m_FileSize < 1024 * 360 Then
            MessageBox.Show("File size to small to split, minimum 360 KB", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub

    ''' <summary>
    ''' Read the join file.
    ''' </summary>
    ''' <param name="fileName">Name of join file</param>
    ''' <returns>String array that contains file name and number of parts</returns>
    Private Shared Function LoadFile(ByVal fileName As String) As String()
        Dim j As Integer = 0
        Dim reader As StreamReader = Nothing
        Dim message As String = ""
        ' Calling methods need to check for a NullReferenceException!
        Dim file As String() = Nothing

        If Not String.IsNullOrEmpty(fileName) Then
            Try
                reader = New StreamReader(fileName, True)
                Dim line As String = ""

                'While (line = reader.ReadLine) <> Nothing
                '    j += 1
                'End While
                ' This fixed a bad bug in the Visual Basic version.
                While reader.Peek >= 0
                    line = reader.ReadLine
                    j += 1
                End While

            Catch ex As OutOfMemoryException
                message = ex.Message
            Catch ex As IOException
                message = ex.Message
            Catch ex As UnauthorizedAccessException
                message = ex.Message
            Catch ex As SecurityException
                message = ex.Message
            Finally
                If Not String.IsNullOrEmpty(message) Then
                    MessageBox.Show("Unable to load file: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                If reader IsNot Nothing Then
                    reader.Close()
                End If
            End Try

            Try
                reader = New System.IO.StreamReader(fileName, True)
                reader.BaseStream.Seek(0, System.IO.SeekOrigin.Begin)
                file = New String(j - 1) {}

                For i As Integer = 0 To file.Length - 1
                    file(i) = reader.ReadLine
                Next
            Catch ex As OutOfMemoryException
                message = ex.Message
            Catch ex As IOException
                message = ex.Message
            Catch ex As UnauthorizedAccessException
                message = ex.Message
            Catch ex As SecurityException
                message = ex.Message
            Finally
                If Not String.IsNullOrEmpty(message) Then
                    MessageBox.Show("Unable to load file: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                If reader IsNot Nothing Then
                    reader.Close()
                End If
            End Try
        End If

        Return file

    End Function

    ''' <summary>
    ''' Get number of parts.
    ''' </summary>
    ''' <param name="size">total size</param>
    ''' <param name="pieceSize">size of pieces</param>
    Private Shared Function ReturnNumberOfParts(ByVal size As Long, ByVal pieceSize As Long) As Integer
        Dim r As Integer = 1
        Dim fs As Long = size, ps As Long = pieceSize
        While fs > ps
            fs -= ps
            r += 1
        End While
        Return r
    End Function

    ''' <summary>
    ''' Used by both split and join buttons.
    ''' </summary>
    ''' <param name="folderPath">New folder name</param>
    ''' <returns>True if folder created sucessfully</returns>
    Private Shared Function CreateFolder(ByVal folderPath As String) As Boolean

        Dim returnValue As Boolean = False
        Dim dirInfo As System.IO.DirectoryInfo = Nothing
        Dim message As String = ""

        If Not String.IsNullOrEmpty(folderPath) Then
            Try
                dirInfo = New System.IO.DirectoryInfo(folderPath)
                If dirInfo.Exists Then
                    returnValue = True
                ElseIf MessageBox.Show("Folder: " & folderPath & " does not exist. Would you like to create the folder?", My.Application.Info.Title, _
                                       MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) = DialogResult.Yes Then
                    dirInfo.Create()
                    dirInfo = New System.IO.DirectoryInfo(folderPath)
                    If dirInfo.Exists Then
                        returnValue = True
                    Else
                        MessageBox.Show("Invalid Path", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        returnValue = False
                    End If
                End If
            Catch ex As OutOfMemoryException
                message = ex.Message
            Catch ex As IOException
                message = ex.Message
                returnValue = False
            Catch ex As UnauthorizedAccessException
                message = ex.Message
                returnValue = False
            Catch ex As SecurityException
                message = ex.Message
                returnValue = False
            Finally
                If Not String.IsNullOrEmpty(message) Then
                    MessageBox.Show("Unable to create folder: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End Try
        Else
            returnValue = False
        End If

        Return returnValue

    End Function

    ''' <summary>
    ''' To save the join file.
    ''' </summary>
    ''' <param name="fileName">Name of join file</param>
    ''' <param name="data">Name and number of parts</param>
    Private Shared Sub FileSave(ByVal fileName As String, ByVal data As String())

        Dim writer As System.IO.StreamWriter = Nothing
        Dim message As String = ""

        If Not String.IsNullOrEmpty(fileName) Then
            Try
                writer = New System.IO.StreamWriter(fileName, False, Encoding.UTF8)
                For i As Integer = 0 To data.Length - 1
                    writer.WriteLine(data(i))
                Next
            Catch ex As OutOfMemoryException
                message = ex.Message
            Catch ex As IOException
                message = ex.Message
            Catch ex As UnauthorizedAccessException
                message = ex.Message
            Catch ex As SecurityException
                message = ex.Message
            Finally
                If Not String.IsNullOrEmpty(message) Then
                    MessageBox.Show("Unable to save file: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                If writer IsNot Nothing Then
                    writer.Close()
                End If
            End Try
        End If

    End Sub

    Private Shared Function UntilFind(ByVal a As String, ByVal b As String) As String
        ' Used to ignore the file name in path.
        Dim r As String = ""
        For i As Integer = a.Length - b.Length To 1 Step -1
            If a.Substring(i, b.Length) = b Then
                r = a.Substring(0, i)
                Exit For
            End If
        Next
        Return r
    End Function

    Private Shared Function ReturnFileName(ByVal a As String, ByVal b As String) As String
        ' Used to get only the file name.
        Dim returnValue As String = ""
        For i As Integer = a.Length - b.Length To 1 Step -1
            If a.Substring(i, b.Length) = b Then
                returnValue = a.Substring(i + 1)
                Exit For
            End If
        Next
        Return returnValue
    End Function

    Private Sub Split()
        Dim message As String = ""

        ToolStripStatusLabelStatus.Text = "Busy"

        Try
            ' Must always.
            If m_Part = 1 And m_IPart = 1 And Not m_Pause Then
                ' Only the first part.
                ComboBoxDoEvents.Enabled = False
                ButtonSplitFile.Enabled = False
                m_StreamReader = New System.IO.StreamReader(TextBoxSplitFileName.Text)
                m_CloseStreamReader = True
                m_OutputFileName = TextBoxSplitFolder.Text
                If m_OutputFileName.Length > 0 Then
                    If m_OutputFileName.Substring(m_OutputFileName.Length - 1) = "\" Then
                        m_OutputFileName = m_OutputFileName.Substring(0, m_OutputFileName.Length - 1)
                    End If
                End If
            End If
            If m_StreamReader.BaseStream.Length = m_FileSize Then
                ' In case that file sharing has not been changed.
                While m_Part <= m_NumberOfParts
                    If Not m_Pause Then
                        If m_Part * m_PieceSize > m_FileSize Then
                            m_PieceSize = m_FileSize - (m_Part - 1) * m_PieceSize
                        End If
                        ' Refresh every 5 MB or value ipieces.
                        If m_IPart = 1 Then
                            m_StreamWriter = New System.IO.StreamWriter(((m_OutputFileName & "\") + ReturnFileName(TextBoxSplitFileName.Text, "\") & ".") + m_Part.ToString())
                            m_CloseStreamWriter = True
                            m_SmallParts = ReturnNumberOfParts(m_PieceSize, m_IPiece)
                        End If

                        While m_IPart <= m_SmallParts
                            If Not m_Pause Then
                                Dim trueipiece As Long = m_IPiece
                                If m_IPart * m_IPiece > m_PieceSize Then
                                    m_IPiece = m_PieceSize - (m_IPart - 1) * m_IPiece
                                End If
                                For ii As Long = 0 To m_IPiece - 1
                                    m_StreamWriter.BaseStream.WriteByte(CByte(m_StreamReader.BaseStream.ReadByte()))
                                Next
                                m_IPiece = trueipiece
                                ProgressBarSplit.Value = Convert.ToInt32((m_Part - 1) * 100 / m_NumberOfParts + (m_IPart * 100 / m_SmallParts) / m_NumberOfParts)
                                Debug()
                                Application.DoEvents()
                                m_IPart += 1
                            Else
                                Exit While
                            End If
                        End While

                        If Not m_Pause Then
                            m_IPart = 1
                            m_StreamWriter.Close()
                            m_CloseStreamWriter = False
                            ProgressBarSplit.Value = Convert.ToInt32(m_Part * 100 / m_NumberOfParts)
                            Debug()
                            Application.DoEvents()
                            m_Part += 1
                        End If
                    Else
                        Exit While
                    End If
                End While
            Else
                MessageBox.Show("File size has changed", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        Catch ex As OutOfMemoryException
            message = ex.Message
        Catch ex As NullReferenceException
            message = ex.Message
        Catch ex As IndexOutOfRangeException
            message = ex.Message
        Catch ex As IOException
            message = ex.Message
        Catch ex As UnauthorizedAccessException
            message = ex.Message
        Catch ex As SecurityException
            message = ex.Message
        Finally
            If Not String.IsNullOrEmpty(message) Then
                MessageBox.Show("Unable to split file: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                ToolStripStatusLabelStatus.Text = "Error"
            End If
            If m_StreamReader IsNot Nothing Then
                m_StreamReader.Close()
                m_CloseStreamReader = False
            End If
        End Try

        ' Code below this line will execute only at the end.
        If Not m_Pause Then
            ' Don't generate join file if there has been an error.
            If String.IsNullOrEmpty(message) Then
                ' Moved to try-catch-finally.
                'm_StreamReader.Close()
                'm_CloseStreamReader = False
                MessageBox.Show("Split succeeded!", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
                If CheckBoxGenerateJoinFile.Checked Then
                    Dim generateJoin As String() = New String(1) {}
                    generateJoin(0) = ReturnFileName(TextBoxSplitFileName.Text, "\")
                    generateJoin(1) = m_NumberOfParts.ToString()
                    Try
                        FileSave((m_OutputFileName & "\") + ReturnFileName(TextBoxSplitFileName.Text, "\") & ".Join", generateJoin)
                        MessageBox.Show("Join file has been created", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Catch ex As OutOfMemoryException
                        message = ex.Message
                    Catch ex As IOException
                        message = ex.Message
                    Catch ex As UnauthorizedAccessException
                        message = ex.Message
                    Catch ex As SecurityException
                        message = ex.Message
                    Finally
                        If Not String.IsNullOrEmpty(message) Then
                            MessageBox.Show("Unable to create join file: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                            ToolStripStatusLabelStatus.Text = "Error"
                        End If
                    End Try
                End If
            End If
            ComboBoxDoEvents.Enabled = True
            ButtonSplitFile.Enabled = True
            ProgressBarSplit.Value = 0
            ToolStripStatusLabelStatus.Text = "Idle"
            ButtonPauseSplit.Text = "Pause"
            m_Pause = False
            m_Part = 1
            m_IPart = 1
        End If
        Debug()
    End Sub

    'Split succeded
    Private Sub Join()
        Dim message As String = ""

        Try
            ' Join procedure with refresh capabilities.
            ToolStripStatusLabelStatus.Text = "Busy"
            ' Must do this every time.
            If m_Part = 1 And m_IPart = 1 And Not m_Pause Then
                'do just first time
                ComboBoxDoEvents.Enabled = False
                ButtonJoinFile.Enabled = False
                m_InputFileName = UntilFind(TextBoxJoinFileName.Text, "\") & "\"
                Dim SaveFolder As String = TextBoxJoinFolder.Text
                If SaveFolder.Substring(SaveFolder.Length - 1) <> "\" Then
                    SaveFolder += "\"
                End If
                m_StreamWriter = New StreamWriter(SaveFolder + m_ToJoin(0))
                m_CloseStreamWriter = True
                m_NumberOfParts = Convert.ToInt32(m_ToJoin(1))
            End If
            While m_Part <= m_NumberOfParts
                If Not m_Pause Then
                    ' I want a refresh every 5 MB value of ipiece
                    ' and code to be executed only in the early cut.
                    If m_IPart = 1 Then
                        m_StreamReader = New StreamReader((m_InputFileName + m_ToJoin(0) & ".") + m_Part.ToString())
                        m_CloseStreamReader = True
                        m_PieceSize = m_StreamReader.BaseStream.Length
                        m_SmallParts = ReturnNumberOfParts(m_PieceSize, m_IPiece)
                    End If

                    While m_IPart <= m_SmallParts
                        If Not m_Pause Then
                            Dim trueipiece As Long = m_IPiece
                            If m_IPart * m_IPiece > m_PieceSize Then
                                m_IPiece = m_PieceSize - (m_IPart - 1) * m_IPiece
                            End If
                            For ii As Long = 0 To m_IPiece - 1
                                m_StreamWriter.BaseStream.WriteByte(CByte(m_StreamReader.BaseStream.ReadByte()))
                            Next
                            m_IPiece = trueipiece
                            ProgressBarJoin.Value = Convert.ToInt32((m_Part - 1) * 100 / m_NumberOfParts + (m_IPart * 100 / m_SmallParts) / m_NumberOfParts)
                            Debug()
                            Application.DoEvents()
                            m_IPart += 1
                        Else
                            Exit While
                        End If
                    End While
                    If Not m_Pause Then
                        ' Code that is executed at the end of each part.
                        m_IPart = 1
                        ' Moved to Finally.
                        'm_StreamReader.Close()
                        'm_CloseStreamReader = False
                        ProgressBarJoin.Value = Convert.ToInt32(m_Part * 100 / m_NumberOfParts)
                        Debug()
                        Application.DoEvents()
                        m_Part += 1
                    End If
                Else
                    Exit While
                End If
            End While
        Catch ex As OutOfMemoryException
            message = ex.Message
        Catch ex As NullReferenceException
            message = ex.Message
        Catch ex As IndexOutOfRangeException
            message = ex.Message
        Catch ex As IOException
            message = ex.Message
        Catch ex As UnauthorizedAccessException
            message = ex.Message
        Catch ex As SecurityException
            message = ex.Message
        Finally
            If Not String.IsNullOrEmpty(message) Then
                MessageBox.Show("Unable to join file: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                ToolStripStatusLabelStatus.Text = "Error"
            End If
            If m_StreamWriter IsNot Nothing Then
                m_StreamWriter.Close()
            End If
            m_CloseStreamReader = False
        End Try

        ' Code below this will execute only at the end of the process
        ' But don't execute this if there was error.
        If Not m_Pause And String.IsNullOrEmpty(message) Then
            ' Moved to try-catch-finally
            'm_StreamWriter.Close()
            m_CloseStreamWriter = False
            MessageBox.Show("Join succeeded!", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
            If CheckBoxDeletePieces.Checked Then
                Try
                    For i As Integer = 1 To m_NumberOfParts
                        File.Delete((m_InputFileName + m_ToJoin(0) & ".") + i.ToString())
                    Next
                    File.Delete(TextBoxJoinFileName.Text)
                Catch ex As OutOfMemoryException
                    message = ex.Message
                Catch ex As IOException
                    message = ex.Message
                Catch ex As UnauthorizedAccessException
                    message = ex.Message
                Catch ex As SecurityException
                    message = ex.Message
                Finally
                    If String.IsNullOrEmpty(message) Then
                        MessageBox.Show("Pieces and .Join file were deleted", My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        TextBoxJoinFileName.Text = ""
                        ToolStripStatusLabelStatus.Text = "Idle"
                    Else
                        MessageBox.Show("Unable to delete pieces and/or .Join file: " & message, My.Application.Info.Title, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        ToolStripStatusLabelStatus.Text = "Error"
                    End If
                End Try
            End If
            ' Always do these things.
            ComboBoxDoEvents.Enabled = True
            ButtonJoinFile.Enabled = True
            ProgressBarJoin.Value = 0
            ButtonPauseJoin.Text = "Pause"
            m_Pause = False
            m_Part = 1
            m_IPart = 1
        End If
        Debug()
    End Sub

    ' For greater processing speed.
    Private Sub Debug()
        'Dim di As String() = New String(11) {}
        ' Added for Visual Basic.
        Dim di As String()
        ReDim Preserve di(11)
        di(0) = "File size = " & m_FileSize.ToString()
        di(1) = "Piece size = " & m_PieceSize.ToString()
        di(2) = "Number of pieces = " & m_NumberOfParts.ToString()
        di(3) = ""
        di(4) = "Do events also at every (nr. of bytes) = " & m_IPiece.ToString()
        di(5) = "Refreshes in a piece = " & m_SmallParts.ToString()
        di(6) = ""
        di(7) = "Part nr. = " & m_Part.ToString()
        di(8) = "Refresh nr. = " & m_IPart.ToString()
        di(9) = ""
        di(10) = "stream reader not closed = " & m_CloseStreamReader.ToString()
        di(11) = "stream writer not closed = " & m_CloseStreamWriter.ToString()
        TextBoxDebugVariables.Lines = di
        ButtonPauseSplit.Enabled = True
        ButtonPauseJoin.Enabled = True
        ButtonPauseResume.Enabled = True
    End Sub

#End Region

End Class
