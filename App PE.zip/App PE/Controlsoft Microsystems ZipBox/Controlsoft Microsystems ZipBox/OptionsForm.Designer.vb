'
'Copyright (c)  2008-2009,Domagoj Pintaric
'SharpArchiver is distributed under the terms of the GNU Lesser General Public License
'
'    This file is part of SharpArchiver.
'
'    SharpArchiver is free software: you can redistribute it and/or modify
'    it under the terms of the GNU Lesser General Public License as published by
'    the Free Software Foundation, either version 3 of the License, or
'    (at your option) any later version.
'
'    SharpArchiver is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
'    GNU General Public License for more details.
'
'    You should have received a copy of the GNU General Public License
'    along with SharpArchiver.  If not, see <http://www.gnu.org/licenses/>.
'
'

Partial Class OptionsForm
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer = Nothing

	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub

	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("Extract Here", 0)
        Dim ListViewItem2 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("Extract To", 0)
        Dim ListViewItem3 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("Compress To Zip File", 0)
        Dim ListViewItem4 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("Encrypt", 0)
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OptionsForm))
        Me.setButton = New System.Windows.Forms.Button()
        Me.cancelButton = New System.Windows.Forms.Button()
        Me.viewGroupBox = New System.Windows.Forms.GroupBox()
        Me.gridGroupBox = New System.Windows.Forms.GroupBox()
        Me.showGridCheckBox = New System.Windows.Forms.CheckBox()
        Me.lookGroupBox = New System.Windows.Forms.GroupBox()
        Me.blackLookRadioButton = New System.Windows.Forms.RadioButton()
        Me.blueLookRadioButton = New System.Windows.Forms.RadioButton()
        Me.silverLookRadioButton = New System.Windows.Forms.RadioButton()
        Me.label2 = New System.Windows.Forms.Label()
        Me.classicLookRadioButton = New System.Windows.Forms.RadioButton()
        Me.filePreviewGroupBox = New System.Windows.Forms.GroupBox()
        Me.detailsRadioButton = New System.Windows.Forms.RadioButton()
        Me.largeIconsRadioButton = New System.Windows.Forms.RadioButton()
        Me.listRadioButton = New System.Windows.Forms.RadioButton()
        Me.smallIconsRadioButton = New System.Windows.Forms.RadioButton()
        Me.tempFolderGroupBox = New System.Windows.Forms.GroupBox()
        Me.tempFolderBrowseButton = New System.Windows.Forms.Button()
        Me.tempFolderTextBox = New System.Windows.Forms.TextBox()
        Me.myExtractFolderButton = New System.Windows.Forms.Button()
        Me.myExtractFolderTextBox = New System.Windows.Forms.TextBox()
        Me.fileAssociationGroupBox = New System.Windows.Forms.GroupBox()
        Me.button3 = New System.Windows.Forms.Button()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.fileCheckedListBox = New System.Windows.Forms.CheckedListBox()
        Me.tabControl1 = New System.Windows.Forms.TabControl()
        Me.ViewTabPage = New System.Windows.Forms.TabPage()
        Me.foldersTabPage = New System.Windows.Forms.TabPage()
        Me.defaultAddFolderGroupBox = New System.Windows.Forms.GroupBox()
        Me.myAddFolderButton = New System.Windows.Forms.Button()
        Me.myAddFolderRadioButton = New System.Windows.Forms.RadioButton()
        Me.lastSelectedFolderRadioButton2 = New System.Windows.Forms.RadioButton()
        Me.myAddFolderTextBox = New System.Windows.Forms.TextBox()
        Me.defaultExtractingFolderGroupBox = New System.Windows.Forms.GroupBox()
        Me.myExtractFolderRadioButton = New System.Windows.Forms.RadioButton()
        Me.lastSelectedFolderRadioButton1 = New System.Windows.Forms.RadioButton()
        Me.fileAssociationTabPage = New System.Windows.Forms.TabPage()
        Me.tabPage1 = New System.Windows.Forms.TabPage()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.listView1 = New System.Windows.Forms.ListView()
        Me.imageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.checkBox1 = New System.Windows.Forms.CheckBox()
        Me.folderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.kryptonHeader1 = New ComponentFactory.Krypton.Toolkit.KryptonHeader()
        Me.viewGroupBox.SuspendLayout()
        Me.gridGroupBox.SuspendLayout()
        Me.lookGroupBox.SuspendLayout()
        Me.filePreviewGroupBox.SuspendLayout()
        Me.tempFolderGroupBox.SuspendLayout()
        Me.fileAssociationGroupBox.SuspendLayout()
        Me.tabControl1.SuspendLayout()
        Me.ViewTabPage.SuspendLayout()
        Me.foldersTabPage.SuspendLayout()
        Me.defaultAddFolderGroupBox.SuspendLayout()
        Me.defaultExtractingFolderGroupBox.SuspendLayout()
        Me.fileAssociationTabPage.SuspendLayout()
        Me.tabPage1.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'setButton
        '
        Me.setButton.Location = New System.Drawing.Point(382, 421)
        Me.setButton.Name = "setButton"
        Me.setButton.Size = New System.Drawing.Size(75, 23)
        Me.setButton.TabIndex = 0
        Me.setButton.Text = "Set"
        Me.setButton.UseVisualStyleBackColor = True
        '
        'cancelButton
        '
        Me.cancelButton.Location = New System.Drawing.Point(463, 421)
        Me.cancelButton.Name = "cancelButton"
        Me.cancelButton.Size = New System.Drawing.Size(75, 23)
        Me.cancelButton.TabIndex = 1
        Me.cancelButton.Text = "Cancel"
        Me.cancelButton.UseVisualStyleBackColor = True
        '
        'viewGroupBox
        '
        Me.viewGroupBox.Controls.Add(Me.gridGroupBox)
        Me.viewGroupBox.Controls.Add(Me.lookGroupBox)
        Me.viewGroupBox.Controls.Add(Me.filePreviewGroupBox)
        Me.viewGroupBox.Location = New System.Drawing.Point(6, 16)
        Me.viewGroupBox.Name = "viewGroupBox"
        Me.viewGroupBox.Size = New System.Drawing.Size(526, 252)
        Me.viewGroupBox.TabIndex = 2
        Me.viewGroupBox.TabStop = False
        Me.viewGroupBox.Text = "View"
        '
        'gridGroupBox
        '
        Me.gridGroupBox.Controls.Add(Me.showGridCheckBox)
        Me.gridGroupBox.Location = New System.Drawing.Point(6, 168)
        Me.gridGroupBox.Name = "gridGroupBox"
        Me.gridGroupBox.Size = New System.Drawing.Size(139, 56)
        Me.gridGroupBox.TabIndex = 2
        Me.gridGroupBox.TabStop = False
        Me.gridGroupBox.Text = "Grid"
        '
        'showGridCheckBox
        '
        Me.showGridCheckBox.Location = New System.Drawing.Point(6, 19)
        Me.showGridCheckBox.Name = "showGridCheckBox"
        Me.showGridCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.showGridCheckBox.TabIndex = 3
        Me.showGridCheckBox.Text = "Show grid"
        Me.showGridCheckBox.UseVisualStyleBackColor = True
        '
        'lookGroupBox
        '
        Me.lookGroupBox.Controls.Add(Me.blackLookRadioButton)
        Me.lookGroupBox.Controls.Add(Me.blueLookRadioButton)
        Me.lookGroupBox.Controls.Add(Me.silverLookRadioButton)
        Me.lookGroupBox.Controls.Add(Me.label2)
        Me.lookGroupBox.Controls.Add(Me.classicLookRadioButton)
        Me.lookGroupBox.Location = New System.Drawing.Point(161, 19)
        Me.lookGroupBox.Name = "lookGroupBox"
        Me.lookGroupBox.Size = New System.Drawing.Size(189, 205)
        Me.lookGroupBox.TabIndex = 1
        Me.lookGroupBox.TabStop = False
        Me.lookGroupBox.Text = "Look"
        '
        'blackLookRadioButton
        '
        Me.blackLookRadioButton.Location = New System.Drawing.Point(27, 124)
        Me.blackLookRadioButton.Name = "blackLookRadioButton"
        Me.blackLookRadioButton.Size = New System.Drawing.Size(58, 24)
        Me.blackLookRadioButton.TabIndex = 4
        Me.blackLookRadioButton.Text = "Black"
        Me.blackLookRadioButton.UseVisualStyleBackColor = True
        '
        'blueLookRadioButton
        '
        Me.blueLookRadioButton.Location = New System.Drawing.Point(27, 64)
        Me.blueLookRadioButton.Name = "blueLookRadioButton"
        Me.blueLookRadioButton.Size = New System.Drawing.Size(58, 24)
        Me.blueLookRadioButton.TabIndex = 2
        Me.blueLookRadioButton.Text = "Blue"
        Me.blueLookRadioButton.UseVisualStyleBackColor = True
        '
        'silverLookRadioButton
        '
        Me.silverLookRadioButton.Location = New System.Drawing.Point(27, 94)
        Me.silverLookRadioButton.Name = "silverLookRadioButton"
        Me.silverLookRadioButton.Size = New System.Drawing.Size(58, 24)
        Me.silverLookRadioButton.TabIndex = 3
        Me.silverLookRadioButton.Text = "Silver"
        Me.silverLookRadioButton.UseVisualStyleBackColor = True
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(6, 52)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(100, 23)
        Me.label2.TabIndex = 1
        Me.label2.Text = "Modern:"
        '
        'classicLookRadioButton
        '
        Me.classicLookRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.classicLookRadioButton.Name = "classicLookRadioButton"
        Me.classicLookRadioButton.Size = New System.Drawing.Size(79, 24)
        Me.classicLookRadioButton.TabIndex = 0
        Me.classicLookRadioButton.Text = "Classic"
        Me.classicLookRadioButton.UseVisualStyleBackColor = True
        '
        'filePreviewGroupBox
        '
        Me.filePreviewGroupBox.Controls.Add(Me.detailsRadioButton)
        Me.filePreviewGroupBox.Controls.Add(Me.largeIconsRadioButton)
        Me.filePreviewGroupBox.Controls.Add(Me.listRadioButton)
        Me.filePreviewGroupBox.Controls.Add(Me.smallIconsRadioButton)
        Me.filePreviewGroupBox.Location = New System.Drawing.Point(6, 19)
        Me.filePreviewGroupBox.Name = "filePreviewGroupBox"
        Me.filePreviewGroupBox.Size = New System.Drawing.Size(139, 143)
        Me.filePreviewGroupBox.TabIndex = 0
        Me.filePreviewGroupBox.TabStop = False
        Me.filePreviewGroupBox.Text = "File preview"
        '
        'detailsRadioButton
        '
        Me.detailsRadioButton.Location = New System.Drawing.Point(6, 106)
        Me.detailsRadioButton.Name = "detailsRadioButton"
        Me.detailsRadioButton.Size = New System.Drawing.Size(96, 24)
        Me.detailsRadioButton.TabIndex = 4
        Me.detailsRadioButton.Text = "Details"
        Me.detailsRadioButton.UseVisualStyleBackColor = True
        '
        'largeIconsRadioButton
        '
        Me.largeIconsRadioButton.Location = New System.Drawing.Point(6, 19)
        Me.largeIconsRadioButton.Name = "largeIconsRadioButton"
        Me.largeIconsRadioButton.Size = New System.Drawing.Size(96, 24)
        Me.largeIconsRadioButton.TabIndex = 1
        Me.largeIconsRadioButton.Text = "Large icons"
        Me.largeIconsRadioButton.UseVisualStyleBackColor = True
        '
        'listRadioButton
        '
        Me.listRadioButton.Location = New System.Drawing.Point(6, 76)
        Me.listRadioButton.Name = "listRadioButton"
        Me.listRadioButton.Size = New System.Drawing.Size(96, 24)
        Me.listRadioButton.TabIndex = 3
        Me.listRadioButton.Text = "List"
        Me.listRadioButton.UseVisualStyleBackColor = True
        '
        'smallIconsRadioButton
        '
        Me.smallIconsRadioButton.Location = New System.Drawing.Point(6, 46)
        Me.smallIconsRadioButton.Name = "smallIconsRadioButton"
        Me.smallIconsRadioButton.Size = New System.Drawing.Size(96, 24)
        Me.smallIconsRadioButton.TabIndex = 2
        Me.smallIconsRadioButton.Text = "Small icons"
        Me.smallIconsRadioButton.UseVisualStyleBackColor = True
        '
        'tempFolderGroupBox
        '
        Me.tempFolderGroupBox.Controls.Add(Me.tempFolderBrowseButton)
        Me.tempFolderGroupBox.Controls.Add(Me.tempFolderTextBox)
        Me.tempFolderGroupBox.Location = New System.Drawing.Point(8, 15)
        Me.tempFolderGroupBox.Name = "tempFolderGroupBox"
        Me.tempFolderGroupBox.Size = New System.Drawing.Size(519, 51)
        Me.tempFolderGroupBox.TabIndex = 3
        Me.tempFolderGroupBox.TabStop = False
        Me.tempFolderGroupBox.Text = "Temp Folder"
        '
        'tempFolderBrowseButton
        '
        Me.tempFolderBrowseButton.Location = New System.Drawing.Point(444, 19)
        Me.tempFolderBrowseButton.Name = "tempFolderBrowseButton"
        Me.tempFolderBrowseButton.Size = New System.Drawing.Size(69, 20)
        Me.tempFolderBrowseButton.TabIndex = 2
        Me.tempFolderBrowseButton.Text = "Browse"
        Me.tempFolderBrowseButton.UseVisualStyleBackColor = True
        '
        'tempFolderTextBox
        '
        Me.tempFolderTextBox.Location = New System.Drawing.Point(6, 19)
        Me.tempFolderTextBox.Name = "tempFolderTextBox"
        Me.tempFolderTextBox.Size = New System.Drawing.Size(432, 20)
        Me.tempFolderTextBox.TabIndex = 1
        '
        'myExtractFolderButton
        '
        Me.myExtractFolderButton.Location = New System.Drawing.Point(444, 52)
        Me.myExtractFolderButton.Name = "myExtractFolderButton"
        Me.myExtractFolderButton.Size = New System.Drawing.Size(69, 20)
        Me.myExtractFolderButton.TabIndex = 5
        Me.myExtractFolderButton.Text = "Browse"
        Me.myExtractFolderButton.UseVisualStyleBackColor = True
        '
        'myExtractFolderTextBox
        '
        Me.myExtractFolderTextBox.Location = New System.Drawing.Point(125, 52)
        Me.myExtractFolderTextBox.Name = "myExtractFolderTextBox"
        Me.myExtractFolderTextBox.Size = New System.Drawing.Size(313, 20)
        Me.myExtractFolderTextBox.TabIndex = 4
        '
        'fileAssociationGroupBox
        '
        Me.fileAssociationGroupBox.Controls.Add(Me.button3)
        Me.fileAssociationGroupBox.Controls.Add(Me.button2)
        Me.fileAssociationGroupBox.Controls.Add(Me.button1)
        Me.fileAssociationGroupBox.Controls.Add(Me.fileCheckedListBox)
        Me.fileAssociationGroupBox.Location = New System.Drawing.Point(8, 17)
        Me.fileAssociationGroupBox.Name = "fileAssociationGroupBox"
        Me.fileAssociationGroupBox.Size = New System.Drawing.Size(526, 308)
        Me.fileAssociationGroupBox.TabIndex = 4
        Me.fileAssociationGroupBox.TabStop = False
        Me.fileAssociationGroupBox.Text = "File Association"
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(327, 278)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(193, 23)
        Me.button3.TabIndex = 4
        Me.button3.Text = "Select Recomended Files"
        Me.button3.UseVisualStyleBackColor = True
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(246, 278)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(75, 23)
        Me.button2.TabIndex = 3
        Me.button2.Text = "Deselect All"
        Me.button2.UseVisualStyleBackColor = True
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(165, 278)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(75, 23)
        Me.button1.TabIndex = 2
        Me.button1.Text = "Select All"
        Me.button1.UseVisualStyleBackColor = True
        '
        'fileCheckedListBox
        '
        Me.fileCheckedListBox.CheckOnClick = True
        Me.fileCheckedListBox.FormattingEnabled = True
        Me.fileCheckedListBox.Items.AddRange(New Object() {".zip", ".7z", ".tar", ".gz", ".bz2", ".arc", ".arj", ".asd", ".ace", ".mime", ".b64", ".bel", ".deb", ".yz1", ".f", ".frz", ".icl", ".ico", ".cab", ".jam", ".lha", ".lzh", ".lzs", ".hqx", ".cpt", ".dmg", ".pit", ".pak", ".wad", ".rar", ".rpm", ".sqx", ".macbin", ".cpio", ".shar", ".uue", ".xxe", ".imp", ".yenc", ".zoo", ".ear", ".jar", ".war", ".wsz", ".mskin", ".bzs", ".wal", ".wmz", ".sae"})
        Me.fileCheckedListBox.Location = New System.Drawing.Point(6, 19)
        Me.fileCheckedListBox.MultiColumn = True
        Me.fileCheckedListBox.Name = "fileCheckedListBox"
        Me.fileCheckedListBox.Size = New System.Drawing.Size(514, 229)
        Me.fileCheckedListBox.TabIndex = 0
        '
        'tabControl1
        '
        Me.tabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabControl1.Controls.Add(Me.ViewTabPage)
        Me.tabControl1.Controls.Add(Me.foldersTabPage)
        Me.tabControl1.Controls.Add(Me.fileAssociationTabPage)
        Me.tabControl1.Controls.Add(Me.tabPage1)
        Me.tabControl1.Location = New System.Drawing.Point(0, 58)
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(550, 357)
        Me.tabControl1.TabIndex = 5
        '
        'ViewTabPage
        '
        Me.ViewTabPage.Controls.Add(Me.viewGroupBox)
        Me.ViewTabPage.Location = New System.Drawing.Point(4, 22)
        Me.ViewTabPage.Name = "ViewTabPage"
        Me.ViewTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.ViewTabPage.Size = New System.Drawing.Size(542, 331)
        Me.ViewTabPage.TabIndex = 0
        Me.ViewTabPage.Text = "View"
        Me.ViewTabPage.UseVisualStyleBackColor = True
        '
        'foldersTabPage
        '
        Me.foldersTabPage.Controls.Add(Me.defaultAddFolderGroupBox)
        Me.foldersTabPage.Controls.Add(Me.defaultExtractingFolderGroupBox)
        Me.foldersTabPage.Controls.Add(Me.tempFolderGroupBox)
        Me.foldersTabPage.Location = New System.Drawing.Point(4, 22)
        Me.foldersTabPage.Name = "foldersTabPage"
        Me.foldersTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.foldersTabPage.Size = New System.Drawing.Size(542, 331)
        Me.foldersTabPage.TabIndex = 1
        Me.foldersTabPage.Text = "Folders"
        Me.foldersTabPage.UseVisualStyleBackColor = True
        '
        'defaultAddFolderGroupBox
        '
        Me.defaultAddFolderGroupBox.Controls.Add(Me.myAddFolderButton)
        Me.defaultAddFolderGroupBox.Controls.Add(Me.myAddFolderRadioButton)
        Me.defaultAddFolderGroupBox.Controls.Add(Me.lastSelectedFolderRadioButton2)
        Me.defaultAddFolderGroupBox.Controls.Add(Me.myAddFolderTextBox)
        Me.defaultAddFolderGroupBox.Location = New System.Drawing.Point(8, 166)
        Me.defaultAddFolderGroupBox.Name = "defaultAddFolderGroupBox"
        Me.defaultAddFolderGroupBox.Size = New System.Drawing.Size(519, 108)
        Me.defaultAddFolderGroupBox.TabIndex = 7
        Me.defaultAddFolderGroupBox.TabStop = False
        Me.defaultAddFolderGroupBox.Text = "Default Add Folder"
        '
        'myAddFolderButton
        '
        Me.myAddFolderButton.Location = New System.Drawing.Point(444, 49)
        Me.myAddFolderButton.Name = "myAddFolderButton"
        Me.myAddFolderButton.Size = New System.Drawing.Size(69, 20)
        Me.myAddFolderButton.TabIndex = 3
        Me.myAddFolderButton.Text = "Browse"
        Me.myAddFolderButton.UseVisualStyleBackColor = True
        '
        'myAddFolderRadioButton
        '
        Me.myAddFolderRadioButton.Location = New System.Drawing.Point(6, 49)
        Me.myAddFolderRadioButton.Name = "myAddFolderRadioButton"
        Me.myAddFolderRadioButton.Size = New System.Drawing.Size(104, 24)
        Me.myAddFolderRadioButton.TabIndex = 2
        Me.myAddFolderRadioButton.Text = "My add folder:"
        Me.myAddFolderRadioButton.UseVisualStyleBackColor = True
        '
        'lastSelectedFolderRadioButton2
        '
        Me.lastSelectedFolderRadioButton2.Location = New System.Drawing.Point(6, 19)
        Me.lastSelectedFolderRadioButton2.Name = "lastSelectedFolderRadioButton2"
        Me.lastSelectedFolderRadioButton2.Size = New System.Drawing.Size(128, 24)
        Me.lastSelectedFolderRadioButton2.TabIndex = 1
        Me.lastSelectedFolderRadioButton2.Text = "Last selected folder"
        Me.lastSelectedFolderRadioButton2.UseVisualStyleBackColor = True
        '
        'myAddFolderTextBox
        '
        Me.myAddFolderTextBox.Location = New System.Drawing.Point(125, 49)
        Me.myAddFolderTextBox.Name = "myAddFolderTextBox"
        Me.myAddFolderTextBox.Size = New System.Drawing.Size(313, 20)
        Me.myAddFolderTextBox.TabIndex = 0
        '
        'defaultExtractingFolderGroupBox
        '
        Me.defaultExtractingFolderGroupBox.Controls.Add(Me.myExtractFolderRadioButton)
        Me.defaultExtractingFolderGroupBox.Controls.Add(Me.lastSelectedFolderRadioButton1)
        Me.defaultExtractingFolderGroupBox.Controls.Add(Me.myExtractFolderTextBox)
        Me.defaultExtractingFolderGroupBox.Controls.Add(Me.myExtractFolderButton)
        Me.defaultExtractingFolderGroupBox.Location = New System.Drawing.Point(8, 72)
        Me.defaultExtractingFolderGroupBox.Name = "defaultExtractingFolderGroupBox"
        Me.defaultExtractingFolderGroupBox.Size = New System.Drawing.Size(519, 88)
        Me.defaultExtractingFolderGroupBox.TabIndex = 6
        Me.defaultExtractingFolderGroupBox.TabStop = False
        Me.defaultExtractingFolderGroupBox.Text = "Default Extracting Folder"
        '
        'myExtractFolderRadioButton
        '
        Me.myExtractFolderRadioButton.Location = New System.Drawing.Point(6, 49)
        Me.myExtractFolderRadioButton.Name = "myExtractFolderRadioButton"
        Me.myExtractFolderRadioButton.Size = New System.Drawing.Size(113, 24)
        Me.myExtractFolderRadioButton.TabIndex = 7
        Me.myExtractFolderRadioButton.Text = "My extract folder:"
        Me.myExtractFolderRadioButton.UseVisualStyleBackColor = True
        '
        'lastSelectedFolderRadioButton1
        '
        Me.lastSelectedFolderRadioButton1.Location = New System.Drawing.Point(6, 19)
        Me.lastSelectedFolderRadioButton1.Name = "lastSelectedFolderRadioButton1"
        Me.lastSelectedFolderRadioButton1.Size = New System.Drawing.Size(128, 24)
        Me.lastSelectedFolderRadioButton1.TabIndex = 6
        Me.lastSelectedFolderRadioButton1.Text = "Last selected folder"
        Me.lastSelectedFolderRadioButton1.UseVisualStyleBackColor = True
        '
        'fileAssociationTabPage
        '
        Me.fileAssociationTabPage.Controls.Add(Me.fileAssociationGroupBox)
        Me.fileAssociationTabPage.Location = New System.Drawing.Point(4, 22)
        Me.fileAssociationTabPage.Name = "fileAssociationTabPage"
        Me.fileAssociationTabPage.Size = New System.Drawing.Size(542, 331)
        Me.fileAssociationTabPage.TabIndex = 2
        Me.fileAssociationTabPage.Text = "File Association"
        Me.fileAssociationTabPage.UseVisualStyleBackColor = True
        '
        'tabPage1
        '
        Me.tabPage1.Controls.Add(Me.groupBox1)
        Me.tabPage1.Location = New System.Drawing.Point(4, 22)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Size = New System.Drawing.Size(542, 331)
        Me.tabPage1.TabIndex = 3
        Me.tabPage1.Text = "Shell Extension"
        Me.tabPage1.UseVisualStyleBackColor = True
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.listView1)
        Me.groupBox1.Controls.Add(Me.checkBox1)
        Me.groupBox1.Location = New System.Drawing.Point(8, 12)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(524, 162)
        Me.groupBox1.TabIndex = 0
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Shell Extension"
        '
        'listView1
        '
        Me.listView1.CheckBoxes = True
        Me.listView1.Enabled = False
        ListViewItem1.StateImageIndex = 0
        ListViewItem2.StateImageIndex = 0
        ListViewItem3.StateImageIndex = 0
        ListViewItem4.StateImageIndex = 0
        Me.listView1.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem1, ListViewItem2, ListViewItem3, ListViewItem4})
        Me.listView1.Location = New System.Drawing.Point(17, 49)
        Me.listView1.Name = "listView1"
        Me.listView1.Size = New System.Drawing.Size(234, 97)
        Me.listView1.SmallImageList = Me.imageList1
        Me.listView1.TabIndex = 1
        Me.listView1.UseCompatibleStateImageBehavior = False
        Me.listView1.View = System.Windows.Forms.View.List
        '
        'imageList1
        '
        Me.imageList1.ImageStream = CType(resources.GetObject("imageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.imageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.imageList1.Images.SetKeyName(0, "SCMIcon.ico")
        '
        'checkBox1
        '
        Me.checkBox1.Location = New System.Drawing.Point(6, 19)
        Me.checkBox1.Name = "checkBox1"
        Me.checkBox1.Size = New System.Drawing.Size(104, 24)
        Me.checkBox1.TabIndex = 0
        Me.checkBox1.Text = "Enabled"
        Me.checkBox1.UseVisualStyleBackColor = True
        '
        'kryptonHeader1
        '
        Me.kryptonHeader1.AutoSize = False
        Me.kryptonHeader1.Dock = System.Windows.Forms.DockStyle.Top
        Me.kryptonHeader1.Location = New System.Drawing.Point(0, 0)
        Me.kryptonHeader1.Name = "kryptonHeader1"
        Me.kryptonHeader1.Size = New System.Drawing.Size(548, 58)
        Me.kryptonHeader1.TabIndex = 6
        Me.kryptonHeader1.Text = "Options"
        Me.kryptonHeader1.Values.Description = ""
        Me.kryptonHeader1.Values.Heading = "Options"
        Me.kryptonHeader1.Values.Image = CType(resources.GetObject("kryptonHeader1.Values.Image"), System.Drawing.Image)
        '
        'OptionsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(548, 451)
        Me.Controls.Add(Me.kryptonHeader1)
        Me.Controls.Add(Me.tabControl1)
        Me.Controls.Add(Me.cancelButton)
        Me.Controls.Add(Me.setButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "OptionsForm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "SharpArchiver"
        Me.viewGroupBox.ResumeLayout(False)
        Me.gridGroupBox.ResumeLayout(False)
        Me.lookGroupBox.ResumeLayout(False)
        Me.filePreviewGroupBox.ResumeLayout(False)
        Me.tempFolderGroupBox.ResumeLayout(False)
        Me.tempFolderGroupBox.PerformLayout()
        Me.fileAssociationGroupBox.ResumeLayout(False)
        Me.tabControl1.ResumeLayout(False)
        Me.ViewTabPage.ResumeLayout(False)
        Me.foldersTabPage.ResumeLayout(False)
        Me.defaultAddFolderGroupBox.ResumeLayout(False)
        Me.defaultAddFolderGroupBox.PerformLayout()
        Me.defaultExtractingFolderGroupBox.ResumeLayout(False)
        Me.defaultExtractingFolderGroupBox.PerformLayout()
        Me.fileAssociationTabPage.ResumeLayout(False)
        Me.tabPage1.ResumeLayout(False)
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Private listView1 As System.Windows.Forms.ListView
	Private checkBox1 As System.Windows.Forms.CheckBox
	Private groupBox1 As System.Windows.Forms.GroupBox
	Private imageList1 As System.Windows.Forms.ImageList
	Private tabPage1 As System.Windows.Forms.TabPage
	Private button3 As System.Windows.Forms.Button
	Private button2 As System.Windows.Forms.Button
	Private button1 As System.Windows.Forms.Button
	Private folderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
	Private setButton As System.Windows.Forms.Button
	Private cancelButton As System.Windows.Forms.Button
	Private ViewTabPage As System.Windows.Forms.TabPage
	Private foldersTabPage As System.Windows.Forms.TabPage
	Private fileAssociationTabPage As System.Windows.Forms.TabPage
	Private viewGroupBox As System.Windows.Forms.GroupBox
	Private tempFolderGroupBox As System.Windows.Forms.GroupBox
	Private myExtractFolderButton As System.Windows.Forms.Button
	Private myExtractFolderTextBox As System.Windows.Forms.TextBox
	Private tempFolderBrowseButton As System.Windows.Forms.Button
	Private tempFolderTextBox As System.Windows.Forms.TextBox
	Private fileAssociationGroupBox As System.Windows.Forms.GroupBox
	Private fileCheckedListBox As System.Windows.Forms.CheckedListBox
	Private defaultAddFolderGroupBox As System.Windows.Forms.GroupBox
	Private myAddFolderTextBox As System.Windows.Forms.TextBox
	Private defaultExtractingFolderGroupBox As System.Windows.Forms.GroupBox
	Private myAddFolderButton As System.Windows.Forms.Button
	Private myAddFolderRadioButton As System.Windows.Forms.RadioButton
	Private lastSelectedFolderRadioButton2 As System.Windows.Forms.RadioButton
	Private myExtractFolderRadioButton As System.Windows.Forms.RadioButton
	Private lastSelectedFolderRadioButton1 As System.Windows.Forms.RadioButton
	Private gridGroupBox As System.Windows.Forms.GroupBox
	Private showGridCheckBox As System.Windows.Forms.CheckBox
	Private lookGroupBox As System.Windows.Forms.GroupBox
	Private blackLookRadioButton As System.Windows.Forms.RadioButton
	Private blueLookRadioButton As System.Windows.Forms.RadioButton
	Private silverLookRadioButton As System.Windows.Forms.RadioButton
	Private classicLookRadioButton As System.Windows.Forms.RadioButton
	Private filePreviewGroupBox As System.Windows.Forms.GroupBox
	Private detailsRadioButton As System.Windows.Forms.RadioButton
	Private largeIconsRadioButton As System.Windows.Forms.RadioButton
	Private listRadioButton As System.Windows.Forms.RadioButton
	Private smallIconsRadioButton As System.Windows.Forms.RadioButton
	Private label2 As System.Windows.Forms.Label
	Private tabControl1 As System.Windows.Forms.TabControl
	Private kryptonHeader1 As ComponentFactory.Krypton.Toolkit.KryptonHeader



End Class
