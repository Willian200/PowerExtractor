﻿Public Class Scanform

    Public Sub New(ByVal ArquivoOuPath As String)

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    Me.TexBoxFile.Text = ArquivoOuPath
    
    If File.Exists(ArquivoOuPath) Then 
    Dim Locked As List(Of Process) = ProcessLocking.WhoIsLocking(ArquivoouPath)
    If Locked.Count > 0 Then 
    For Each itemproc In Locked 
    MsgBox.Show(" o Arquivo " &  ItemProc.ProcessName.ToString")
    End For
    
    End If 
    
    "Exemplo Base
    'Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
    '    LockedFileProcesses.Clear()
    '    RichTextBox1.Text = ""
    '    Dim OFD As New OpenFileDialog
    '    OFD.InitialDirectory = "C:\Users\John\Desktop"
    '    OFD.Title = "Check Locked File"
    '    OFD.Multiselect = False
    '    If OFD.ShowDialog = Windows.Forms.DialogResult.OK Then
    '        LockedFileProcesses = WhoIsLocking(OFD.FileName)
    '        If LockedFileProcesses.Count > 0 Then
    '            For Each Item In LockedFileProcesses
    '                RichTextBox1.AppendText(OFD.FileName & " - " & Item.ProcessName.ToString & " .. " & Item.Id.ToString & vbCrLf)
    '            Next
    '        End If
    '    End If



    End Sub
End Class