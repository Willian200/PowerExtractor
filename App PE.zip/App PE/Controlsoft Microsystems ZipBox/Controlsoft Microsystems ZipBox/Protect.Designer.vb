﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Protect
    Inherits Metro.Form
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Protect))
        Me.GlassButton4 = New Glass.GlassButton()
        Me.GlassButton3 = New Glass.GlassButton()
        Me.GGlowBox2 = New gGlowBox.gGlowBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GlassButton2 = New Glass.GlassButton()
        Me.GGlowBox1 = New gGlowBox.gGlowBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GlassButton1 = New Glass.GlassButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GGlowBox3 = New gGlowBox.gGlowBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.GGlowBox2.SuspendLayout()
        Me.GGlowBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GGlowBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GlassButton4
        '
        Me.GlassButton4.Location = New System.Drawing.Point(158, 350)
        Me.GlassButton4.Name = "GlassButton4"
        Me.GlassButton4.Size = New System.Drawing.Size(124, 25)
        Me.GlassButton4.TabIndex = 23
        Me.GlassButton4.Text = "Descriptografar"
        '
        'GlassButton3
        '
        Me.GlassButton3.Location = New System.Drawing.Point(28, 350)
        Me.GlassButton3.Name = "GlassButton3"
        Me.GlassButton3.Size = New System.Drawing.Size(124, 25)
        Me.GlassButton3.TabIndex = 22
        Me.GlassButton3.Text = "Criptografar"
        '
        'GGlowBox2
        '
        Me.GGlowBox2.Controls.Add(Me.TextBox2)
        Me.GGlowBox2.Location = New System.Drawing.Point(39, 193)
        Me.GGlowBox2.Name = "GGlowBox2"
        Me.GGlowBox2.Size = New System.Drawing.Size(403, 27)
        Me.GGlowBox2.TabIndex = 21
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Gray
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(4, 4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(396, 22)
        Me.TextBox2.TabIndex = 11
        Me.TextBox2.Text = "Selecione a Pasta a Salvar"
        '
        'GlassButton2
        '
        Me.GlassButton2.Location = New System.Drawing.Point(448, 193)
        Me.GlassButton2.Name = "GlassButton2"
        Me.GlassButton2.Size = New System.Drawing.Size(40, 23)
        Me.GlassButton2.TabIndex = 20
        Me.GlassButton2.Text = "..."
        '
        'GGlowBox1
        '
        Me.GGlowBox1.Controls.Add(Me.TextBox1)
        Me.GGlowBox1.Location = New System.Drawing.Point(39, 149)
        Me.GGlowBox1.Name = "GGlowBox1"
        Me.GGlowBox1.Size = New System.Drawing.Size(403, 27)
        Me.GGlowBox1.TabIndex = 19
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.Gray
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Location = New System.Drawing.Point(4, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(396, 22)
        Me.TextBox1.TabIndex = 11
        Me.TextBox1.Text = "Selecione o Arquivo Para Criptografar"
        '
        'GlassButton1
        '
        Me.GlassButton1.Location = New System.Drawing.Point(448, 149)
        Me.GlassButton1.Name = "GlassButton1"
        Me.GlassButton1.Size = New System.Drawing.Size(40, 23)
        Me.GlassButton1.TabIndex = 18
        Me.GlassButton1.Text = "..."
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(28, 47)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(64, 63)
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'GGlowBox3
        '
        Me.GGlowBox3.Controls.Add(Me.TextBox3)
        Me.GGlowBox3.Location = New System.Drawing.Point(39, 239)
        Me.GGlowBox3.Name = "GGlowBox3"
        Me.GGlowBox3.Size = New System.Drawing.Size(403, 27)
        Me.GGlowBox3.TabIndex = 26
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Gray
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.Location = New System.Drawing.Point(4, 4)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(396, 22)
        Me.TextBox3.TabIndex = 11
        Me.TextBox3.Text = "Senha"
        '
        'Protect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gray
        Me.ClientSize = New System.Drawing.Size(654, 390)
        Me.Controls.Add(Me.GGlowBox3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GlassButton4)
        Me.Controls.Add(Me.GlassButton3)
        Me.Controls.Add(Me.GGlowBox2)
        Me.Controls.Add(Me.GlassButton2)
        Me.Controls.Add(Me.GGlowBox1)
        Me.Controls.Add(Me.GlassButton1)
        Me.ForeColor = System.Drawing.Color.Silver
        Me.MaximizeBox = False
        Me.Name = "Protect"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Protect"
        Me.Controls.SetChildIndex(Me.GlassButton1, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox1, 0)
        Me.Controls.SetChildIndex(Me.GlassButton2, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox2, 0)
        Me.Controls.SetChildIndex(Me.GlassButton3, 0)
        Me.Controls.SetChildIndex(Me.GlassButton4, 0)
        Me.Controls.SetChildIndex(Me.PictureBox1, 0)
        Me.Controls.SetChildIndex(Me.GGlowBox3, 0)
        Me.GGlowBox2.ResumeLayout(False)
        Me.GGlowBox2.PerformLayout()
        Me.GGlowBox1.ResumeLayout(False)
        Me.GGlowBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GGlowBox3.ResumeLayout(False)
        Me.GGlowBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GlassButton4 As Glass.GlassButton
    Friend WithEvents GlassButton3 As Glass.GlassButton
    Friend WithEvents GGlowBox2 As gGlowBox.gGlowBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents GlassButton2 As Glass.GlassButton
    Friend WithEvents GGlowBox1 As gGlowBox.gGlowBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents GlassButton1 As Glass.GlassButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GGlowBox3 As gGlowBox.gGlowBox
    Friend WithEvents TextBox3 As TextBox
End Class
