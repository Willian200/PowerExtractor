﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PieceSizeDialog
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBoxPieceSize = New System.Windows.Forms.TextBox
        Me.RadioButtonGB = New System.Windows.Forms.RadioButton
        Me.RadioButtonMB = New System.Windows.Forms.RadioButton
        Me.RadioButtonKB = New System.Windows.Forms.RadioButton
        Me.ButtonOk = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'RichTextBoxPieceSize
        '
        Me.TextBoxPieceSize.Location = New System.Drawing.Point(11, 36)
        Me.TextBoxPieceSize.MaxLength = 14
        Me.TextBoxPieceSize.Multiline = False
        Me.TextBoxPieceSize.Name = "RichTextBoxPieceSize"
        Me.TextBoxPieceSize.Size = New System.Drawing.Size(92, 20)
        Me.TextBoxPieceSize.TabIndex = 21
        Me.TextBoxPieceSize.Text = ""
        '
        'RadioButtonGB
        '
        Me.RadioButtonGB.AutoSize = True
        Me.RadioButtonGB.Location = New System.Drawing.Point(103, 13)
        Me.RadioButtonGB.Name = "RadioButtonGB"
        Me.RadioButtonGB.Size = New System.Drawing.Size(40, 17)
        Me.RadioButtonGB.TabIndex = 20
        Me.RadioButtonGB.Text = "GB"
        Me.RadioButtonGB.UseVisualStyleBackColor = True
        '
        'RadioButtonMB
        '
        Me.RadioButtonMB.AutoSize = True
        Me.RadioButtonMB.Checked = True
        Me.RadioButtonMB.Location = New System.Drawing.Point(56, 13)
        Me.RadioButtonMB.Name = "RadioButtonMB"
        Me.RadioButtonMB.Size = New System.Drawing.Size(41, 17)
        Me.RadioButtonMB.TabIndex = 19
        Me.RadioButtonMB.TabStop = True
        Me.RadioButtonMB.Text = "MB"
        Me.RadioButtonMB.UseVisualStyleBackColor = True
        '
        'RadioButtonKB
        '
        Me.RadioButtonKB.AutoSize = True
        Me.RadioButtonKB.Location = New System.Drawing.Point(11, 13)
        Me.RadioButtonKB.Name = "RadioButtonKB"
        Me.RadioButtonKB.Size = New System.Drawing.Size(39, 17)
        Me.RadioButtonKB.TabIndex = 18
        Me.RadioButtonKB.TabStop = True
        Me.RadioButtonKB.Text = "KB"
        Me.RadioButtonKB.UseVisualStyleBackColor = True
        '
        'ButtonOk
        '
        Me.ButtonOk.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.ButtonOk.Location = New System.Drawing.Point(109, 34)
        Me.ButtonOk.Name = "ButtonOk"
        Me.ButtonOk.Size = New System.Drawing.Size(34, 23)
        Me.ButtonOk.TabIndex = 17
        Me.ButtonOk.Text = "OK"
        Me.ButtonOk.UseVisualStyleBackColor = True
        '
        'PieceSizeDialog
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(154, 70)
        Me.Controls.Add(Me.TextBoxPieceSize)
        Me.Controls.Add(Me.RadioButtonGB)
        Me.Controls.Add(Me.RadioButtonMB)
        Me.Controls.Add(Me.RadioButtonKB)
        Me.Controls.Add(Me.ButtonOk)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "PieceSizeDialog"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Specify piece size"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents TextBoxPieceSize As System.Windows.Forms.TextBox
    Private WithEvents RadioButtonGB As System.Windows.Forms.RadioButton
    Private WithEvents RadioButtonMB As System.Windows.Forms.RadioButton
    Private WithEvents RadioButtonKB As System.Windows.Forms.RadioButton
    Private WithEvents ButtonOk As System.Windows.Forms.Button
End Class
