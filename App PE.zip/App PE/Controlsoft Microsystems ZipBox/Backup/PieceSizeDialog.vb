﻿Public Class PieceSizeDialog

    Public Sub New()
        InitializeComponent()
    End Sub

    Private m_PieceSize As Long

    Public Property PieceSize() As Long
        Get
            Return m_PieceSize
        End Get
        Set(ByVal value As Long)
            m_PieceSize = value
        End Set
    End Property

    Private Sub PieceSizeDialog_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Me.CenterToParent()
    End Sub

    Private Sub TextBoxPieceSize_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles TextBoxPieceSize.KeyDown
        Dim supper As Boolean = False
        For i As Integer = 0 To TextBoxPieceSize.Text.Length - 1
            If TextBoxPieceSize.Text.Substring(i, 1) = "." Then
                supper = True
            End If
        Next
        Select Case e.KeyCode
            Case Keys.D0, Keys.D1, Keys.D2, Keys.D3, Keys.D4, Keys.D5, _
            Keys.D6, Keys.D7, Keys.D8, Keys.D9, Keys.NumPad0, Keys.NumPad1, _
            Keys.NumPad2, Keys.NumPad3, Keys.NumPad4, Keys.NumPad5, Keys.NumPad6, Keys.NumPad7, _
            Keys.NumPad8, Keys.NumPad9, Keys.Back, Keys.Left, Keys.Right, Keys.Up, _
            Keys.Down, Keys.Delete
                Exit Select
            Case Keys.Enter
                Exit Select
            Case Keys.[Decimal], Keys.OemPeriod
                e.SuppressKeyPress = supper
                Exit Select
            Case Else
                e.SuppressKeyPress = True
                Exit Select
        End Select
    End Sub

    Private Sub ButtonOk_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ButtonOk.Click
        If Me.TextBoxPieceSize.Text <> "" Then
            Dim d As Double = Convert.ToDouble(Me.TextBoxPieceSize.Text)
            If RadioButtonKB.Checked Then
                d *= 1024
            ElseIf RadioButtonMB.Checked Then
                d *= 1024 * 1024
            ElseIf RadioButtonGB.Checked Then
                d *= 1024 * 1024 * 1024
            End If
            m_PieceSize = Convert.ToInt64(Math.Truncate(d))
        End If
    End Sub

End Class